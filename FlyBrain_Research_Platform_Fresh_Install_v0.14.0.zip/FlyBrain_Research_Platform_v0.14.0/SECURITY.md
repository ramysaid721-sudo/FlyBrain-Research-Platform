# Security Policy

## Supported versions

Security fixes should target the latest released versions of FlyBrain-NOS and URCAL in this repository.

## Reporting a vulnerability

Do not publish credentials, access tokens, private datasets, or exploitable details in public issues. Use GitHub's private vulnerability reporting feature if enabled for the repository, or contact the repository owner through a private channel.

## Operational requirements

- Never commit API tokens, provider credentials, personal data, or private connectome datasets.
- Use distinct tokens per principal and store them in a managed secret store.
- Keep URCAL's development WSGI server bound to loopback; do not expose it directly to the public internet.
- Require TLS, firewall rules, rate limits, audit retention, backups, and least-privilege identities before remote deployment.
- Keep provider routing fail-closed until account access, quotas, cost limits, and connectivity are verified.
