# Neural runtime status

## Available runtime modes

Release: FlyBrain-NOS 0.13.2.

### Synthetic temporal propagation
`flybrain_os.temporal.simulate_steps` provides a transparent nonnegative activation sandbox over directed graph edges. Its parameters are engineering assumptions, not physiological estimates.

### Synthetic leaky-integrate-and-fire runtime
`flybrain_os.neural_runtime.simulate_lif` provides discrete-time LIF membrane dynamics, refractory periods, signed synaptic weights, voltage traces and spike counts. All electrical parameters and weights must be supplied by the experiment. A spike at step *t* affects downstream neurons at step *t+1*.

## Evidence boundary

Neither runtime is a biologically validated Drosophila brain simulator. The LIF model is a generic computational neuron abstraction. The connectome input currently describes structural connectivity; synapse counts are not automatically treated as synaptic strengths, signs, delays or physiological conductances. Such mappings require explicit sourced evidence or clearly labelled fitted assumptions.

## Validation plan

For any scientific claim, freeze the dataset snapshot and parameter set, compare against non-neural baselines (linear propagation, graph diffusion and a conventional classifier/router as appropriate), use held-out tasks, report uncertainty and ablations, and separate parameter fitting from evaluation. Runtime execution alone does not establish biological fidelity or a decision-making advantage.
