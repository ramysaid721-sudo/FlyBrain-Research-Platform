# Multi-model research hub (0.8.0)

FlyBrain-NOS can consult configured model providers in parallel. OpenAI and xAI use their Responses API adapters; other presets use their OpenAI-compatible Chat Completions endpoints. Supported presets include OpenAI API, xAI (Grok), Hugging Face Inference Providers, OpenRouter, Ollama local, Groq, Together, Fireworks, DeepSeek, Mistral, and Gemini's OpenAI-compatible endpoint. Custom compatible endpoints can be added through `FLYBRAIN_EXTRA_PROVIDERS`.

## Configuration

Set model IDs and credentials in the process environment (or a secret manager that injects environment variables). Never commit keys or paste them into project files:

| Provider | Model variable | Credential variable |
|---|---|---|
| OpenAI | `OPENAI_MODEL` | `OPENAI_API_KEY` |
| xAI / Grok | `XAI_MODEL` | `XAI_API_KEY` |
| Hugging Face | `HF_MODEL` | `HF_TOKEN` |
| OpenRouter | `OPENROUTER_MODEL` | `OPENROUTER_API_KEY` |
| Ollama local | `OLLAMA_MODEL` | none for loopback server |
| Groq | `GROQ_MODEL` | `GROQ_API_KEY` |
| Together | `TOGETHER_MODEL` | `TOGETHER_API_KEY` |
| Fireworks | `FIREWORKS_MODEL` | `FIREWORKS_API_KEY` |
| DeepSeek | `DEEPSEEK_MODEL` | `DEEPSEEK_API_KEY` |
| Mistral | `MISTRAL_MODEL` | `MISTRAL_API_KEY` |
| Gemini | `GEMINI_MODEL` | `GEMINI_API_KEY` |

Optional endpoint overrides use `<PROVIDER>_BASE_URL`. Remote endpoints must use HTTPS; only local Ollama loopback HTTP is accepted. Example custom provider JSON (credential value remains only in its named environment variable):

```json
[{"id":"my-provider","endpoint":"https://api.example.com/v1","model":"model-name","key_env":"MY_PROVIDER_KEY"}]
```

Set that JSON string as `FLYBRAIN_EXTRA_PROVIDERS` and export `MY_PROVIDER_KEY` separately.

## Commands

```bash
flybrain-nos model-hub-status
flybrain-nos model-task-plan "Review the FlyBrain-NOS circuit routing architecture"
flybrain-nos model-consult "Independently review the FlyBrain-NOS circuit routing architecture" --output data/model-review.json
flybrain-nos model-consult "Review a confidential local experiment" --local-only
flybrain-nos model-provider-check
```

`model-hub-status` reports provider readiness and local CPU/RAM/GPU/scheduler observations without printing credentials. `model-task-plan` creates a proposer / independent critic / synthesizer workflow without contacting any provider. `model-consult` calls configured providers concurrently and records results in a local SQLite ledger. Add `--local-only` to exclude every remote provider; the result includes a privacy summary naming the providers that received the task and whether external transfer occurred. `model-provider-check` probes each configured `/models` endpoint without transmitting a research prompt. A provider may be reachable while its model-list endpoint is unsupported; treat the result as a diagnostic, not a guarantee that generation will succeed.

## Evidence and safety rules

- Provider output is untrusted research input, not executable instructions.
- No generated code is executed automatically, and no model can authorize deployment.
- Agreement between models is not scientific evidence; preserve disagreement and verify claims against primary sources or experiments.
- Requests may incur provider charges and transmit the submitted prompt to the selected provider. Only configure providers whose data policies are acceptable for the material being sent.
- Keys are read from environment variables and are never written to the project database or result report. Error records avoid including request headers or key values.
- This module does not create accounts, provision paid compute, or assume that a configured provider is reachable.

## Current execution boundary

The development container can inspect its own CPU and memory and can detect NVIDIA GPUs when `nvidia-smi` is installed. It cannot inspect another host's resources without an installed agent/connector on that host. NRC's source/runtime was not present in the current workspace, so this release does not claim a live NRC↔FlyBrain-NOS execution session. The collaboration ledger and model hub are ready to be configured and run where both systems are deployed.

## API selection and privacy controls (0.8.0)

- OpenAI and xAI presets use `POST /responses` with the `input` field and parse `output_text` (or structured output text blocks).
- Other presets continue to use `POST /chat/completions` for broad compatibility, including Hugging Face Inference Providers and local Ollama.
- Custom providers may set `"api_mode":"responses"`; default is `chat`.
- `model-provider-check` sends only an authenticated metadata GET to `/models`; it does not submit research content. Some services may not implement this endpoint.
- `model-consult --local-only` excludes all providers not explicitly marked local. At present, the bundled local provider is Ollama restricted to `127.0.0.1`.
- The CLI does not auto-discover paid cloud resources, create accounts, launch jobs, or authorize spending.

## Reproducible release build

From the repository root, run `python scripts/build_release.py`. The script reruns the test suite, byte-compilation, and CLI help check; writes `RELEASE_MANIFEST.json` with SHA-256 hashes for included source files; creates a clean ZIP outside the repository; and verifies ZIP integrity. Runtime SQLite databases, credentials, caches, and compiled bytecode are excluded.
