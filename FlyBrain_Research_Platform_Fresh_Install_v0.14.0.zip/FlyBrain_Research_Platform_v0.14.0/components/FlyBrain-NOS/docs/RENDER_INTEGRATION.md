# Render integration

FlyBrain-NOS includes a read-only Render inventory adapter. It normalizes the
workspace/service/workflow/database/Key Value observations into evidence-aware
capability states and provides a deployment guard. The adapter does not call
Render APIs directly and does not provision resources.

## Recommended deployment topology

- **Render Web Service**: optional HTTPS API/control endpoint for status and
  collaboration message exchange. Keep research compute out of the web process.
- **Render Workflow**: bounded asynchronous tasks (metadata validation,
  research orchestration, result packaging). Separate independent task units.
- **Render Key Value**: optional queue/coordination layer only after a workload
  needs it; retain SQLite for portable local mode.
- **Render Postgres**: optional shared collaboration/catalog store once multiple
  independent instances need concurrent access. SQLite remains local fallback.
- **Persistent disk/object storage**: keep large connectome payloads and durable
  artifacts outside ephemeral service filesystems; record immutable checksums.

## Security and scientific-integrity gates

1. Secrets are configured in Render's environment/secret UI, never committed,
   placed in the repository URL, or written to logs.
2. Keep a local-only mode and explicit data-egress policy. Do not transmit raw
   research datasets unless the data classification permits it.
3. Treat incoming tasks and model outputs as untrusted data. No generated code
   or shell command is auto-executed.
4. Record task ID, provider, software version, input/output checksums, timestamps,
   evidence class, cost metadata, and reviewer outcome.
5. Use idempotency keys, bounded retries, timeouts, cancellation, and resource
   quotas for all remote tasks.
6. Do not provision or deploy until repository access, runtime secrets, an
   explicit deployment authorization, and a spending budget are all confirmed.

## Current connection status

The Render account inventory was queried on 2026-11-16. One workspace was
accessible; the workspace returned no services, no workflows, no Postgres
instances, and no Key Value instances. This proves control-plane visibility,
not a running deployment. The first deployment still requires an accessible
Git repository URL and explicit review/approval.
