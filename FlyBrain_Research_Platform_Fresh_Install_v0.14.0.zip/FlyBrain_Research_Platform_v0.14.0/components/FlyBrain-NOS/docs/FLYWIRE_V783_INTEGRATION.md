# FlyWire FAFB v783 source integration

## Verified remote metadata (16 Nov 2026)

A public Hugging Face packaging repository was inspected: `SLOP011/flywire-fafb-connectome`.
Its card reports 139,255 proofread neurons, 15,091,983 directed neuron pairs at >=1 synapse,
2,700,513 directed pairs at >=5 synapses, 79 neuropils, and two Parquet files:
`connections.parquet` (473,692,168 bytes) and `nodes.parquet` (2,900,707 bytes).
The remote dataset preview was inspected (five rows). No complete Parquet payload was downloaded
or imported into this release.

## Upstream provenance and attribution

- Connectivity: FlyWire v783 release, Zenodo DOI `10.5281/zenodo.10676866`.
- Neuron annotations: Schlegel et al. 2024, DOI `10.1038/s41586-024-07686-5`.
- The package declares `CC-BY-4.0`; verify upstream file-specific terms before redistribution.
- The package is a third-party repackaging and is not affiliated with the FlyWire Consortium.

## Import API

`flybrain_os.flywire.iter_flywire_edges_csv` streams CSV rows using exact source fields:
`pre`, `post`, `syn_count`, `gaba`, `ach`, `glut`, `oct`, `ser`, `da`.
`iter_flywire_edges_parquet` streams Parquet batches and requires optional `pyarrow`.
`iter_flywire_nodes_csv` maps node annotations while preserving `root_id` as text.
Predicted `top_nt` remains `transmitter_prediction` and is explicitly marked unverified.

The six NT columns are probabilities, not synaptic efficacies or measured synaptic signs.
Synapse counts remain observed structural counts; they are never silently used as functional weights.

## Deferred operations

The full 476.6 MB Parquet package has not been downloaded. Remote Hugging Face Jobs are
available in the authenticated account context but are billed per minute; current public
pricing lists CPU Basic at $0.01/hour. No remote job was launched and no charge was incurred.
A full import/graph analysis should run only after a zero-cost compute allowance is confirmed
or the account owner explicitly approves the estimated spend. See the Hugging Face Jobs pricing
page: https://huggingface.co/docs/hub/en/jobs-pricing.


## Reproducible acquisition and full-data QA

After installing `flybrain-nos[hub,parquet]`, download the package explicitly:

```bash
python scripts/fetch_flywire.py --output data/flywire_fafb_v783 --revision <pinned-hub-commit>
python scripts/analyze_flywire_parquet.py --data-dir data/flywire_fafb_v783
```

The first script records SHA-256 hashes and the selected Hub revision. The second streams
Parquet batches and reports structural degree/count summaries, class counts, and probability
vector QA. It does not infer functional circuits or train a model. Do not use `main` for a
reproducible publication; supply a pinned Hub commit after checking it.
