# Annotation ingestion and research catalog

## Data model

Each neuron annotation is keyed by `(dataset, snapshot, root_id)`. The root ID is always serialized as a string. Annotations carry a record-level evidence class and source reference; individual field semantics remain explicit in their names. `transmitter_prediction` is not equivalent to `transmitter_verified`.

Supported optional annotation fields: `cell_type`, `class`, `super_class`, `hemibrain_type`, `side`, `neuropils`, `transmitter_prediction`, `transmitter_confidence`, `transmitter_verified`, `confidence`, `source_reference`, `source_name`, `source_url`, `annotation_version`, and `notes`.

Unknown fields, duplicate keys within an import, invalid evidence classes, and confidence values outside `[0,1]` are rejected. Replacing an existing catalog key requires an explicit CLI flag.

## Persistence

The JSONL output is a portable normalized export. SQLite provides local indexed storage for annotations and circuit candidate records. Dataset and snapshot are part of every primary key or candidate record; root IDs are not assumed stable across snapshots.

## Boundaries

This is data governance and cataloguing, not biological interpretation. It does not infer cell type, neurotransmitter, synaptic sign, efficacy, physiology, or function. Source labels and evidence classes must reflect the actual upstream source; the software cannot independently verify a publisher's claims.
