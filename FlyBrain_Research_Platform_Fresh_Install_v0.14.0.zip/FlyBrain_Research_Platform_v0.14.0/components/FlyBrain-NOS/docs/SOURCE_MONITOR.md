# Public-source update monitor (0.5.0)

FlyBrain-NOS can monitor public information pages independently of a ChatGPT automation. The monitor is a local command-line component, uses Python's standard library, and persists baselines/HTTP validators in SQLite.

## Run

```bash
python -m flybrain_os.cli monitor-sources \
  --config flybrain_os/monitor_sources.json \
  --state data/source-monitor.sqlite \
  --report data/source-monitor-report.json
```

Schedule this command on the host that runs FlyBrain-NOS (for example, with the host OS task scheduler). The project does not silently install a cron job or background service. A first run creates baselines; later runs report changed pages. HTTP 304 responses are treated as unchanged. Errors are reported per source and do not become claims that no update exists.

## Sources

The default configuration includes the FlyWire Codex news page, Codex dataset catalog, FlyWire public-release/license guidance, and the BANC/Codex project repositories. These are page-level signals, not a complete guarantee that every downloadable data artifact has been checked. Add official data-release indexes or feeds to the JSON config as their stable endpoints are verified.

## Safety and interpretation

- No dataset payloads are downloaded; responses are capped at 2 MB per source.
- No sign-in, API token, cloud job, or write action is used.
- First observation is a baseline, not a newly announced update.
- A page content change is a review signal, not proof of a new connectome snapshot. Inspect the linked primary source before updating the dataset registry.
- The monitor does not automatically change root IDs, overwrite datasets, or infer biological function.
- The default source list and last-check state remain local to the host.

## Optional systemd timer template

`deploy/flybrain-source-monitor.service.example` and `deploy/flybrain-source-monitor.timer.example` are templates for a Linux host. Edit the absolute project path and Python executable first, then install them as user units and enable the timer. This repository does not install or enable them automatically. The example checks daily at 18:00 in the host timezone.
