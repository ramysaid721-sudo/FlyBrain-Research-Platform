# NRC ↔ FlyBrain-NOS Collaboration Protocol 1.0

## Purpose

A bidirectional, auditable exchange protocol lets NeuroResearch Neural Core (NRC) and FlyBrain-NOS share research proposals, artifact manifests, test reports, lessons, and decisions. Each installation keeps its own local ledger and can continue operating offline.

## Message exchange

Each message contains a UUID, protocol version, sender, recipient, kind, UTC timestamp, JSON payload, and SHA-256 of the canonical payload. Messages are exported as JSONL and imported by the addressed peer. Re-imports are idempotently ignored. Invalid checksums, unsupported versions, unknown peers, and messages addressed to another system are rejected.

Supported kinds: `research_proposal`, `artifact_manifest`, `test_report`, `lesson`, `decision`.

## Trust and safety boundary

- Messages are inert data. Import never executes code, shell commands, notebooks, plugins, or remote jobs.
- An artifact manifest should include artifact name/version, source revision, SHA-256, license/attribution, test command, test totals, and evidence classification.
- A proposal is not an approved change. The receiving system records an explicit review (`accepted`, `rejected`, `deferred`) with reviewer and reason.
- A passing test report is evidence about the stated test suite, not proof of biological validity or general correctness.
- Do not send credentials, API tokens, personal data, or restricted datasets in messages.
- Production transport should use authenticated encrypted channels and peer identity verification; JSONL exchange is the portable offline baseline, not a network daemon.

## Operating model

1. Either peer may create a proposal or artifact manifest.
2. The other peer imports and validates the message.
3. The receiver performs independent tests in its own sandbox.
4. The receiver records a reasoned review and returns a test report/lesson.
5. The originating peer evaluates the response and may create a new revision.
6. Both systems retain their own ledgers and can export/import whenever connectivity is available.

## Current implementation boundary

FlyBrain-NOS implements the protocol, local SQLite ledger, JSONL export/import, checksum validation, deduplication, and review records. This repository does not contain the NRC source/runtime, so the NRC-side adapter and live bidirectional exchange have not yet been installed or exercised. NRC must implement the same schema before the two actual runtimes can exchange messages. The test suite uses two isolated local ledgers to validate the protocol mechanics; it does not claim that NRC itself was running.
