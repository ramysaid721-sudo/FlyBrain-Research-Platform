# Circuit extraction and temporal sandbox (0.3.0)

## Circuit extraction

`flybrain_os.circuits.extract_circuit` extracts a bounded subgraph from the ingested directed edge table. It supports:

- seed neuron IDs;
- incoming, outgoing, or bidirectional neighborhood expansion;
- hop radius;
- optional neuropil filters;
- minimum observed synapse-count threshold;
- maximum node count.

The output is an **anatomical/topological candidate**, not a named functional circuit. Metrics include node count, directed edge count, observed synapse total, mean in/out degree, and reciprocal-pair fraction. The metric `total_observed_synapse_count` is descriptive only. It is not a synaptic efficacy estimate.

Example:

```bash
flybrain-nos extract-circuit edges.csv \
  --seed 720575940000000001 --hops 2 --direction both \
  --neuropil AL --min-synapses 5 --max-nodes 1000 \
  --candidate-id candidate-olfactory-neighborhood --output candidate.json
```

## Temporal sandbox

`flybrain_os.temporal.simulate_steps` provides a deterministic discrete-time activation sandbox. Its `decay`, `gain`, `threshold`, and activation cap are explicit engineering parameters with synthetic status. The current implementation uses graph adjacency, not synapse counts, as a source of neighbor signals. It does not represent membrane potentials, spiking, neurotransmitter-specific signs, synaptic delays, conductance, neuromodulation, plasticity, or measured physiological parameters.

Do not use these outputs as biological predictions or evidence of actual fly-brain computation. The sandbox exists to test orchestration ideas and software interfaces while biological parameterization remains unresolved.
