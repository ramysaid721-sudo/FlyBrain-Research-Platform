# NRC-side bridge adapter

`flybrain_os.nrc_bridge.NRCBridge` is a small, portable adapter intended to be copied into the NRC integration layer when the NRC source tree is available. It uses the same versioned JSONL/SQLite collaboration protocol as FlyBrain-NOS.

```python
from flybrain_os.nrc_bridge import NRCBridge

bridge = NRCBridge("data/nrc-collaboration.sqlite")
bridge.publish("research_proposal", {
    "title": "Evaluate a new circuit-routing heuristic",
    "evidence": "hypothesis",
    "artifact_refs": [],
})
bridge.export_outbox("exchange/nrc-to-flybrain.jsonl")
bridge.import_inbox("exchange/flybrain-to-nrc.jsonl")
```

Received messages remain inert data. NRC must validate proposed code in its own isolated test environment and record a reasoned review before adoption. The adapter does not install itself into NRC or claim that NRC is running; the NRC source/runtime was not present in the development workspace at release time.
