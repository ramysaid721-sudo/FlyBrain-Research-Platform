# FlyBrain-NOS architecture (current source: 0.13.2)

This project is standalone. NeuroResearch Neural Core (NRC) may act as an external development/research environment, but is not imported at runtime and is not required to run FlyBrain-NOS.

## Connectome ingestion

- Dataset and snapshot are explicit, never inferred from a filename.
- Source URL, source name, license, attribution, import timestamp, and SHA-256 are recorded.
- Neuron/root IDs are strings; do not coerce them to floating point or fixed-width numeric types.
- Edges are directed presynaptic-to-postsynaptic observations.
- Synapse counts remain counts. They are not signed weights, efficacy, probabilities, or proof of functional influence.
- Neurotransmitter probabilities, if provided by a source, remain explicitly named probabilistic annotations.

## Evidence separation

Anatomical membership and connectivity are stored separately from proposed function. Functional labels require one of measured, inferred, assumed, or synthetic evidence and a source reference where applicable. Connectivity alone cannot establish a circuit's computational role.

## Runtime boundary

The current release validates and packages static edge data and includes two explicitly synthetic experimental runtimes: temporal activation propagation and generic leaky-integrate-and-fire (LIF). It does not infer synaptic signs or physiological parameters from connectome edge counts, and it does not autonomously execute external providers. Any future neural controller must be evaluated against explicit tasks and biological evidence.

## Operational source monitoring (0.5.0)

The `monitor-sources` CLI capability checks configured public FlyWire/Codex and project pages, tracks local content fingerprints and HTTP validators in SQLite, and emits JSON change reports. It is an operational utility within the FlyBrain-NOS package; it is not yet dispatched through a validated biological connectome controller. The connectome-based routing architecture remains a separate experimental layer until a real, licensed dataset is imported and its routing behavior is evaluated.


## Bidirectional research collaboration (0.6.0)

NRC and FlyBrain-NOS are now designed as independent peers with a shared, versioned exchange protocol. Each peer owns its runtime, local data, and SQLite collaboration ledger. Research proposals, artifact manifests, test reports, lessons, and decisions can move in both directions through checksum-verified JSONL messages. Import is idempotent and inert; it never runs received code. Each receiver performs independent validation and records a reasoned review. Offline operation is supported.

The current FlyBrain-NOS implementation and two-ledger protocol tests are complete. NRC's adapter has not been implemented or exercised because NRC source/runtime is absent from this workspace. Therefore this release establishes the contract and validates its mechanics, but does not claim a live NRC connection or mutual autonomous learning between running systems yet.

## URCAL resource boundary (0.11.0)

FlyBrain-NOS can optionally use its own `FlyBrainURCALClient`. The client
submits task metadata through an injected URCAL gateway using a FlyBrain-owned
principal and explicit resource policy. URCAL remains neutral: it does not
become the neural controller, infer circuit function, or share NRC state.
The HTTP transport uses only the Python standard library. FlyBrain remains usable without the URCAL package installed; cross-project integration tests require the URCAL source tree on `PYTHONPATH`.
