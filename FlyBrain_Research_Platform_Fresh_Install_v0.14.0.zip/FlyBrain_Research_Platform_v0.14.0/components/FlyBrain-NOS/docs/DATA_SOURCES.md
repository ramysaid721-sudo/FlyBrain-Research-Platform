# Data source notes

Preferred initial candidate: FlyWire FAFB snapshot v783, with BANC v888 evaluated as a separate dataset rather than silently mixed with FAFB. Dataset identity and snapshot must accompany every imported file.

Official Codex FAQ describes static snapshot downloads for bulk analysis and distinguishes Codex snapshots from live CAVE proofreading data. It also notes that root IDs can change across snapshots after edits, merges, or splits.

Before importing or redistributing any source file, verify the exact file's license and citation requirements from the source portal. FlyWire's public-release guidelines currently state CC BY-NC 4.0 for the public release; do not assume every derived or associated artifact has identical terms.

No connectome dataset is bundled or downloaded in this release. The data directory is intentionally empty pending selection of a specific snapshot and review of its license, size, and provenance.

## Current source discovery notes (checked 2026-11-16)

The official FlyWire Codex pages describe static, versioned snapshots and recommend downloading static data products for bulk analysis rather than issuing many live app queries. Its FAQ documents programmatic discovery through the Codex download portal and explains that connection tables may contain multiple rows for the same neuron pair when synapses occur in different neuropils. Root IDs are snapshot-specific. Predicted neurotransmitter labels and curated/verified annotations are distinct evidence streams and can disagree.

Relevant official references:
- Codex home and dataset selector: https://codex.flywire.ai/
- Codex FAQ and data-download/API guidance: https://codex.flywire.ai/faq
- Codex data source and attribution notes: https://codex.flywire.ai/about_flywire
- FlyWire connectome paper: https://www.nature.com/articles/s41586-024-07558-y

Snapshot note: the Codex pages surfaced during this build list FAFB v783 (139,255 neurons) and BANC v888 (158,262 neurons; May 20, 2026 release), among other datasets. Always query the official selector/portal immediately before import; do not hard-code these counts as permanent constants.

A Hugging Face search also surfaced a third-party FAFB v783 dataset package. It is not treated as an authoritative source or imported by this project. Prefer the official Codex download portal and preserve the precise per-file citation, license, checksum, and snapshot metadata.

This project has not downloaded or bundled any connectome dataset. No claim is made that these sources have been imported or independently validated here.
