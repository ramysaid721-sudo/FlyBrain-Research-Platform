## 0.13.3 - URCAL transport hardening

- Bounded URCAL HTTP response bodies to 1 MiB and reject malformed JSON responses.
- Stopped echoing arbitrary HTTP error response bodies in exceptions to reduce secret leakage.
- Validate base URLs, task identifiers, payload shape, capabilities, cost, quota and timeout before submission.
- Added transport hardening regression tests.

## 0.13.2 - Standalone test and dependency boundary correction

- Removed the misleading optional PyPI dependency on `urcal`; FlyBrain's HTTP transport does not import the URCAL package.
- Made the cross-project WSGI test skip only its URCAL-dependent case when URCAL source is not installed or exposed on `PYTHONPATH`.
- Added a dedicated `test` extra for pytest and clarified standalone versus integrated test execution.
- Updated architecture documentation to accurately describe the current synthetic LIF and temporal runtimes.

## 0.13.1 - Packaging metadata correction

- Restricted setuptools package discovery to `flybrain_os*`, preventing accidental treatment of data/deploy directories as Python packages.
- Verified wheel construction for the release package.

## 0.13.0 - Independent URCAL HTTP transport

- Added a FlyBrain-owned HTTP client for the authenticated URCAL API; no URCAL Python import is required for remote integration.
- Added bearer-token handling, bounded request timeout, idempotency keys and safe error handling.
- Enforced HTTPS for non-loopback endpoints; plain HTTP is accepted only for local development.
- Added end-to-end local WSGI integration tests against URCAL's job API.
- FlyBrain and URCAL retain independent configuration and identities.

## 0.12.0 - Experimental spiking neural runtime

- Added a deterministic leaky-integrate-and-fire (LIF) simulation engine with explicit membrane, refractory, input-current and signed synaptic-weight parameters.
- Added voltage traces, spike events and per-neuron spike counts for reproducible experiments.
- Kept the model explicitly synthetic and uncalibrated; connectome synapse counts are not silently converted into physiological weights.
- Added tests for deterministic dynamics, spike propagation, validation and resting-state behavior.
- No claim of biological equivalence or connectome-derived decision advantage.

## 0.11.0 - URCAL client boundary and neural-runtime status

- Added an optional FlyBrain-owned URCAL client with independent task policy, caller identity, and idempotency keys.
- Added explicit neural-runtime status documentation separating anatomical connectome processing from synthetic temporal propagation and biologically validated simulation.
- No NRC source/runtime was bundled or integrated; the existing NRC bridge remains a portable protocol adapter only.

## 0.10.0 - Render Integration Foundation

- Added read-only Render inventory normalization and evidence-aware capability states.
- Added deployment guard requiring repository, branch, secrets, explicit authorization, and approved budget.
- Added Render architecture/security/scientific-integrity deployment guidance.
- No cloud resources provisioned and no remote jobs executed.

# Changelog

## 0.9.0 — FlyWire FAFB v783 source integration

- Added a provenance-labelled FlyWire FAFB v783 source specification with explicit source DOIs, license, node/edge counts, and neuropil count.
- Added streaming CSV and optional PyArrow Parquet adapters for the published `pre/post/syn_count` edge schema.
- Added node-annotation mapping that preserves 64-bit root IDs as strings and keeps predicted neurotransmitters explicitly unverified.
- Separated evidence for observed structural edges from inferred neurotransmitter classifications.
- Added source documentation and tests for schema validation, 64-bit ID preservation, probability checks, duplicate IDs, and local checksum generation.
- Verified remote metadata and five sample rows via Hugging Face; full Parquet files have not been downloaded or imported.
- No cloud compute jobs or paid inference were launched.


## 0.8.0 — Provider API modernization and privacy controls

- Added native Responses API request/response handling for OpenAI and xAI presets.
- Retained Chat Completions adapters for Hugging Face, Ollama, and other compatible providers.
- Added safe provider metadata health checks via `model-provider-check`; diagnostics never return credentials.
- Added `model-consult --local-only` and explicit privacy-transfer reporting.
- Added tests for Responses API parsing, provider checks, and local-only isolation.
- Updated configuration, API, privacy, and operating-boundary documentation.
- No external provider calls were made during this build; no credentials or paid services were used.

## 0.4.0 — Annotation Catalog

- Added evidence-aware neuron annotation ingestion from CSV and JSON.
- Added strict field validation, confidence bounds, duplicate detection, and snapshot-scoped identity.
- Kept predicted neurotransmitter annotations distinct from verified transmitter fields.
- Added portable JSONL annotation export.
- Added local SQLite research catalog for neuron annotations and extracted circuit candidates.
- Added CLI commands `import-annotations` and `catalog-stats`; extended `extract-circuit` with optional catalog registration.
- Added documentation and automated tests for import, persistence, snapshot isolation, and CLI workflow.
- No real connectome dataset was downloaded or imported in this release.

## 0.5.0 — Local source update monitor

- Added a configurable public-source monitor with SQLite baselines, SHA-256 content fingerprints, HTTP ETag/Last-Modified validators, and concise change excerpts.
- Added a default source list for FlyWire Codex news/catalog and release guidance, plus BANC and Codex project repositories.
- Added `monitor-sources` CLI command and JSON reports.
- The monitor checks source pages only; it does not download large connectome datasets, use cloud services, or modify imported research data.


## 0.6.0 — Bidirectional collaboration protocol

- Added versioned NRC ↔ FlyBrain-NOS message schema and local SQLite collaboration ledger.
- Added checksum validation, idempotent JSONL import/export, sender/recipient validation, and append-only review records.
- Added CLI commands `collab-send`, `collab-export`, `collab-import`, `collab-stats`, and `collab-review`.
- Added trust-boundary documentation: exchanged payloads are inert and never auto-executed.
- Added isolated two-peer tests for round-trip exchange, deduplication, tampering, invalid routing, and reviews.
- NRC runtime integration remains pending because NRC source/runtime is not present in this workspace.


## 0.7.0 — Multi-model research hub

- Added provider discovery for OpenAI, xAI/Grok, Hugging Face, OpenRouter, Ollama, Groq, Together, Fireworks, DeepSeek, Mistral, Gemini, and custom OpenAI-compatible endpoints.
- Added parallel multi-model consultation with SQLite audit records.
- Added task workflow planner for proposal, independent critique, and synthesis.
- Added local CPU/RAM/GPU/scheduler inventory without credential disclosure.
- Added CLI commands `model-hub-status`, `model-task-plan`, and `model-consult`.
- Provider calls remain opt-in and require user-managed environment credentials; model outputs are never executed.


## 0.7.1 — NRC bridge adapter

- Added a portable NRC-side adapter around the versioned collaboration protocol.
- Added round-trip tests for NRC-to-FlyBrain and FlyBrain-to-NRC message exchange.
- Documented deployment boundary: adapter is ready, but NRC runtime integration remains pending source/runtime availability.
