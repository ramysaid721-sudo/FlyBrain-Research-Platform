"""Auditable, bidirectional collaboration protocol for NRC and FlyBrain-NOS.

Messages are inert data. Importing a proposal never executes code or commands.
"""
from __future__ import annotations
import hashlib, json, sqlite3, uuid
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Iterable

PROTOCOL_VERSION = "1.0"
PEERS = {"nrc", "flybrain-nos"}
KINDS = {"research_proposal", "artifact_manifest", "test_report", "lesson", "decision"}
REVIEWS = {"accepted", "rejected", "deferred"}

SCHEMA = """
CREATE TABLE IF NOT EXISTS collaboration_messages (
 message_id TEXT PRIMARY KEY, protocol_version TEXT NOT NULL,
 sender TEXT NOT NULL, recipient TEXT NOT NULL, kind TEXT NOT NULL,
 created_at TEXT NOT NULL, payload_json TEXT NOT NULL, payload_sha256 TEXT NOT NULL,
 imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(sender, message_id));
CREATE TABLE IF NOT EXISTS collaboration_reviews (
 review_id TEXT PRIMARY KEY, message_id TEXT NOT NULL,
 reviewer TEXT NOT NULL, outcome TEXT NOT NULL, reason TEXT NOT NULL,
 created_at TEXT NOT NULL, FOREIGN KEY(message_id) REFERENCES collaboration_messages(message_id));
CREATE INDEX IF NOT EXISTS idx_collab_recipient ON collaboration_messages(recipient, created_at);
CREATE INDEX IF NOT EXISTS idx_collab_kind ON collaboration_messages(kind);
"""

class CollaborationError(ValueError): pass

def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))

def _digest(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()

def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

class CollaborationLedger:
    """Local append-only message ledger with explicit review records."""
    def __init__(self, path: str | Path, system_id: str):
        if system_id not in PEERS: raise CollaborationError(f"unknown system_id: {system_id}")
        self.path=Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        self.system_id=system_id
        with self.connect() as db: db.executescript(SCHEMA)

    def connect(self):
        db=sqlite3.connect(self.path); db.execute("PRAGMA foreign_keys=ON"); return db

    def create_message(self, recipient: str, kind: str, payload: dict[str, Any], message_id: str | None=None) -> dict:
        if recipient not in PEERS or recipient == self.system_id: raise CollaborationError("recipient must be the other registered system")
        if kind not in KINDS: raise CollaborationError(f"unsupported message kind: {kind}")
        if not isinstance(payload, dict): raise CollaborationError("payload must be a JSON object")
        message={"message_id":message_id or str(uuid.uuid4()), "protocol_version":PROTOCOL_VERSION,
                 "sender":self.system_id,"recipient":recipient,"kind":kind,"created_at":_utcnow(),
                 "payload":payload,"payload_sha256":_digest(payload)}
        self._validate(message)
        with self.connect() as db:
            db.execute("INSERT INTO collaboration_messages(message_id,protocol_version,sender,recipient,kind,created_at,payload_json,payload_sha256) VALUES(?,?,?,?,?,?,?,?)",
                       (message["message_id"],message["protocol_version"],message["sender"],message["recipient"],message["kind"],message["created_at"],_canonical(payload),message["payload_sha256"]))
        return message

    @staticmethod
    def _validate(message: dict) -> None:
        required={"message_id","protocol_version","sender","recipient","kind","created_at","payload","payload_sha256"}
        if set(message) != required: raise CollaborationError("message fields do not match protocol schema")
        if message["protocol_version"] != PROTOCOL_VERSION: raise CollaborationError("unsupported protocol version")
        if message["sender"] not in PEERS or message["recipient"] not in PEERS or message["sender"] == message["recipient"]: raise CollaborationError("invalid sender/recipient")
        if message["kind"] not in KINDS or not isinstance(message["payload"],dict): raise CollaborationError("invalid kind or payload")
        if _digest(message["payload"]) != message["payload_sha256"]: raise CollaborationError("payload checksum mismatch")

    def export_jsonl(self, path: str | Path, *, recipient: str | None=None) -> int:
        query="SELECT message_id,protocol_version,sender,recipient,kind,created_at,payload_json,payload_sha256 FROM collaboration_messages"
        args=()
        if recipient:
            if recipient not in PEERS or recipient == self.system_id: raise CollaborationError("invalid recipient filter")
            query += " WHERE recipient=?"; args=(recipient,)
        query += " ORDER BY created_at,message_id"
        with self.connect() as db: rows=db.execute(query,args).fetchall()
        out=Path(path); out.parent.mkdir(parents=True,exist_ok=True)
        with out.open("w",encoding="utf-8") as f:
            for r in rows:
                obj={"message_id":r[0],"protocol_version":r[1],"sender":r[2],"recipient":r[3],"kind":r[4],"created_at":r[5],"payload":json.loads(r[6]),"payload_sha256":r[7]}
                f.write(_canonical(obj)+"\n")
        return len(rows)

    def import_jsonl(self, path: str | Path) -> dict:
        imported=duplicates=0; errors=[]
        with Path(path).open(encoding="utf-8") as f:
            for line_no,line in enumerate(f,1):
                if not line.strip(): continue
                try:
                    msg=json.loads(line); self._validate(msg)
                    if msg["recipient"] != self.system_id: raise CollaborationError("message is not addressed to this system")
                    with self.connect() as db:
                        cur=db.execute("INSERT OR IGNORE INTO collaboration_messages(message_id,protocol_version,sender,recipient,kind,created_at,payload_json,payload_sha256) VALUES(?,?,?,?,?,?,?,?)",
                            (msg["message_id"],msg["protocol_version"],msg["sender"],msg["recipient"],msg["kind"],msg["created_at"],_canonical(msg["payload"]),msg["payload_sha256"]))
                        if cur.rowcount: imported += 1
                        else: duplicates += 1
                except Exception as exc: errors.append({"line":line_no,"error":str(exc)})
        return {"imported":imported,"duplicates":duplicates,"errors":errors,"executed_payloads":0}

    def review(self, message_id: str, outcome: str, reviewer: str, reason: str) -> str:
        if outcome not in REVIEWS: raise CollaborationError("outcome must be accepted, rejected, or deferred")
        if not reviewer.strip() or not reason.strip(): raise CollaborationError("reviewer and reason are required")
        rid=str(uuid.uuid4())
        with self.connect() as db:
            exists=db.execute("SELECT 1 FROM collaboration_messages WHERE message_id=?",(message_id,)).fetchone()
            if not exists: raise CollaborationError("unknown message_id")
            db.execute("INSERT INTO collaboration_reviews VALUES(?,?,?,?,?,?)",(rid,message_id,reviewer,outcome,reason,_utcnow()))
        return rid

    def stats(self) -> dict:
        with self.connect() as db:
            messages=db.execute("SELECT COUNT(*) FROM collaboration_messages").fetchone()[0]
            reviews=db.execute("SELECT COUNT(*) FROM collaboration_reviews").fetchone()[0]
            by_kind={k:n for k,n in db.execute("SELECT kind,COUNT(*) FROM collaboration_messages GROUP BY kind")}
            by_outcome={k:n for k,n in db.execute("SELECT outcome,COUNT(*) FROM collaboration_reviews GROUP BY outcome")}
        return {"system_id":self.system_id,"protocol_version":PROTOCOL_VERSION,"messages":messages,"reviews":reviews,"messages_by_kind":by_kind,"reviews_by_outcome":by_outcome,"automatic_code_execution":False}
