"""Experimental discrete-time signal propagation over an extracted graph.

This is an engineering sandbox, not a biological neural simulation. Values are
nonnegative routing activations; synapse counts are not treated as synaptic
weights. All dynamics parameters are explicit synthetic assumptions.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True)
class TemporalConfig:
    decay: float = 0.35
    gain: float = 0.25
    threshold: float = 0.05
    max_activation: float = 1.0

    def validate(self):
        if not 0 <= self.decay <= 1: raise ValueError("decay must be in [0,1]")
        if self.gain < 0: raise ValueError("gain must be >= 0")
        if self.threshold < 0: raise ValueError("threshold must be >= 0")
        if self.max_activation <= 0: raise ValueError("max_activation must be > 0")


def simulate_steps(neuron_ids: list[str], directed_pairs: list[tuple[str, str]],
                   initial: Mapping[str, float], steps: int,
                   config: TemporalConfig = TemporalConfig()) -> list[dict[str, float]]:
    """Run transparent synthetic signal propagation for a fixed step count."""
    config.validate()
    if steps < 0: raise ValueError("steps must be >= 0")
    nodes = set(neuron_ids)
    if any(a not in nodes or b not in nodes for a, b in directed_pairs):
        raise ValueError("all edge endpoints must exist in neuron_ids")
    state = {n: float(initial.get(n, 0.0)) for n in nodes}
    if any(v < 0 or v > config.max_activation for v in state.values()):
        raise ValueError("initial activation outside configured range")
    incoming = {n: [] for n in nodes}
    for a, b in directed_pairs: incoming[b].append(a)
    history = [{k: state[k] for k in sorted(state)}]
    for _ in range(steps):
        nxt = {}
        for node in nodes:
            drive = sum(state[src] for src in incoming[node])
            value = config.decay * state[node] + config.gain * drive
            if value < config.threshold: value = 0.0
            nxt[node] = min(config.max_activation, value)
        state = nxt
        history.append({k: state[k] for k in sorted(state)})
    return history
