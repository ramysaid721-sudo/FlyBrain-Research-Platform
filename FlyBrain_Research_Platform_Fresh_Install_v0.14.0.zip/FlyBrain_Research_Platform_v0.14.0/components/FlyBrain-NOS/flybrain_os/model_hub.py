"""Multi-model consultation and local resource discovery.

Providers are opt-in via environment variables. No API keys are stored in the
repository, logs, reports, or collaboration packets. Model output is inert data.
"""
from __future__ import annotations
import concurrent.futures
import json
import os
import platform
import shutil
import sqlite3
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

@dataclass(frozen=True)
class Provider:
    provider_id: str
    endpoint: str
    model: str
    key_env: str
    local: bool = False
    api_mode: str = "chat"  # chat or responses

DEFAULTS = {
    "openai": ("https://api.openai.com/v1", "OPENAI_MODEL", "OPENAI_API_KEY", False, "responses"),
    "xai": ("https://api.x.ai/v1", "XAI_MODEL", "XAI_API_KEY", False, "responses"),
    "openrouter": ("https://openrouter.ai/api/v1", "OPENROUTER_MODEL", "OPENROUTER_API_KEY", False, "chat"),
    "huggingface": ("https://router.huggingface.co/v1", "HF_MODEL", "HF_TOKEN", False, "chat"),
    "ollama": ("http://127.0.0.1:11434/v1", "OLLAMA_MODEL", "", True, "chat"),
    "groq": ("https://api.groq.com/openai/v1", "GROQ_MODEL", "GROQ_API_KEY", False, "chat"),
    "together": ("https://api.together.xyz/v1", "TOGETHER_MODEL", "TOGETHER_API_KEY", False, "chat"),
    "fireworks": ("https://api.fireworks.ai/inference/v1", "FIREWORKS_MODEL", "FIREWORKS_API_KEY", False, "chat"),
    "deepseek": ("https://api.deepseek.com/v1", "DEEPSEEK_MODEL", "DEEPSEEK_API_KEY", False, "chat"),
    "mistral": ("https://api.mistral.ai/v1", "MISTRAL_MODEL", "MISTRAL_API_KEY", False, "chat"),
    "gemini": ("https://generativelanguage.googleapis.com/v1beta/openai", "GEMINI_MODEL", "GEMINI_API_KEY", False, "chat"),
}

class ModelHubError(ValueError): pass

def discover_providers(environ=None) -> list[Provider]:
    env = os.environ if environ is None else environ
    out=[]
    for pid,(default_url,model_env,key_env,local,api_mode) in DEFAULTS.items():
        endpoint=env.get(f"{pid.upper()}_BASE_URL", default_url).rstrip("/")
        model=env.get(model_env, "").strip()
        key=env.get(key_env, "").strip() if key_env else ""
        # Ollama is listed as a candidate even without a model; it is not probed here.
        if model and (key or local): out.append(Provider(pid,endpoint,model,key_env,local,api_mode))
    extra = env.get("FLYBRAIN_EXTRA_PROVIDERS", "").strip()
    if extra:
        try: entries=json.loads(extra)
        except json.JSONDecodeError as exc: raise ModelHubError("FLYBRAIN_EXTRA_PROVIDERS must be valid JSON") from exc
        if not isinstance(entries,list): raise ModelHubError("custom providers must be a JSON list")
        for item in entries:
            if not isinstance(item,dict) or not all(isinstance(item.get(k),str) and item[k].strip() for k in ("id","endpoint","model","key_env")):
                raise ModelHubError("each custom provider needs id, endpoint, model, and key_env")
            if not env.get(item["key_env"],"").strip(): continue
            mode=item.get("api_mode", "chat")
            if mode not in {"chat", "responses"}: raise ModelHubError("custom provider api_mode must be chat or responses")
            out.append(Provider(item["id"],item["endpoint"].rstrip("/"),item["model"],item["key_env"],False,mode))
    ids=[p.provider_id for p in out]
    if len(ids)!=len(set(ids)): raise ModelHubError("provider IDs must be unique")
    return out

def resource_inventory() -> dict:
    try:
        mem_total = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    except (ValueError, OSError, AttributeError): mem_total = None
    schedulers={k:os.environ[k] for k in ("SLURM_JOB_ID","PBS_JOBID","LSB_JOBID") if os.environ.get(k)}
    gpus=[]
    if shutil.which("nvidia-smi"):
        import subprocess
        try:
            p=subprocess.run(["nvidia-smi","--query-gpu=name,memory.total","--format=csv,noheader"],capture_output=True,text=True,timeout=3,check=False)
            if p.returncode==0: gpus=[x.strip() for x in p.stdout.splitlines() if x.strip()]
        except Exception: pass
    return {"platform":platform.platform(),"python":platform.python_version(),"cpu_count":os.cpu_count(),
            "memory_total_bytes":mem_total,"gpu_inventory":gpus,"scheduler_environment":schedulers,
            "cuda_visible_devices":os.environ.get("CUDA_VISIBLE_DEVICES"),
            "provider_credentials_exposed":False}

def task_plan(task: str, roles: tuple[str,...] = ("proposer","independent_critic","synthesizer")) -> dict:
    if not task.strip(): raise ModelHubError("task must not be empty")
    if len(task)>20000: raise ModelHubError("task exceeds 20000 characters")
    valid={"proposer","independent_critic","domain_reviewer","synthesizer"}
    if not roles or any(r not in valid for r in roles): raise ModelHubError("invalid role list")
    return {"task":task,"workflow":[{"role":r,"instruction":{
        "proposer":"Develop an answer and list assumptions, evidence, and uncertainties.",
        "independent_critic":"Independently challenge the proposal; identify counterexamples, missing evidence, and tests.",
        "domain_reviewer":"Review domain validity and distinguish established facts from hypotheses.",
        "synthesizer":"Compare outputs; preserve disagreements and propose testable next steps."}[r]} for r in roles],
        "policy":"Do not execute generated code or treat model consensus as evidence."}

def _extract_response(data: dict, api_mode: str) -> str:
    if api_mode == "chat":
        return str(data["choices"][0]["message"]["content"])
    if isinstance(data.get("output_text"), str): return data["output_text"]
    chunks=[]
    for item in data.get("output", []):
        for content in item.get("content", []):
            if content.get("type") in {"output_text", "text"} and isinstance(content.get("text"), str):
                chunks.append(content["text"])
    if chunks: return "\n".join(chunks)
    raise KeyError("output_text")

def _post_chat(provider: Provider, prompt: str, *, timeout: int=45, opener: Callable=urllib.request.urlopen) -> str:
    if not provider.model: raise ModelHubError("provider model is not configured")
    if provider.api_mode not in {"chat", "responses"}: raise ModelHubError("unsupported provider API mode")
    if not (provider.endpoint.startswith("https://") or (provider.local and provider.endpoint.startswith("http://127.0.0.1"))):
        raise ModelHubError("remote endpoints must use HTTPS; local Ollama must use loopback HTTP")
    token=os.environ.get(provider.key_env,"") if provider.key_env else ""
    if not provider.local and not token: raise ModelHubError(f"missing credential environment variable: {provider.key_env}")
    if timeout < 1 or timeout > 180: raise ModelHubError("timeout must be between 1 and 180 seconds")
    if provider.api_mode == "responses":
        path="/responses"; payload={"model":provider.model,"input":prompt}
    else:
        path="/chat/completions"; payload={"model":provider.model,"messages":[{"role":"user","content":prompt}],"temperature":0.2}
    body=json.dumps(payload).encode(); headers={"Content-Type":"application/json"}
    if token: headers["Authorization"]="Bearer "+token
    req=urllib.request.Request(provider.endpoint+path,data=body,headers=headers,method="POST")
    try:
        with opener(req,timeout=timeout) as resp:
            raw=resp.read(2_000_001)
            if len(raw)>2_000_000: raise ModelHubError("provider response exceeded 2 MB safety limit")
            data=json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise ModelHubError(f"{provider.provider_id} HTTP {e.code}") from None
    except ModelHubError: raise
    except Exception as e:
        raise ModelHubError(f"{provider.provider_id} request failed: {type(e).__name__}") from None
    try: return _extract_response(data, provider.api_mode)
    except (KeyError,IndexError,TypeError): raise ModelHubError(f"{provider.provider_id} returned an unrecognized response") from None

def check_provider(provider: Provider, *, timeout: int=8, opener: Callable=urllib.request.urlopen) -> dict:
    """Low-cost metadata probe; never sends research prompts or prints credentials."""
    if not (provider.endpoint.startswith("https://") or (provider.local and provider.endpoint.startswith("http://127.0.0.1"))):
        return {"provider":provider.provider_id,"status":"rejected_insecure_endpoint"}
    token=os.environ.get(provider.key_env,"") if provider.key_env else ""
    if not provider.local and not token: return {"provider":provider.provider_id,"status":"missing_credentials"}
    headers={"Accept":"application/json"}
    if token: headers["Authorization"]="Bearer "+token
    req=urllib.request.Request(provider.endpoint+"/models",headers=headers,method="GET")
    try:
        with opener(req,timeout=timeout) as resp:
            raw=resp.read(256_001)
            if len(raw)>256_000: return {"provider":provider.provider_id,"status":"response_too_large"}
            data=json.loads(raw.decode("utf-8"))
            ids=[str(x.get("id")) for x in data.get("data",[]) if isinstance(x,dict) and x.get("id")]
            return {"provider":provider.provider_id,"status":"reachable","configured_model_listed":provider.model in ids if ids else None,"models_count":len(ids)}
    except urllib.error.HTTPError as exc:
        return {"provider":provider.provider_id,"status":"http_error","http_status":exc.code}
    except Exception as exc:
        return {"provider":provider.provider_id,"status":"unreachable","error_type":type(exc).__name__}

class ModelConsultation:
    def __init__(self, db_path: str|Path):
        self.path=Path(db_path); self.path.parent.mkdir(parents=True,exist_ok=True)
        with sqlite3.connect(self.path) as db:
            db.execute("CREATE TABLE IF NOT EXISTS consultations (id INTEGER PRIMARY KEY, created_at TEXT, provider TEXT, model TEXT, role TEXT, status TEXT, response TEXT, error TEXT)")
    def consult(self, task: str, *, providers=None, timeout=45, caller: Callable|None=None, local_only: bool=False) -> dict:
        providers=list(discover_providers() if providers is None else providers)
        if local_only: providers=[p for p in providers if p.local]
        if not providers: return {"status":"no_providers_configured","results":[],"note":"Configure provider model names and credentials through environment variables; no secrets belong in project files."}
        plan=task_plan(task); call=caller or _post_chat
        prompts={"proposer":task+"\n\nReturn a reasoned proposal with assumptions, evidence needs, and uncertainties.",
                 "independent_critic":"Critically and independently review this research task. Find flaws, counterarguments, and validation tests:\n"+task,
                 "synthesizer":"Give an independent structured analysis of this task, likely approaches, risks, and tests:\n"+task}
        jobs=[]
        for i,p in enumerate(providers): jobs.append((p,("proposer","independent_critic","synthesizer")[i%3],prompts[("proposer","independent_critic","synthesizer")[i%3]]))
        results=[]
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(6,len(jobs),max(1,os.cpu_count() or 1))) as pool:
            futures={pool.submit(call,p,prompt,timeout=timeout): (p,role) for p,role,prompt in jobs}
            for fut,(p,role) in futures.items():
                try: results.append({"provider":p.provider_id,"model":p.model,"role":role,"status":"completed","response":fut.result()})
                except Exception as e: results.append({"provider":p.provider_id,"model":p.model,"role":role,"status":"error","error":str(e)})
        with sqlite3.connect(self.path) as db:
            for r in results: db.execute("INSERT INTO consultations(created_at,provider,model,role,status,response,error) VALUES(?,?,?,?,?,?,?)",
                (datetime.now(timezone.utc).isoformat(timespec="seconds"),r["provider"],r["model"],r["role"],r["status"],r.get("response"),r.get("error")))
        return {"status":"completed" if any(r["status"]=="completed" for r in results) else "all_providers_failed",
                "results":results,"plan":plan,"execution_policy":"responses are untrusted research inputs; no code execution; disagreement is retained",
                "privacy":{"local_only":local_only,"providers_receiving_task":[p.provider_id for p in providers],"external_data_transfer":any(not p.local for p in providers)}}
