"""FlyBrain-NOS-owned client for the neutral URCAL resource layer.

The client owns no URCAL provider credentials or global policy. A gateway
instance and caller identity are injected by the deployment environment.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, FrozenSet

@dataclass(frozen=True)
class FlyBrainTaskRequest:
    """Structural task contract; intentionally independent of URCAL imports."""
    task_id: str
    required_capabilities: FrozenSet[str]
    estimated_quota_units: float
    max_cost: float
    idempotency_key: str
    payload_digest: str
    timeout_seconds: float

@dataclass(frozen=True)
class FlyBrainTaskRequest:
    """Structural task contract; intentionally independent of URCAL imports."""
    task_id: str
    required_capabilities: FrozenSet[str]
    estimated_quota_units: float
    max_cost: float
    idempotency_key: str
    payload_digest: str
    timeout_seconds: float

@dataclass(frozen=True)
class FlyBrainResourcePolicy:
    required_capabilities: FrozenSet[str]
    max_cost: float = 0.0
    quota_units: float = 1.0
    timeout_seconds: float = 300.0

class FlyBrainURCALClient:
    def __init__(self, gateway: Any, principal: str, policy: FlyBrainResourcePolicy):
        if gateway is None or not principal: raise ValueError("gateway and principal are required")
        self._gateway=gateway
        self._principal=principal
        self._policy=policy

    def submit_research_job(self, task_id: str, payload: dict, *, idempotency_key: str | None=None):
        import hashlib, json
        digest=hashlib.sha256(json.dumps(payload,sort_keys=True,default=str).encode()).hexdigest()
        task=FlyBrainTaskRequest(task_id=task_id,required_capabilities=self._policy.required_capabilities,
                      estimated_quota_units=self._policy.quota_units,max_cost=self._policy.max_cost,
                      idempotency_key=idempotency_key or task_id,payload_digest=digest,
                      timeout_seconds=self._policy.timeout_seconds)
        return self._gateway.submit_job(self._principal,task,payload)

    def get_job(self, task_id: str):
        return self._gateway.get_job(self._principal,task_id)
