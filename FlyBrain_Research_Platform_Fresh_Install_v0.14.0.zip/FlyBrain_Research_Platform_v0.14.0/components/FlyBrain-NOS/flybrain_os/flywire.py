"""Evidence-aware adapters for the public FlyWire FAFB v783 release.

This module handles data interchange only. It does not infer physiology from
connectivity or promote predicted neurotransmitter labels to verified facts.
"""
from __future__ import annotations

import csv
import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterator

from .annotations import NeuronAnnotation
from .connectome import Edge, DatasetManifest, sha256_file

DATASET_REPO = "SLOP011/flywire-fafb-connectome"
DATASET_VERSION = "FAFB_v783"
DATASET_LICENSE = "CC-BY-4.0"
CONNECTIVITY_DOI = "10.5281/zenodo.10676866"
ANNOTATION_DOI = "10.1038/s41586-024-07686-5"
CONNECTIVITY_SOURCE = f"https://doi.org/{CONNECTIVITY_DOI}"
ANNOTATION_SOURCE = f"https://doi.org/{ANNOTATION_DOI}"
NEUROTRANSMITTER_COLUMNS = ("gaba", "ach", "glut", "oct", "ser", "da")
EXPECTED_EDGE_COLUMNS = ("pre", "post", "syn_count", *NEUROTRANSMITTER_COLUMNS)
EXPECTED_NODE_COLUMNS = (
    "root_id", "flow", "super_class", "cell_class", "cell_sub_class",
    "cell_type", "hemibrain_type", "hemilineages", "top_nt", "top_nt_conf",
    "side", "nerve", "vfb_id", "fbbt_id",
)


@dataclass(frozen=True)
class FlyWireDatasetSpec:
    repository: str = DATASET_REPO
    snapshot: str = DATASET_VERSION
    license: str = DATASET_LICENSE
    proofread_neurons: int = 139_255
    directed_pairs_ge1_synapse: int = 15_091_983
    directed_pairs_ge5_synapses: int = 2_700_513
    neuropils: int = 79
    connectivity_doi: str = CONNECTIVITY_DOI
    annotation_doi: str = ANNOTATION_DOI
    neurotransmitter_fields_are_probabilities: bool = True
    synapse_counts_are_physiological_weights: bool = False

    def validate(self) -> None:
        if self.license != "CC-BY-4.0":
            raise ValueError("unexpected license; re-check upstream terms")
        if self.proofread_neurons <= 0 or self.directed_pairs_ge1_synapse <= 0:
            raise ValueError("dataset counts must be positive")
        if self.directed_pairs_ge5_synapses > self.directed_pairs_ge1_synapse:
            raise ValueError("thresholded edge count cannot exceed all edge count")
        if self.synapse_counts_are_physiological_weights:
            raise ValueError("synapse counts must not be represented as physiological weights")


def flywire_manifest(local_source: str | Path, *, imported_at: str) -> DatasetManifest:
    """Build a manifest from a downloaded file; checksum is computed locally."""
    path = Path(local_source)
    if not path.is_file():
        raise FileNotFoundError(path)
    manifest = DatasetManifest(
        dataset="FlyWire FAFB",
        snapshot=DATASET_VERSION,
        source_name=path.name,
        source_url=f"https://huggingface.co/datasets/{DATASET_REPO}/resolve/main/{path.name}",
        source_sha256=sha256_file(path),
        license=DATASET_LICENSE,
        attribution=(
            "Dorkenwald et al. 2024, Nature, doi:10.1038/s41586-024-07558-y; "
            f"FlyWire connectivity source {CONNECTIVITY_DOI}; annotations {ANNOTATION_DOI}"
        ),
        imported_at=imported_at,
    )
    manifest.validate()
    return manifest


def _edge_from_row(row: dict[str, Any], row_number: int) -> Edge:
    missing = set(EXPECTED_EDGE_COLUMNS) - set(row)
    if missing:
        raise ValueError(f"missing FlyWire columns: {', '.join(sorted(missing))}")
    try:
        probabilities = {name: float(row[name]) for name in NEUROTRANSMITTER_COLUMNS}
        if not all(math.isfinite(v) and 0.0 <= v <= 1.0 for v in probabilities.values()):
            raise ValueError("neurotransmitter probabilities must be finite values in [0,1]")
        total = sum(probabilities.values())
        if abs(total - 1.0) > 0.025:
            raise ValueError(f"neurotransmitter probabilities sum to {total:.6f}, expected approximately 1")
        edge = Edge(
            source_id=str(row["pre"]).strip(),
            target_id=str(row["post"]).strip(),
            synapse_count=int(row["syn_count"]),
            neurotransmitter_probabilities=probabilities,
            evidence="measured",  # structural edge/count is observed in the released connectome
            neurotransmitter_evidence="inferred",  # NT probabilities are predictions, not verification
        )
        edge.validate()
        if edge.synapse_count < 1:
            raise ValueError("FlyWire edge rows must have at least one synapse")
        return edge
    except Exception as exc:
        raise ValueError(f"invalid FlyWire edge row {row_number}: {exc}") from exc


def iter_flywire_edges_csv(path: str | Path) -> Iterator[Edge]:
    """Stream FlyWire `pre/post/syn_count` CSV exports without float ID coercion."""
    with Path(path).open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        missing = set(EXPECTED_EDGE_COLUMNS) - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"missing FlyWire columns: {', '.join(sorted(missing))}")
        for line, row in enumerate(reader, start=2):
            yield _edge_from_row(row, line)


def iter_flywire_edges_parquet(path: str | Path, *, batch_size: int = 100_000) -> Iterator[Edge]:
    """Stream Parquet row groups/batches; requires optional `pyarrow` package."""
    if batch_size < 1:
        raise ValueError("batch_size must be positive")
    try:
        import pyarrow.parquet as pq
    except ImportError as exc:
        raise RuntimeError("Parquet import requires optional dependency: pip install pyarrow") from exc
    parquet = pq.ParquetFile(path)
    missing = set(EXPECTED_EDGE_COLUMNS) - set(parquet.schema.names)
    if missing:
        raise ValueError(f"missing FlyWire Parquet columns: {', '.join(sorted(missing))}")
    row_number = 1
    for batch in parquet.iter_batches(batch_size=batch_size, columns=list(EXPECTED_EDGE_COLUMNS)):
        for row in batch.to_pylist():
            row_number += 1
            yield _edge_from_row(row, row_number)


def iter_flywire_nodes_csv(
    path: str | Path, *, dataset: str = "FlyWire FAFB", snapshot: str = DATASET_VERSION
) -> Iterator[NeuronAnnotation]:
    """Stream node annotations, preserving root IDs and predicted NT status."""
    with Path(path).open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        missing = {"root_id", "super_class", "cell_class", "cell_type", "top_nt", "top_nt_conf"} - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"missing FlyWire node columns: {', '.join(sorted(missing))}")
        seen: set[str] = set()
        for line, row in enumerate(reader, start=2):
            root_id = str(row.get("root_id", "")).strip()
            if not root_id:
                raise ValueError(f"missing root_id at node CSV line {line}")
            if root_id in seen:
                raise ValueError(f"duplicate root_id at node CSV line {line}: {root_id}")
            seen.add(root_id)
            values: dict[str, Any] = {}
            mapping = {
                "flow": "flow", "super_class": "super_class", "cell_class": "class",
                "cell_sub_class": "cell_sub_class", "cell_type": "cell_type",
                "hemibrain_type": "hemibrain_type", "hemilineages": "hemilineages",
                "side": "side", "nerve": "nerve", "vfb_id": "vfb_id", "fbbt_id": "fbbt_id",
            }
            for source, target in mapping.items():
                value = row.get(source)
                if value not in (None, ""):
                    values[target] = value
            if row.get("top_nt") not in (None, ""):
                values["transmitter_prediction"] = row["top_nt"]
                values["transmitter_verified"] = False
            if row.get("top_nt_conf") not in (None, ""):
                values["transmitter_confidence"] = float(row["top_nt_conf"])
            record = NeuronAnnotation(
                root_id=root_id, dataset=dataset, snapshot=snapshot, values=values,
                evidence="inferred", source_reference=ANNOTATION_SOURCE,
            )
            record.validate()
            yield record


def write_flywire_source_record(output: str | Path) -> dict[str, Any]:
    """Write a compact, provenance-labelled record; does not claim local data import."""
    spec = FlyWireDatasetSpec()
    spec.validate()
    payload = {
        "status": "source_verified_metadata_only",
        "dataset": asdict(spec),
        "source_files": {
            "connections.parquet": {"bytes": 473_692_168, "rows": 15_091_983},
            "nodes.parquet": {"bytes": 2_900_707, "rows": 139_255},
        },
        "upstream_sources": [CONNECTIVITY_SOURCE, ANNOTATION_SOURCE],
        "local_data_downloaded": False,
        "neurotransmitter_probabilities_are_verified_measurements": False,
        "synapse_counts_are_weights": False,
    }
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    Path(output).write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return payload
