"""Render control-plane inventory and deployment-plan adapter.

This module is deliberately read-only: it does not provision, deploy, or start
remote workloads. Render MCP actions are invoked by the operator layer.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any, Mapping


@dataclass(frozen=True)
class RenderCapability:
    provider: str
    capability: str
    state: str
    evidence: str
    cost_risk: str
    notes: str


@dataclass(frozen=True)
class RenderInventory:
    workspace_id: str
    workspace_name: str
    services: tuple[Mapping[str, Any], ...] = ()
    workflows: tuple[Mapping[str, Any], ...] = ()
    postgres_instances: tuple[Mapping[str, Any], ...] = ()
    key_value_instances: tuple[Mapping[str, Any], ...] = ()
    checked_at: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "workspace_id": self.workspace_id,
            "workspace_name": self.workspace_name,
            "services": list(self.services),
            "workflows": list(self.workflows),
            "postgres_instances": list(self.postgres_instances),
            "key_value_instances": list(self.key_value_instances),
            "checked_at": self.checked_at,
        }


def inventory_from_render_responses(
    workspace: Mapping[str, Any],
    services: Any,
    workflows: Any,
    postgres: Any,
    key_value: Any,
) -> RenderInventory:
    """Normalize the Render MCP read responses without assuming API shape."""
    def rows(value: Any) -> tuple[Mapping[str, Any], ...]:
        if value is None:
            return ()
        if isinstance(value, Mapping):
            for key in ("items", "services", "instances", "data"):
                candidate = value.get(key)
                if isinstance(candidate, list):
                    return tuple(x for x in candidate if isinstance(x, Mapping))
            if not value:
                return ()
            return (value,)
        if isinstance(value, list):
            return tuple(x for x in value if isinstance(x, Mapping))
        return ()

    return RenderInventory(
        workspace_id=str(workspace.get("id", "")),
        workspace_name=str(workspace.get("name", "")),
        services=rows(services),
        workflows=rows(workflows),
        postgres_instances=rows(postgres),
        key_value_instances=rows(key_value),
        checked_at=datetime.now(timezone.utc).isoformat(),
    )


def capabilities(inventory: RenderInventory) -> list[RenderCapability]:
    """Translate inventory into explicit capability/evidence states."""
    return [
        RenderCapability("render", "control_plane_access", "authenticated",
                         "Render workspace listing returned an accessible workspace",
                         "none for inventory", "Read-only account inspection succeeded"),
        RenderCapability("render", "web_services", "available_not_provisioned" if not inventory.services else "resources_present",
                         f"{len(inventory.services)} service resource(s) returned",
                         "potential recurring cost on creation/use", "No resources are created by this adapter"),
        RenderCapability("render", "workflows", "available_not_provisioned" if not inventory.workflows else "resources_present",
                         f"{len(inventory.workflows)} workflow(s) returned",
                         "compute usage may be billable when runs execute",
                         "Workflow inventory is separate from running tasks"),
        RenderCapability("render", "postgres", "available_not_provisioned" if not inventory.postgres_instances else "resources_present",
                         f"{len(inventory.postgres_instances)} database(s) returned",
                         "storage and compute may be billable", "No database was created"),
        RenderCapability("render", "key_value", "available_not_provisioned" if not inventory.key_value_instances else "resources_present",
                         f"{len(inventory.key_value_instances)} instance(s) returned",
                         "instance plan may be billable", "No key-value service was created"),
    ]


def deployment_guard(*, repository_url: str | None, branch: str | None,
                     secrets_configured: bool, approval_received: bool,
                     budget_approved: bool) -> dict[str, Any]:
    """Return a non-executing readiness decision for a Render deployment."""
    blockers: list[str] = []
    if not repository_url:
        blockers.append("A repository URL accessible to Render is not configured")
    if not branch:
        blockers.append("A deployment branch is not configured")
    if not secrets_configured:
        blockers.append("Required runtime secrets are not configured in Render")
    if not approval_received:
        blockers.append("Explicit deployment approval has not been received")
    if not budget_approved:
        blockers.append("Cloud spending/budget has not been approved")
    return {
        "decision": "blocked" if blockers else "eligible_for_explicit_deployment_review",
        "blockers": blockers,
        "execution_performed": False,
        "policy": "No remote resource creation, deployment, or task run is initiated by this check.",
    }


def write_inventory(path: str, inventory: RenderInventory) -> None:
    import json
    from pathlib import Path
    Path(path).write_text(json.dumps({
        "inventory": inventory.to_dict(),
        "capabilities": [asdict(x) for x in capabilities(inventory)],
    }, indent=2), encoding="utf-8")
