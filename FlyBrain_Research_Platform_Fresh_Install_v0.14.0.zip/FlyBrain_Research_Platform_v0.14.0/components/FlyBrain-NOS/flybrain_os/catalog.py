"""Local SQLite catalog for versioned annotations and topology candidates."""
from __future__ import annotations
import json, sqlite3
from pathlib import Path
from dataclasses import asdict
from .annotations import NeuronAnnotation

SCHEMA = """
CREATE TABLE IF NOT EXISTS neuron_annotations (
 dataset TEXT NOT NULL, snapshot TEXT NOT NULL, root_id TEXT NOT NULL,
 values_json TEXT NOT NULL, evidence TEXT NOT NULL, source_reference TEXT NOT NULL,
 PRIMARY KEY(dataset,snapshot,root_id));
CREATE TABLE IF NOT EXISTS circuit_candidates (
 candidate_id TEXT PRIMARY KEY, dataset TEXT NOT NULL, snapshot TEXT NOT NULL,
 candidate_json TEXT NOT NULL, stored_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_annotations_root ON neuron_annotations(root_id);
"""

class ResearchCatalog:
    def __init__(self, path: str | Path):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        with self.connect() as db: db.executescript(SCHEMA)
    def connect(self):
        db=sqlite3.connect(self.path); db.execute("PRAGMA foreign_keys=ON"); return db
    def add_annotations(self, records: list[NeuronAnnotation], *, replace: bool=False) -> int:
        sql="INSERT OR REPLACE" if replace else "INSERT"
        rows=[(a.dataset,a.snapshot,a.root_id,json.dumps(a.values,ensure_ascii=False,sort_keys=True),a.evidence,a.source_reference) for a in records]
        with self.connect() as db: db.executemany(f"{sql} INTO neuron_annotations VALUES (?,?,?,?,?,?)",rows)
        return len(rows)
    def add_candidate(self, candidate: dict, dataset: str, snapshot: str) -> None:
        cid=str(candidate.get("candidate_id", "")).strip()
        if not cid: raise ValueError("candidate_id required")
        with self.connect() as db:
            db.execute("INSERT OR REPLACE INTO circuit_candidates(candidate_id,dataset,snapshot,candidate_json) VALUES (?,?,?,?)",
                       (cid,dataset,snapshot,json.dumps(candidate,ensure_ascii=False,sort_keys=True)))
    def stats(self) -> dict:
        with self.connect() as db:
            n=db.execute("SELECT COUNT(*) FROM neuron_annotations").fetchone()[0]
            c=db.execute("SELECT COUNT(*) FROM circuit_candidates").fetchone()[0]
            snaps=db.execute("SELECT DISTINCT dataset || ':' || snapshot FROM neuron_annotations ORDER BY 1").fetchall()
        return {"annotation_records":n,"circuit_candidates":c,"annotation_snapshots":[x[0] for x in snaps]}
    def get_neuron(self, dataset: str, snapshot: str, root_id: str):
        with self.connect() as db:
            row=db.execute("SELECT values_json,evidence,source_reference FROM neuron_annotations WHERE dataset=? AND snapshot=? AND root_id=?",(dataset,snapshot,str(root_id))).fetchone()
        if not row: return None
        return {"dataset":dataset,"snapshot":snapshot,"root_id":str(root_id),"values":json.loads(row[0]),"evidence":row[1],"source_reference":row[2]}
