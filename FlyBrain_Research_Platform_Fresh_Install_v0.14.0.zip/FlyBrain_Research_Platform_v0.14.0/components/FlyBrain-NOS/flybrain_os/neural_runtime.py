"""Experimental leaky-integrate-and-fire runtime for explicit synthetic networks.

This is a computational testbed, not a validated Drosophila brain model.
Weights, membrane constants, thresholds and input currents are supplied by the
experimenter. Connectome synapse counts are never silently interpreted as
physiological synaptic strengths.
"""
from __future__ import annotations
from dataclasses import dataclass
from math import exp, isfinite
from typing import Mapping


@dataclass(frozen=True)
class LIFConfig:
    dt_ms: float = 1.0
    tau_m_ms: float = 20.0
    resistance: float = 1.0
    rest_mv: float = -65.0
    reset_mv: float = -70.0
    threshold_mv: float = -50.0
    refractory_ms: float = 2.0
    synaptic_gain: float = 1.0

    def validate(self):
        positive = (self.dt_ms, self.tau_m_ms, self.resistance)
        if any(not isfinite(x) or x <= 0 for x in positive):
            raise ValueError("dt_ms, tau_m_ms and resistance must be finite and positive")
        if not isfinite(self.refractory_ms) or self.refractory_ms < 0:
            raise ValueError("refractory_ms must be finite and nonnegative")
        if not isfinite(self.synaptic_gain) or self.synaptic_gain < 0:
            raise ValueError("synaptic_gain must be finite and nonnegative")
        if not all(isfinite(x) for x in (self.rest_mv,self.reset_mv,self.threshold_mv)):
            raise ValueError("voltage parameters must be finite")
        if self.threshold_mv <= self.reset_mv:
            raise ValueError("threshold_mv must exceed reset_mv")


def simulate_lif(neuron_ids: list[str], directed_weights: list[tuple[str,str,float]],
                 input_current: Mapping[str,float], steps: int,
                 config: LIFConfig = LIFConfig(),
                 initial_voltage: Mapping[str,float] | None = None) -> dict:
    """Run deterministic synchronous LIF dynamics and return full voltage/spike traces.

    A spike emitted at step t contributes to its targets at step t+1. Positive
    weights are excitatory and negative weights inhibitory by convention; this
    sign convention is a model choice, not a claim about any imported dataset.
    """
    config.validate()
    if steps < 0: raise ValueError("steps must be nonnegative")
    nodes = list(neuron_ids)
    if len(nodes) != len(set(nodes)) or any(not isinstance(n,str) or not n for n in nodes):
        raise ValueError("neuron_ids must be unique non-empty strings")
    node_set=set(nodes)
    edges={n:[] for n in nodes}
    for src,dst,weight in directed_weights:
        if src not in node_set or dst not in node_set: raise ValueError("edge endpoint missing from neuron_ids")
        if not isfinite(float(weight)): raise ValueError("synaptic weights must be finite")
        edges[dst].append((src,float(weight)))
    if set(input_current)-node_set: raise ValueError("input_current contains unknown neuron ids")
    if initial_voltage is not None and set(initial_voltage)-node_set: raise ValueError("initial_voltage contains unknown neuron ids")
    currents={n:float(input_current.get(n,0.0)) for n in nodes}
    if any(not isfinite(v) for v in currents.values()): raise ValueError("input currents must be finite")
    voltage={n:float((initial_voltage or {}).get(n,config.rest_mv)) for n in nodes}
    if any(not isfinite(v) for v in voltage.values()): raise ValueError("initial voltages must be finite")
    refractory={n:0.0 for n in nodes}
    voltage_trace=[dict(voltage)]
    spike_trace=[]
    alpha=exp(-config.dt_ms/config.tau_m_ms)
    for _ in range(steps):
        emitted=[]
        next_voltage={}
        for n in nodes:
            if refractory[n] > 0:
                refractory[n]=max(0.0,refractory[n]-config.dt_ms)
                next_voltage[n]=config.reset_mv
                continue
            synaptic=sum(weight for src,weight in edges[n] if src in previous_spikes) if spike_trace else 0.0
            drive=currents[n]+config.synaptic_gain*synaptic
            v=config.rest_mv+(voltage[n]-config.rest_mv)*alpha+config.resistance*drive*(1-alpha)
            if v >= config.threshold_mv:
                emitted.append(n); next_voltage[n]=config.reset_mv
                refractory[n]=config.refractory_ms
            else:
                next_voltage[n]=v
        voltage=next_voltage
        previous_spikes=set(emitted)
        spike_trace.append(sorted(emitted))
        voltage_trace.append(dict(voltage))
    counts={n:sum(n in step for step in spike_trace) for n in nodes}
    return {"model":"synthetic_lif","steps":steps,"dt_ms":config.dt_ms,
            "voltage_trace":voltage_trace,"spike_trace":spike_trace,
            "spike_counts":counts,"assumptions":"user-supplied synthetic parameters; not biologically calibrated"}
