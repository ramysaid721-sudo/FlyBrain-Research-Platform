import argparse, json
from pathlib import Path
from .connectome import DatasetManifest, load_edges_csv, sha256_file, write_bundle
from .circuits import CircuitQuery, extract_circuit, save_candidate
from .annotations import load_annotations, write_annotations
from .catalog import ResearchCatalog
from .monitor import SourceMonitor, load_config, write_report
from .collaboration import CollaborationLedger
from .model_hub import ModelConsultation, discover_providers, resource_inventory, task_plan, check_provider

def main():
    p=argparse.ArgumentParser(prog="flybrain-nos")
    sub=p.add_subparsers(dest="cmd", required=True)
    v=sub.add_parser("validate-csv", help="validate a connectome edge CSV")
    v.add_argument("csv_path"); v.add_argument("--dataset", required=True); v.add_argument("--snapshot", required=True)
    v.add_argument("--source-name", required=True); v.add_argument("--source-url", required=True)
    v.add_argument("--license", required=True); v.add_argument("--attribution", required=True)
    v.add_argument("--imported-at", required=True); v.add_argument("--output", required=True)
    c=sub.add_parser("extract-circuit", help="extract a topology-only candidate from an edge CSV")
    c.add_argument("csv_path"); c.add_argument("--seed", action="append", default=[])
    c.add_argument("--neuropil", action="append", default=[]); c.add_argument("--min-synapses", type=int, default=1)
    c.add_argument("--hops", type=int, default=1); c.add_argument("--direction", choices=["in","out","both"], default="both")
    c.add_argument("--max-nodes", type=int, default=5000); c.add_argument("--candidate-id", default="candidate-001")
    c.add_argument("--output", required=True); c.add_argument("--dataset"); c.add_argument("--snapshot"); c.add_argument("--catalog")
    n=sub.add_parser("import-annotations", help="validate and normalize neuron annotations")
    n.add_argument("input_path"); n.add_argument("--dataset", required=True); n.add_argument("--snapshot", required=True)
    n.add_argument("--output", required=True); n.add_argument("--catalog")
    n.add_argument("--replace", action="store_true", help="replace matching dataset/snapshot/root_id records")
    s=sub.add_parser("catalog-stats", help="show local research catalog counts")
    s.add_argument("catalog_path")
    x=sub.add_parser("collab-send", help="send an auditable message to the other system")
    x.add_argument("--system", choices=["nrc","flybrain-nos"], required=True)
    x.add_argument("--to", choices=["nrc","flybrain-nos"], required=True)
    x.add_argument("--kind", choices=["research_proposal","artifact_manifest","test_report","lesson","decision"], required=True)
    x.add_argument("--payload", required=True, help="path to JSON object payload")
    x.add_argument("--ledger", default="data/collaboration.sqlite")
    x=sub.add_parser("collab-export", help="export messages as portable JSONL")
    x.add_argument("--system", choices=["nrc","flybrain-nos"], required=True)
    x.add_argument("--ledger", default="data/collaboration.sqlite")
    x.add_argument("--output", required=True); x.add_argument("--to", choices=["nrc","flybrain-nos"])
    x=sub.add_parser("collab-import", help="import and validate messages without executing payloads")
    x.add_argument("--system", choices=["nrc","flybrain-nos"], required=True)
    x.add_argument("input_path"); x.add_argument("--ledger", default="data/collaboration.sqlite")
    x=sub.add_parser("collab-stats", help="show collaboration ledger statistics")
    x.add_argument("--system", choices=["nrc","flybrain-nos"], required=True)
    x.add_argument("--ledger", default="data/collaboration.sqlite")
    x=sub.add_parser("collab-review", help="record a human/system review of an imported message")
    x.add_argument("--system", choices=["nrc","flybrain-nos"], required=True)
    x.add_argument("--ledger", default="data/collaboration.sqlite"); x.add_argument("--message-id", required=True)
    x.add_argument("--outcome", choices=["accepted","rejected","deferred"], required=True)
    x.add_argument("--reviewer", required=True); x.add_argument("--reason", required=True)
    mh=sub.add_parser("model-hub-status", help="inspect configured model providers and local compute resources")
    mh.add_argument("--output")
    mp=sub.add_parser("model-task-plan", help="create a multi-model review plan without calling external models")
    mp.add_argument("task"); mp.add_argument("--output")
    mc=sub.add_parser("model-consult", help="consult configured external model providers in parallel")
    mc.add_argument("task"); mc.add_argument("--ledger",default="data/model-consultations.sqlite"); mc.add_argument("--timeout",type=int,default=45); mc.add_argument("--output"); mc.add_argument("--local-only",action="store_true",help="never send task data to external model providers")
    pc=sub.add_parser("model-provider-check", help="probe configured provider /models endpoints without sending research prompts")
    pc.add_argument("--timeout",type=int,default=8); pc.add_argument("--output")
    m=sub.add_parser("monitor-sources", help="check configured public source pages for updates")
    m.add_argument("--config", default=str(Path(__file__).with_name("monitor_sources.json")))
    m.add_argument("--state", default="data/source-monitor.sqlite")
    m.add_argument("--report", default="data/source-monitor-report.json")
    a=p.parse_args()
    if a.cmd == "model-hub-status":
        result={"providers":[{"provider":x.provider_id,"model":x.model,"endpoint":x.endpoint,"credential_configured":bool(x.key_env and __import__("os").environ.get(x.key_env)) or x.local} for x in discover_providers()],"resources":resource_inventory()}
        if a.output: Path(a.output).write_text(json.dumps(result,indent=2),encoding="utf-8")
        print(json.dumps(result,indent=2))
    elif a.cmd == "model-task-plan":
        result=task_plan(a.task)
        if a.output: Path(a.output).write_text(json.dumps(result,indent=2),encoding="utf-8")
        print(json.dumps(result,ensure_ascii=False,indent=2))
    elif a.cmd == "model-consult":
        result=ModelConsultation(a.ledger).consult(a.task,timeout=a.timeout,local_only=a.local_only)
        if a.output: Path(a.output).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
        print(json.dumps(result,ensure_ascii=False,indent=2))
    elif a.cmd == "model-provider-check":
        result={"checked":len(discover_providers()),"results":[check_provider(x,timeout=a.timeout) for x in discover_providers()],"note":"Only metadata endpoints are queried; no research prompt is transmitted."}
        if a.output: Path(a.output).write_text(json.dumps(result,indent=2),encoding="utf-8")
        print(json.dumps(result,indent=2))
    elif a.cmd == "collab-send":
        if a.system == a.to: p.error("--to must name the other system")
        payload=json.loads(Path(a.payload).read_text(encoding="utf-8"))
        msg=CollaborationLedger(a.ledger,a.system).create_message(a.to,a.kind,payload)
        print(json.dumps(msg,ensure_ascii=False,indent=2))
    elif a.cmd == "collab-export":
        count=CollaborationLedger(a.ledger,a.system).export_jsonl(a.output,recipient=a.to)
        print(json.dumps({"exported":count,"output":a.output},indent=2))
    elif a.cmd == "collab-import":
        print(json.dumps(CollaborationLedger(a.ledger,a.system).import_jsonl(a.input_path),ensure_ascii=False,indent=2))
    elif a.cmd == "collab-stats":
        print(json.dumps(CollaborationLedger(a.ledger,a.system).stats(),indent=2))
    elif a.cmd == "collab-review":
        rid=CollaborationLedger(a.ledger,a.system).review(a.message_id,a.outcome,a.reviewer,a.reason)
        print(json.dumps({"review_id":rid,"outcome":a.outcome},indent=2))
    elif a.cmd == "validate-csv":
        edges=load_edges_csv(a.csv_path)
        m=DatasetManifest(a.dataset,a.snapshot,a.source_name,a.source_url,sha256_file(a.csv_path),a.license,a.attribution,a.imported_at)
        summary=write_bundle(a.output,m,edges)
        print(json.dumps(summary,indent=2))
    elif a.cmd == "import-annotations":
        records=load_annotations(a.input_path,dataset=a.dataset,snapshot=a.snapshot)
        summary=write_annotations(a.output,records)
        if a.catalog:
            summary["catalog_inserted"]=ResearchCatalog(a.catalog).add_annotations(records,replace=a.replace)
        print(json.dumps(summary,indent=2))
    elif a.cmd == "catalog-stats":
        print(json.dumps(ResearchCatalog(a.catalog_path).stats(),indent=2))
    elif a.cmd == "monitor-sources":
        report=SourceMonitor(a.state).run(load_config(a.config))
        write_report(report,a.report)
        print(json.dumps(report,ensure_ascii=False,indent=2))
    elif a.cmd == "extract-circuit":
        edges=load_edges_csv(a.csv_path)
        q=CircuitQuery(seed_neuron_ids=tuple(a.seed), neuropils=tuple(a.neuropil), min_synapses=a.min_synapses,
                       hops=a.hops, direction=a.direction, max_nodes=a.max_nodes)
        if bool(a.dataset) != bool(a.snapshot):
            p.error("--dataset and --snapshot must be supplied together")
        if a.catalog and not (a.dataset and a.snapshot):
            p.error("--catalog requires --dataset and --snapshot")
        candidate=extract_circuit(edges,q,a.candidate_id)
        save_candidate(candidate,a.output)
        if a.catalog:
            ResearchCatalog(a.catalog).add_candidate(candidate.to_dict(),a.dataset,a.snapshot)
        result=dict(candidate.topology_metrics)
        if a.catalog: result["catalog_candidate_saved"]=a.candidate_id
        print(json.dumps(result,indent=2))
if __name__ == "__main__": main()
