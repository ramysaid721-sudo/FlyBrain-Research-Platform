"""Topology-first circuit extraction with explicit evidence boundaries.

Extracted subgraphs are anatomical/topological candidates only. They do not
establish physiological function, synaptic sign, efficacy, or causal influence.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from collections import defaultdict, deque
from typing import Iterable
import json
from pathlib import Path

from .connectome import Edge


@dataclass(frozen=True)
class CircuitQuery:
    seed_neuron_ids: tuple[str, ...] = ()
    neuropils: tuple[str, ...] = ()
    min_synapses: int = 1
    hops: int = 1
    direction: str = "both"  # in, out, both
    max_nodes: int = 5000

    def validate(self) -> None:
        if self.min_synapses < 0: raise ValueError("min_synapses must be >= 0")
        if self.hops < 0: raise ValueError("hops must be >= 0")
        if self.direction not in {"in", "out", "both"}: raise ValueError("direction must be in, out, or both")
        if self.max_nodes < 1: raise ValueError("max_nodes must be >= 1")


@dataclass
class CircuitCandidate:
    candidate_id: str
    neuron_ids: list[str]
    internal_edges: list[dict]
    extraction_method: str
    query: dict
    topology_metrics: dict
    evidence: str = "measured_topology"
    functional_interpretation: str | None = None

    def to_dict(self): return asdict(self)


def extract_circuit(edges: Iterable[Edge], query: CircuitQuery, candidate_id: str = "candidate-001") -> CircuitCandidate:
    query.validate()
    rows = [e for e in edges if e.synapse_count >= query.min_synapses and (not query.neuropils or e.region in query.neuropils)]
    outgoing: dict[str, list[Edge]] = defaultdict(list)
    incoming: dict[str, list[Edge]] = defaultdict(list)
    for e in rows:
        outgoing[e.source_id].append(e); incoming[e.target_id].append(e)

    if query.seed_neuron_ids:
        selected = set(query.seed_neuron_ids)
        frontier = set(selected)
        for _ in range(query.hops):
            nxt: set[str] = set()
            for node in frontier:
                if query.direction in {"out", "both"}:
                    nxt.update(e.target_id for e in outgoing.get(node, ()))
                if query.direction in {"in", "both"}:
                    nxt.update(e.source_id for e in incoming.get(node, ()))
            nxt -= selected
            room = query.max_nodes - len(selected)
            if room <= 0: break
            if len(nxt) > room: nxt = set(sorted(nxt)[:room])
            selected.update(nxt); frontier = nxt
            if not frontier: break
    else:
        selected = set()
        for e in rows:
            for node in (e.source_id, e.target_id):
                if len(selected) < query.max_nodes:
                    selected.add(node)
            if len(selected) >= query.max_nodes: break

    internal = [e for e in rows if e.source_id in selected and e.target_id in selected]
    indeg = defaultdict(int); outdeg = defaultdict(int)
    for e in internal:
        outdeg[e.source_id] += 1; indeg[e.target_id] += 1
    n = len(selected); m = len(internal)
    pairs = {(e.source_id, e.target_id) for e in internal}
    reciprocal_pairs = sum(1 for a, b in pairs if (b, a) in pairs)
    metrics = {
        "node_count": n,
        "directed_edge_rows": m,
        "unique_directed_pairs": len(pairs),
        "total_observed_synapse_count": sum(e.synapse_count for e in internal),
        "mean_in_degree": (sum(indeg.values()) / n) if n else 0.0,
        "mean_out_degree": (sum(outdeg.values()) / n) if n else 0.0,
        "reciprocal_directed_pair_fraction": (reciprocal_pairs / len(pairs)) if pairs else 0.0,
        "synapse_counts_used_as_physiological_weights": False,
    }
    return CircuitCandidate(
        candidate_id=candidate_id,
        neuron_ids=sorted(selected),
        internal_edges=[{"source_id": e.source_id, "target_id": e.target_id, "synapse_count": e.synapse_count, "region": e.region} for e in internal],
        extraction_method="seeded_hop_neighborhood" if query.seed_neuron_ids else "bounded_edge_table_subgraph",
        query={**asdict(query), "seed_neuron_ids": list(query.seed_neuron_ids), "neuropils": list(query.neuropils)},
        topology_metrics=metrics,
    )


def save_candidate(candidate: CircuitCandidate, path: str | Path) -> None:
    Path(path).write_text(json.dumps(candidate.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
