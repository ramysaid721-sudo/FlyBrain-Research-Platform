"""Evidence-aware ingestion for static Drosophila connectome edge tables.

Synapse counts are retained as observations; they are never silently converted
into signed synaptic weights, efficacy, or functional meaning.
"""
from __future__ import annotations
import csv, hashlib, json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

EVIDENCE = {"measured", "inferred", "assumed", "synthetic"}

@dataclass(frozen=True)
class DatasetManifest:
    dataset: str
    snapshot: str
    source_name: str
    source_url: str
    source_sha256: str
    license: str
    attribution: str
    imported_at: str
    schema_version: str = "1.0"

    def validate(self) -> None:
        for key in ("dataset", "snapshot", "source_name", "source_url", "source_sha256", "license", "attribution", "imported_at"):
            if not str(getattr(self, key)).strip():
                raise ValueError(f"manifest field required: {key}")
        if len(self.source_sha256) != 64 or any(c not in "0123456789abcdef" for c in self.source_sha256.lower()):
            raise ValueError("source_sha256 must be a 64-character hex digest")

@dataclass(frozen=True)
class Edge:
    source_id: str
    target_id: str
    synapse_count: int
    region: str | None = None
    neurotransmitter_probabilities: dict[str, float] | None = None
    evidence: str = "measured"
    neurotransmitter_evidence: str | None = None

    def validate(self) -> None:
        if not self.source_id or not self.target_id:
            raise ValueError("source_id and target_id are required")
        if self.synapse_count < 0:
            raise ValueError("synapse_count cannot be negative")
        if self.evidence not in EVIDENCE:
            raise ValueError(f"unsupported evidence class: {self.evidence}")
        if self.neurotransmitter_evidence is not None and self.neurotransmitter_evidence not in EVIDENCE:
            raise ValueError(f"unsupported neurotransmitter evidence class: {self.neurotransmitter_evidence}")
        for name, p in (self.neurotransmitter_probabilities or {}).items():
            if not 0.0 <= float(p) <= 1.0:
                raise ValueError(f"probability out of range for {name}")

@dataclass(frozen=True)
class Neuron:
    root_id: str
    annotations: dict[str, Any]
    annotation_evidence: str = "inferred"

    def validate(self) -> None:
        if not self.root_id:
            raise ValueError("root_id is required")
        if self.annotation_evidence not in EVIDENCE:
            raise ValueError("invalid annotation evidence")


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_edges_csv(path: str | Path, *, source_col="pre_root_id", target_col="post_root_id", count_col="syn_count", region_col="neuropil") -> list[Edge]:
    """Load edge CSV. Root IDs stay strings to avoid 64-bit precision loss."""
    out: list[Edge] = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        required = {source_col, target_col, count_col}
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"missing CSV columns: {', '.join(sorted(missing))}")
        for line, row in enumerate(reader, start=2):
            try:
                edge = Edge(
                    source_id=str(row[source_col]).strip(),
                    target_id=str(row[target_col]).strip(),
                    synapse_count=int(row[count_col]),
                    region=(str(row.get(region_col, "")).strip() or None) if region_col else None,
                )
                edge.validate()
                out.append(edge)
            except Exception as exc:
                raise ValueError(f"invalid edge at CSV line {line}: {exc}") from exc
    return out


def write_bundle(output_dir: str | Path, manifest: DatasetManifest, edges: list[Edge]) -> dict[str, Any]:
    manifest.validate()
    for e in edges: e.validate()
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    (out / "manifest.json").write_text(json.dumps(asdict(manifest), indent=2), encoding="utf-8")
    with (out / "edges.jsonl").open("w", encoding="utf-8") as f:
        for e in edges: f.write(json.dumps(asdict(e), ensure_ascii=False) + "\n")
    node_ids = sorted({e.source_id for e in edges} | {e.target_id for e in edges})
    summary = {
        "dataset": manifest.dataset, "snapshot": manifest.snapshot,
        "edge_rows": len(edges), "unique_neurons_in_edges": len(node_ids),
        "synapse_count_total": sum(e.synapse_count for e in edges),
        "root_id_storage": "string", "synapse_counts_are_weights": False,
        "functional_labels_inferred_from_connectivity": False,
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary
