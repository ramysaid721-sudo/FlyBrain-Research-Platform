"""Evidence-aware neuron annotation ingestion (CSV and JSON)."""
from __future__ import annotations
import csv, json
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import Any

EVIDENCE = {"measured", "inferred", "assumed", "synthetic"}
ALLOWED_FIELDS = {
    "cell_type", "cell_sub_class", "class", "super_class", "flow", "hemibrain_type", "hemilineages", "side", "nerve", "vfb_id", "fbbt_id",
    "neuropils", "transmitter_prediction", "transmitter_confidence",
    "transmitter_verified", "confidence", "source_reference", "source_name",
    "source_url", "annotation_version", "notes"
}

@dataclass(frozen=True)
class NeuronAnnotation:
    root_id: str
    dataset: str
    snapshot: str
    values: dict[str, Any]
    evidence: str
    source_reference: str

    def validate(self) -> None:
        if not self.root_id.strip(): raise ValueError("root_id is required")
        if not self.dataset.strip() or not self.snapshot.strip(): raise ValueError("dataset and snapshot are required")
        if self.evidence not in EVIDENCE: raise ValueError(f"invalid evidence class: {self.evidence}")
        unknown = set(self.values) - ALLOWED_FIELDS
        if unknown: raise ValueError(f"unsupported annotation fields: {', '.join(sorted(unknown))}")
        for key in ("confidence", "transmitter_confidence"):
            if self.values.get(key) not in (None, ""):
                v=float(self.values[key])
                if not 0 <= v <= 1: raise ValueError(f"{key} must be between 0 and 1")
        if self.values.get("transmitter_verified") not in (None, "", True, False, "true", "false", "True", "False", "0", "1", 0, 1):
            raise ValueError("transmitter_verified must be boolean when supplied")
        # Predicted transmitter is not treated as a verified transmitter.
        if self.values.get("transmitter_prediction") and self.values.get("transmitter_verified") in (True, "true", "True", 1, "1"):
            raise ValueError("predicted transmitter and verified transmitter must be represented separately")


def _normalize(item: dict[str, Any], *, dataset: str | None, snapshot: str | None) -> NeuronAnnotation:
    root = str(item.get("root_id", "")).strip()
    ds = str(item.get("dataset", dataset or "")).strip()
    snap = str(item.get("snapshot", snapshot or "")).strip()
    evidence = str(item.get("evidence", "inferred")).strip().lower()
    source = str(item.get("source_reference", item.get("source_url", ""))).strip()
    metadata_fields = {"root_id", "dataset", "snapshot", "evidence"}
    unknown = set(item) - ALLOWED_FIELDS - metadata_fields
    if unknown: raise ValueError(f"unsupported annotation fields: {', '.join(sorted(unknown))}")
    values = {k: v for k, v in item.items() if k in ALLOWED_FIELDS and k not in {"source_reference"}}
    values.pop("source_url", None)
    obj = NeuronAnnotation(root, ds, snap, values, evidence, source)
    obj.validate()
    return obj


def load_annotations(path: str | Path, *, dataset: str | None = None, snapshot: str | None = None) -> list[NeuronAnnotation]:
    p=Path(path)
    if p.suffix.lower() == ".json":
        payload=json.loads(p.read_text(encoding="utf-8"))
        if not isinstance(payload, list): raise ValueError("annotation JSON must contain a list of records")
        records=payload
    else:
        with p.open(newline="", encoding="utf-8-sig") as f:
            records=list(csv.DictReader(f))
    result=[]
    for i, item in enumerate(records, start=1):
        try:
            item=dict(item)
            # JSON-encoded list fields are decoded; other values remain as supplied.
            if isinstance(item.get("neuropils"), str) and item["neuropils"].strip().startswith("["):
                item["neuropils"]=json.loads(item["neuropils"])
            result.append(_normalize(item, dataset=dataset, snapshot=snapshot))
        except Exception as exc:
            raise ValueError(f"invalid annotation record {i}: {exc}") from exc
    ids=[(x.dataset,x.snapshot,x.root_id) for x in result]
    if len(ids) != len(set(ids)): raise ValueError("duplicate root_id within the same dataset snapshot")
    return result


def write_annotations(path: str | Path, annotations: list[NeuronAnnotation]) -> dict[str, Any]:
    for a in annotations: a.validate()
    out=Path(path); out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as f:
        for a in annotations: f.write(json.dumps(asdict(a), ensure_ascii=False, sort_keys=True)+"\n")
    return {"records":len(annotations), "datasets":sorted({a.dataset for a in annotations}),
            "snapshots":sorted({a.snapshot for a in annotations}), "root_ids_are_strings":True,
            "predictions_are_not_verified_facts":True}
