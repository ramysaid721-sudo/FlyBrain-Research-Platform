"""Change monitor for official connectome information sources.

The monitor stores a local baseline and HTTP validators. It does not download
large connectome payloads or execute remote code.
"""
from __future__ import annotations

import difflib
import hashlib
import json
import re
import sqlite3
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Callable
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

USER_AGENT = "FlyBrain-NOS-source-monitor/0.5 (+local research metadata checker)"
MAX_BYTES_DEFAULT = 2_000_000


class _TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__(); self.parts=[]; self.skip=0
    def handle_starttag(self, tag, attrs):
        if tag.lower() in {"script", "style", "noscript", "svg"}: self.skip += 1
        elif tag.lower() in {"p", "div", "li", "h1", "h2", "h3", "tr", "br"}: self.parts.append("\n")
    def handle_endtag(self, tag):
        if tag.lower() in {"script", "style", "noscript", "svg"} and self.skip: self.skip -= 1
        elif tag.lower() in {"p", "div", "li", "h1", "h2", "h3", "tr"}: self.parts.append("\n")
    def handle_data(self, data):
        if not self.skip: self.parts.append(data)


def normalize_body(body: bytes, content_type: str = "") -> str:
    raw = body.decode("utf-8", errors="replace")
    if "html" in content_type.lower() or re.search(r"<\s*(html|body|div|p|main)\b", raw[:2000], re.I):
        parser = _TextExtractor(); parser.feed(raw); raw = "\n".join(parser.parts)
    lines = [re.sub(r"\s+", " ", line).strip() for line in raw.splitlines()]
    return "\n".join(line for line in lines if line)


@dataclass
class FetchResult:
    status: int
    body: bytes = b""
    etag: str = ""
    last_modified: str = ""
    content_type: str = ""


def http_fetch(url: str, *, etag: str = "", last_modified: str = "", timeout: int = 20,
               max_bytes: int = MAX_BYTES_DEFAULT) -> FetchResult:
    headers = {"User-Agent": USER_AGENT, "Accept": "text/html,application/json,application/atom+xml,application/rss+xml,text/plain,*/*;q=0.5"}
    if etag: headers["If-None-Match"] = etag
    if last_modified: headers["If-Modified-Since"] = last_modified
    req = Request(url, headers=headers)
    try:
        with urlopen(req, timeout=timeout) as response:
            body = response.read(max_bytes + 1)
            if len(body) > max_bytes: raise ValueError(f"source exceeded {max_bytes} byte safety limit")
            h = response.headers
            return FetchResult(response.status, body, h.get("ETag", ""), h.get("Last-Modified", ""), h.get("Content-Type", ""))
    except HTTPError as exc:
        if exc.code == 304:
            return FetchResult(304, b"", etag, last_modified, "")
        raise


SCHEMA = """
CREATE TABLE IF NOT EXISTS source_state (
 source_id TEXT PRIMARY KEY, url TEXT NOT NULL, content_hash TEXT NOT NULL,
 content_text TEXT NOT NULL, etag TEXT NOT NULL, last_modified TEXT NOT NULL,
 checked_at TEXT NOT NULL, http_status INTEGER NOT NULL
);
"""


class SourceMonitor:
    def __init__(self, state_path: str | Path, fetcher: Callable = http_fetch):
        self.path = Path(state_path); self.path.parent.mkdir(parents=True, exist_ok=True)
        self.fetcher = fetcher
        with sqlite3.connect(self.path) as db: db.executescript(SCHEMA)

    def _prior(self, source_id: str):
        with sqlite3.connect(self.path) as db:
            row = db.execute("SELECT url,content_hash,content_text,etag,last_modified FROM source_state WHERE source_id=?", (source_id,)).fetchone()
        return row

    def check(self, source: dict) -> dict:
        sid = str(source["id"]); url = str(source["url"]); prior = self._prior(sid)
        if prior and prior[0] != url: prior = None
        try:
            result = self.fetcher(url, etag=prior[3] if prior else "", last_modified=prior[4] if prior else "")
            now = datetime.now(timezone.utc).isoformat(timespec="seconds")
            if result.status == 304 and prior:
                with sqlite3.connect(self.path) as db:
                    db.execute("UPDATE source_state SET checked_at=?,http_status=304 WHERE source_id=?", (now,sid))
                return {"id":sid,"url":url,"status":"unchanged","http_status":304}
            if result.status < 200 or result.status >= 300: raise RuntimeError(f"unexpected HTTP status {result.status}")
            text = normalize_body(result.body, result.content_type)
            digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
            baseline = prior is None
            changed = bool(prior and prior[1] != digest)
            with sqlite3.connect(self.path) as db:
                db.execute("INSERT OR REPLACE INTO source_state VALUES (?,?,?,?,?,?,?,?)",
                    (sid,url,digest,text,result.etag,result.last_modified,now,result.status))
            out = {"id":sid,"url":url,"status":"baseline_created" if baseline else ("changed" if changed else "unchanged"),
                   "http_status":result.status,"sha256":digest,"characters":len(text)}
            if changed:
                diff = list(difflib.unified_diff(prior[2].splitlines(), text.splitlines(), fromfile="previous", tofile="current", lineterm=""))
                out["change_excerpt"] = "\n".join(diff[:80])
            return out
        except Exception as exc:
            return {"id":sid,"url":url,"status":"error","error":f"{type(exc).__name__}: {exc}"}

    def run(self, config: dict) -> dict:
        sources = config.get("sources")
        if not isinstance(sources, list) or not sources: raise ValueError("config must contain a non-empty sources list")
        ids=set()
        for s in sources:
            if not isinstance(s,dict) or not s.get("id") or not s.get("url"): raise ValueError("each source requires id and url")
            if s["id"] in ids: raise ValueError(f"duplicate source id: {s['id']}")
            ids.add(s["id"])
        results=[self.check(s) for s in sources]
        return {"monitor":"FlyBrain-NOS","generated_at":datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "checked":len(results),"changed":sum(x["status"]=="changed" for x in results),
                "errors":sum(x["status"]=="error" for x in results),"results":results}


def load_config(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_report(report: dict, path: str | Path) -> None:
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
