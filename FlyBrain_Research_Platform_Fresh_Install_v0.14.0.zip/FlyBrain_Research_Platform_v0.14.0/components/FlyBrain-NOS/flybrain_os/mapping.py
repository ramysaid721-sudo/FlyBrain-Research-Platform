"""Separate anatomical circuits from functional hypotheses."""
from dataclasses import dataclass

VALID_EVIDENCE = {"measured", "inferred", "assumed", "synthetic"}

@dataclass(frozen=True)
class CircuitAssignment:
    circuit_id: str
    neuron_ids: tuple[str, ...]
    anatomical_basis: str
    proposed_function: str | None = None
    function_evidence: str | None = None
    source_reference: str | None = None

    def validate(self):
        if not self.circuit_id or not self.neuron_ids:
            raise ValueError("circuit_id and at least one neuron ID are required")
        if not self.anatomical_basis.strip():
            raise ValueError("anatomical_basis is required")
        if self.proposed_function and self.function_evidence not in VALID_EVIDENCE:
            raise ValueError("functional claims require an explicit evidence class")
        if not self.proposed_function and self.function_evidence is not None:
            raise ValueError("function_evidence without a proposed_function is invalid")


def assignments_from_json(payload):
    if not isinstance(payload, list): raise ValueError("circuit mapping must be a JSON list")
    result=[]
    for item in payload:
        a=CircuitAssignment(
            circuit_id=item["circuit_id"], neuron_ids=tuple(str(x) for x in item["neuron_ids"]),
            anatomical_basis=item["anatomical_basis"], proposed_function=item.get("proposed_function"),
            function_evidence=item.get("function_evidence"), source_reference=item.get("source_reference"))
        a.validate(); result.append(a)
    return result
