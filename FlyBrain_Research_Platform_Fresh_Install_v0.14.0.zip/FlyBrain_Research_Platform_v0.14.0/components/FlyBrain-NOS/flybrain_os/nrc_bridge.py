"""Drop-in NRC-side adapter for the shared collaboration protocol.

This adapter only packages and exchanges JSON data. It never executes a
received payload, imports a peer's Python modules, or shares runtime state.
"""
from pathlib import Path
from typing import Any
from .collaboration import CollaborationLedger

class NRCBridge:
    def __init__(self, ledger_path: str|Path):
        self.ledger=CollaborationLedger(ledger_path,"nrc")

    def publish(self, kind: str, payload: dict[str,Any]) -> dict:
        return self.ledger.create_message("flybrain-nos",kind,payload)

    def export_outbox(self, destination: str|Path) -> int:
        return self.ledger.export_jsonl(destination,recipient="flybrain-nos")

    def import_inbox(self, source: str|Path) -> dict:
        return self.ledger.import_jsonl(source)

    def review(self, message_id: str, outcome: str, reason: str) -> str:
        return self.ledger.review(message_id,outcome,"nrc",reason)

    def status(self) -> dict:
        return self.ledger.stats()
