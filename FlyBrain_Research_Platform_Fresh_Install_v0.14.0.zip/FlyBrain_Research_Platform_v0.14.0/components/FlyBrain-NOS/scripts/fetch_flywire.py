#!/usr/bin/env python3
"""Download the public FlyWire FAFB v783 package with explicit opt-in."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

REPO = "SLOP011/flywire-fafb-connectome"
FILES = ["README.md", "meta.json", "connections.parquet", "nodes.parquet"]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output", default="data/flywire_fafb_v783", help="download directory")
    ap.add_argument("--revision", default="main", help="Hub revision; prefer a commit hash for reproducibility")
    args = ap.parse_args()
    try:
        from huggingface_hub import snapshot_download
    except ImportError as exc:
        raise SystemExit("Install optional dependency first: pip install 'flybrain-nos[hub]'") from exc
    target = Path(args.output).resolve()
    target.mkdir(parents=True, exist_ok=True)
    local = Path(snapshot_download(
        repo_id=REPO, repo_type="dataset", revision=args.revision,
        allow_patterns=FILES, local_dir=str(target),
    ))
    files = []
    for name in FILES:
        p = local / name
        if p.is_file():
            files.append({"path": name, "bytes": p.stat().st_size, "sha256": sha256(p)})
    record = {
        "repository": REPO, "revision": args.revision, "snapshot": "FAFB_v783",
        "license_declared_by_package": "CC-BY-4.0", "files": files,
        "note": "Verify upstream terms and repository revision before publication or redistribution.",
    }
    (local / "flybrain_download_manifest.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
