#!/usr/bin/env python3
"""Run release checks and create a clean, checksummed FlyBrain-NOS source archive."""
from __future__ import annotations
import hashlib, json, subprocess, sys, zipfile, tomllib
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERSION = tomllib.loads((ROOT / 'pyproject.toml').read_text())['project']['version']
OUT = ROOT.parent / f'FlyBrain_Neural_Operating_System_v{VERSION}-release.zip'
EXCLUDED_PARTS = {'__pycache__', '.pytest_cache', '.git', 'build', 'dist'}
EXCLUDED_SUFFIXES = {'.pyc', '.sqlite', '.db'}

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def run(args: list[str]) -> None:
    subprocess.run(args, cwd=ROOT, check=True)

def main() -> int:
    run([sys.executable, '-m', 'pytest', '-q'])
    run([sys.executable, '-m', 'compileall', '-q', 'flybrain_os'])
    run([sys.executable, '-m', 'flybrain_os.cli', '--help'])
    run([sys.executable, '-m', 'flybrain_os.cli', 'model-hub-status'])
    files = []
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or path.name == 'RELEASE_MANIFEST.json':
            continue
        rel = path.relative_to(ROOT)
        if any(part in EXCLUDED_PARTS or part.endswith('.egg-info') for part in rel.parts) or path.suffix in EXCLUDED_SUFFIXES:
            continue
        files.append({'path': rel.as_posix(), 'sha256': sha256(path), 'bytes': path.stat().st_size})
    manifest = {
        'project': 'FlyBrain-NOS', 'version': VERSION,
        'created_at_utc': datetime.now(timezone.utc).isoformat(timespec='seconds'),
        'verification': {'pytest': 'passed', 'compileall': 'passed', 'cli_help': 'passed', 'model_hub_status': 'passed'},
        'source_file_count': len(files), 'source_files': files,
        'scope_note': 'Source release only. No connectome payloads, credentials, runtime databases, or cloud resources included.'
    }
    (ROOT / 'RELEASE_MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(ROOT.rglob('*')):
            if not path.is_file(): continue
            rel = path.relative_to(ROOT)
            if any(part in EXCLUDED_PARTS or part.endswith('.egg-info') for part in rel.parts) or path.suffix in EXCLUDED_SUFFIXES:
                continue
            z.write(path, Path('FlyBrain_Neural_Operating_System') / rel)
    with zipfile.ZipFile(OUT) as z:
        bad = z.testzip()
        if bad: raise RuntimeError(f'archive integrity failure: {bad}')
    print(json.dumps({'archive': str(OUT), 'bytes': OUT.stat().st_size,
                      'files': len(zipfile.ZipFile(OUT).namelist()), 'sha256': sha256(OUT)}, indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
