#!/usr/bin/env python3
"""Stream basic structural QA metrics from FlyWire FAFB v783 Parquet files."""
from __future__ import annotations
import argparse
import json
import math
from collections import Counter
from pathlib import Path

NT = ("gaba", "ach", "glut", "oct", "ser", "da")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--data-dir", default="data/flywire_fafb_v783")
    ap.add_argument("--output", default="data/flywire_fafb_v783_analysis.json")
    ap.add_argument("--batch-size", type=int, default=100_000)
    args = ap.parse_args()
    if args.batch_size < 1:
        ap.error("--batch-size must be positive")
    try:
        import pyarrow.parquet as pq
    except ImportError as exc:
        raise SystemExit("Install optional dependency first: pip install 'flybrain-nos[parquet]'") from exc
    root = Path(args.data_dir)
    edges_path, nodes_path = root / "connections.parquet", root / "nodes.parquet"
    if not edges_path.is_file() or not nodes_path.is_file():
        raise SystemExit("Expected connections.parquet and nodes.parquet in --data-dir")
    edge_file, node_file = pq.ParquetFile(edges_path), pq.ParquetFile(nodes_path)
    required_edges = {"pre", "post", "syn_count", *NT}
    if not required_edges.issubset(edge_file.schema.names):
        raise SystemExit(f"Edge schema missing: {sorted(required_edges - set(edge_file.schema.names))}")
    required_nodes = {"root_id", "super_class", "cell_class", "cell_type", "top_nt", "top_nt_conf"}
    if not required_nodes.issubset(node_file.schema.names):
        raise SystemExit(f"Node schema missing: {sorted(required_nodes - set(node_file.schema.names))}")

    out_degree, in_degree, nt_sums = Counter(), Counter(), Counter()
    nt_min, nt_max = {k: 1.0 for k in NT}, {k: 0.0 for k in NT}
    rows = synapses = ge5 = self_loops = bad_probability_rows = 0
    for batch in edge_file.iter_batches(batch_size=args.batch_size, columns=["pre", "post", "syn_count", *NT]):
        data = batch.to_pydict()
        n = len(data["pre"])
        rows += n
        for pre, post, count in zip(data["pre"], data["post"], data["syn_count"]):
            pre, post, count = str(pre), str(post), int(count)
            out_degree[pre] += 1; in_degree[post] += 1
            synapses += count; ge5 += count >= 5; self_loops += pre == post
        for i in range(n):
            vals = [float(data[k][i]) for k in NT]
            total = sum(vals)
            if not all(math.isfinite(v) and 0 <= v <= 1 for v in vals) or abs(total - 1.0) > 0.025:
                bad_probability_rows += 1
            for k, v in zip(NT, vals):
                nt_sums[k] += v
                nt_min[k] = min(nt_min[k], v); nt_max[k] = max(nt_max[k], v)

    node_counts = Counter()
    node_rows = 0
    for batch in node_file.iter_batches(batch_size=args.batch_size, columns=["root_id", "super_class", "cell_class", "cell_type", "top_nt"]):
        d = batch.to_pydict(); node_rows += len(d["root_id"])
        node_counts.update(str(x) for x in d["super_class"] if x not in (None, ""))
    result = {
        "dataset": "FlyWire FAFB v783", "edge_rows": rows, "node_rows": node_rows,
        "unique_edge_endpoint_ids": len(set(out_degree) | set(in_degree)),
        "synapse_count_sum": synapses, "edges_ge5_synapses": ge5, "self_loop_rows": self_loops,
        "super_class_counts": dict(node_counts),
        "neurotransmitter_probability_means": {k: nt_sums[k] / rows if rows else None for k in NT},
        "neurotransmitter_probability_min": nt_min, "neurotransmitter_probability_max": nt_max,
        "rows_with_invalid_probability_vector": bad_probability_rows,
        "interpretation_limits": [
            "Synapse counts are structural observations, not synaptic efficacies.",
            "Neurotransmitter columns are probabilities/predictions, not verified transmitter measurements.",
            "Degree statistics describe this packaged directed edge table, not functional causal influence.",
        ],
    }
    out = Path(args.output); out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
