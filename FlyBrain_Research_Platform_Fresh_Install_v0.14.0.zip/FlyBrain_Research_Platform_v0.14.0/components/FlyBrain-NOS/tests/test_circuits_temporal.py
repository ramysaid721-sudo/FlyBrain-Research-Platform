import pytest
from flybrain_os.connectome import Edge
from flybrain_os.circuits import CircuitQuery, extract_circuit
from flybrain_os.temporal import TemporalConfig, simulate_steps


def test_seeded_outgoing_circuit_extraction():
    edges=[Edge('a','b',7,'AL'),Edge('b','c',4,'AL'),Edge('x','a',9,'MB')]
    c=extract_circuit(edges,CircuitQuery(seed_neuron_ids=('a',),hops=1,direction='out',neuropils=('AL',)))
    assert c.neuron_ids == ['a','b']
    assert c.topology_metrics['total_observed_synapse_count'] == 7
    assert c.topology_metrics['synapse_counts_used_as_physiological_weights'] is False
    assert c.functional_interpretation is None


def test_seeded_both_hops():
    edges=[Edge('a','b',2),Edge('c','a',3),Edge('b','d',4)]
    c=extract_circuit(edges,CircuitQuery(seed_neuron_ids=('a',),hops=2,direction='both'))
    assert set(c.neuron_ids) == {'a','b','c','d'}


def test_circuit_node_cap():
    edges=[Edge('a',str(i),1) for i in range(10)]
    c=extract_circuit(edges,CircuitQuery(seed_neuron_ids=('a',),hops=1,max_nodes=4))
    assert len(c.neuron_ids) <= 4


def test_invalid_query_rejected():
    with pytest.raises(ValueError): extract_circuit([],CircuitQuery(direction='sideways'))


def test_temporal_synthetic_propagation():
    h=simulate_steps(['a','b'],[('a','b')],{'a':1.0},2,TemporalConfig(decay=0,gain=.5,threshold=0))
    assert h[0]['a'] == 1.0
    assert h[1]['b'] == .5
    assert h[2]['b'] == 0.0


def test_temporal_rejects_missing_endpoint():
    with pytest.raises(ValueError): simulate_steps(['a'],[('a','b')],{},1)


def test_temporal_parameter_validation():
    with pytest.raises(ValueError): TemporalConfig(decay=1.5).validate()
