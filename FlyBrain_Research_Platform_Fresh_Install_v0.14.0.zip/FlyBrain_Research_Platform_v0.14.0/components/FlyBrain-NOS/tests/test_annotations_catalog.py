import json, pytest
from flybrain_os.annotations import NeuronAnnotation, load_annotations, write_annotations
from flybrain_os.catalog import ResearchCatalog

def test_annotation_json_and_large_root_id(tmp_path):
    p=tmp_path/'a.json'
    p.write_text(json.dumps([{"root_id":"9007199254740993123","cell_type":"Kenyon cell","transmitter_prediction":"GABA","transmitter_verified":False,"evidence":"inferred","source_reference":"doi:x"}]))
    rows=load_annotations(p,dataset='FAFB',snapshot='v783')
    assert rows[0].root_id=='9007199254740993123'
    assert rows[0].values['transmitter_prediction']=='GABA'
    assert rows[0].values['transmitter_verified'] is False

def test_unknown_annotation_field_rejected(tmp_path):
    p=tmp_path/'a.json'; p.write_text('[{"root_id":"1","mystery":"x"}]')
    with pytest.raises(ValueError): load_annotations(p,dataset='D',snapshot='S')

def test_duplicate_snapshot_root_rejected(tmp_path):
    p=tmp_path/'a.json'; p.write_text('[{"root_id":"1"},{"root_id":"1"}]')
    with pytest.raises(ValueError): load_annotations(p,dataset='D',snapshot='S')

def test_confidence_bounds(tmp_path):
    p=tmp_path/'a.json'; p.write_text('[{"root_id":"1","confidence":1.5}]')
    with pytest.raises(ValueError): load_annotations(p,dataset='D',snapshot='S')

def test_catalog_roundtrip_and_snapshot_isolation(tmp_path):
    p=tmp_path/'a.json'; p.write_text('[{"root_id":"1","cell_type":"A"}]')
    a=load_annotations(p,dataset='FAFB',snapshot='v783')
    cat=ResearchCatalog(tmp_path/'catalog.sqlite')
    assert cat.add_annotations(a)==1
    assert cat.get_neuron('FAFB','v783','1')['values']['cell_type']=='A'
    assert cat.get_neuron('FAFB','v784','1') is None
    assert cat.stats()['annotation_records']==1

def test_duplicate_insert_requires_replace(tmp_path):
    p=tmp_path/'a.json'; p.write_text('[{"root_id":"1"}]')
    a=load_annotations(p,dataset='D',snapshot='S'); cat=ResearchCatalog(tmp_path/'c.db')
    cat.add_annotations(a)
    with pytest.raises(Exception): cat.add_annotations(a)
    assert cat.add_annotations(a,replace=True)==1

def test_write_jsonl(tmp_path):
    p=tmp_path/'a.json'; p.write_text('[{"root_id":"1"}]')
    rows=load_annotations(p,dataset='D',snapshot='S')
    out=tmp_path/'out.jsonl'; summary=write_annotations(out,rows)
    assert summary['predictions_are_not_verified_facts'] is True
    assert json.loads(out.read_text().splitlines()[0])['root_id']=='1'

def test_catalog_stores_circuit_candidate(tmp_path):
    cat=ResearchCatalog(tmp_path/'catalog.db')
    candidate={'candidate_id':'circuit-A','neuron_ids':['1','2'],'topology_metrics':{'node_count':2}}
    cat.add_candidate(candidate,'FAFB','v783')
    assert cat.stats()['circuit_candidates']==1
