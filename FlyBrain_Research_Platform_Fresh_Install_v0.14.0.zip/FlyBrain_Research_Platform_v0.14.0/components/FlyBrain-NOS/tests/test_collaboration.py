import json
import pytest
from flybrain_os.collaboration import CollaborationError, CollaborationLedger


def test_bidirectional_message_exchange_and_deduplication(tmp_path):
    nrc=CollaborationLedger(tmp_path/'nrc.sqlite','nrc')
    fly=CollaborationLedger(tmp_path/'fly.sqlite','flybrain-nos')
    nrc.create_message('flybrain-nos','research_proposal',{'goal':'test graph metric','evidence':'synthetic'},message_id='m-1')
    packet=tmp_path/'to-fly.jsonl'
    assert nrc.export_jsonl(packet,recipient='flybrain-nos')==1
    first=fly.import_jsonl(packet)
    second=fly.import_jsonl(packet)
    assert first['imported']==1 and first['executed_payloads']==0
    assert second['duplicates']==1
    fly.create_message('nrc','lesson',{'lesson':'preserve snapshot identity'},message_id='m-2')
    reply=tmp_path/'to-nrc.jsonl'
    assert fly.export_jsonl(reply,recipient='nrc')==1
    assert nrc.import_jsonl(reply)['imported']==1
    assert nrc.stats()['messages']==2
    assert fly.stats()['messages']==2


def test_checksum_tampering_is_rejected(tmp_path):
    a=CollaborationLedger(tmp_path/'a.sqlite','nrc')
    b=CollaborationLedger(tmp_path/'b.sqlite','flybrain-nos')
    a.create_message('flybrain-nos','lesson',{'x':1},message_id='x')
    path=tmp_path/'packet.jsonl'; a.export_jsonl(path)
    msg=json.loads(path.read_text()); msg['payload']['x']=2
    path.write_text(json.dumps(msg)+'\n')
    result=b.import_jsonl(path)
    assert result['imported']==0 and 'checksum mismatch' in result['errors'][0]['error']


def test_invalid_direction_and_kind_rejected(tmp_path):
    a=CollaborationLedger(tmp_path/'a.sqlite','nrc')
    with pytest.raises(CollaborationError): a.create_message('nrc','lesson',{})
    with pytest.raises(CollaborationError): a.create_message('flybrain-nos','execute_shell',{})


def test_reviews_are_append_only_and_reasoned(tmp_path):
    a=CollaborationLedger(tmp_path/'a.sqlite','nrc')
    a.create_message('flybrain-nos','artifact_manifest',{'sha256':'a'*64},message_id='artifact-1')
    a.review('artifact-1','deferred','nrc-reviewer','Awaiting independent tests')
    assert a.stats()['reviews_by_outcome']=={'deferred':1}
    with pytest.raises(CollaborationError): a.review('artifact-1','accepted','nrc-reviewer','')
