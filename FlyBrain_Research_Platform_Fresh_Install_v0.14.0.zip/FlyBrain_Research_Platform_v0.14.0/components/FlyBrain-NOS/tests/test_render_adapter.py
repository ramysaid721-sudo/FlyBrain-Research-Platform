from flybrain_os.render_adapter import (
    inventory_from_render_responses, capabilities, deployment_guard,
)


def test_inventory_handles_empty_render_workspace():
    ws = {"id": "ws-1", "name": "Research"}
    inv = inventory_from_render_responses(ws, None, {"items": []},
                                          "No Postgres instances found",
                                          "No Key Value instances found")
    assert inv.workspace_id == "ws-1"
    assert len(inv.services) == len(inv.workflows) == 0
    states = {x.capability: x.state for x in capabilities(inv)}
    assert states["control_plane_access"] == "authenticated"
    assert states["web_services"] == "available_not_provisioned"


def test_inventory_normalizes_existing_resources():
    inv = inventory_from_render_responses(
        {"id": "ws", "name": "R"},
        {"items": [{"id": "srv-1"}]},
        {"items": [{"id": "wf-1"}]},
        [{"id": "db-1"}],
        {"items": [{"id": "kv-1"}]},
    )
    assert [x["id"] for x in inv.services] == ["srv-1"]
    assert [x["id"] for x in inv.postgres_instances] == ["db-1"]


def test_deployment_guard_blocks_missing_repo_secrets_approval_and_budget():
    result = deployment_guard(repository_url=None, branch="main",
                              secrets_configured=False, approval_received=False,
                              budget_approved=False)
    assert result["decision"] == "blocked"
    assert len(result["blockers"]) == 4
    assert result["execution_performed"] is False


def test_deployment_guard_only_eligible_when_all_gates_met():
    result = deployment_guard(repository_url="https://github.com/acme/flybrain",
                              branch="main", secrets_configured=True,
                              approval_received=True, budget_approved=True)
    assert result["decision"] == "eligible_for_explicit_deployment_review"
    assert result["execution_performed"] is False
