import json
from flybrain_os.model_hub import (ModelConsultation, ModelHubError, Provider,
    discover_providers, resource_inventory, task_plan)


def test_provider_discovery_never_exposes_credentials():
    env={"OPENAI_API_KEY":"secret-value","OPENAI_MODEL":"gpt-test",
         "XAI_API_KEY":"x-secret","XAI_MODEL":"grok-test",
         "OLLAMA_MODEL":"local-test"}
    providers=discover_providers(env)
    assert {p.provider_id for p in providers}=={"openai","xai","ollama"}
    assert all("secret" not in repr(p) for p in providers)


def test_task_plan_has_independent_critique_and_synthesis():
    plan=task_plan("Assess graph routing")
    assert [x["role"] for x in plan["workflow"]]==["proposer","independent_critic","synthesizer"]
    assert "Do not execute" in plan["policy"]


def test_model_consult_uses_configured_providers_and_logs_outputs(tmp_path):
    providers=[Provider("openai","https://api.openai.com/v1","gpt-test","OPENAI_API_KEY"),
               Provider("xai","https://api.x.ai/v1","grok-test","XAI_API_KEY")]
    def fake_call(provider,prompt,timeout=45):
        assert "Assess" in prompt
        return "analysis from "+provider.provider_id
    ledger=ModelConsultation(tmp_path/"models.sqlite")
    result=ledger.consult("Assess the routing design",providers=providers,caller=fake_call)
    assert result["status"]=="completed"
    assert len(result["results"])==2
    assert {x["provider"] for x in result["results"]}=={"openai","xai"}
    assert all(x["status"]=="completed" for x in result["results"])


def test_no_provider_is_reported_honestly(tmp_path):
    result=ModelConsultation(tmp_path/"models.sqlite").consult("test",providers=[])
    assert result["status"]=="no_providers_configured"


def test_remote_http_endpoint_rejected():
    from flybrain_os.model_hub import _post_chat
    p=Provider("bad","http://example.com/v1","model","TOKEN")
    try:
        _post_chat(p,"hello")
    except ModelHubError as e:
        assert "HTTPS" in str(e)
    else:
        raise AssertionError("insecure remote endpoint should be rejected")


def test_resource_inventory_is_safe_and_structured():
    report=resource_inventory()
    assert "cpu_count" in report and "memory_total_bytes" in report
    assert report["provider_credentials_exposed"] is False


def test_custom_provider_is_discovered_without_reading_secret_value():
    env={"MY_SECRET":"do-not-print","MY_MODEL":"custom-model",
         "FLYBRAIN_EXTRA_PROVIDERS":json.dumps([{"id":"custom","endpoint":"https://models.example/v1","model":"custom-model","key_env":"MY_SECRET"}])}
    providers=discover_providers(env)
    assert len(providers)==1 and providers[0].provider_id=="custom"
    assert "do-not-print" not in repr(providers)


def test_openai_compatible_adapter_builds_authenticated_request(monkeypatch):
    import io
    from flybrain_os.model_hub import _post_chat
    monkeypatch.setenv("XAI_API_KEY", "temporary-secret")
    captured={}
    class Response:
        def __enter__(self): return self
        def __exit__(self,*args): pass
        def read(self,n): return json.dumps({"choices":[{"message":{"content":"Grok response"}}]}).encode()
    def fake_open(req,timeout):
        captured["url"]=req.full_url
        captured["auth"]=req.get_header("Authorization")
        captured["body"]=json.loads(req.data)
        captured["timeout"]=timeout
        return Response()
    provider=Provider("xai","https://api.x.ai/v1","grok-test","XAI_API_KEY")
    assert _post_chat(provider,"Review this",timeout=12,opener=fake_open)=="Grok response"
    assert captured["url"]=="https://api.x.ai/v1/chat/completions"
    assert captured["auth"]=="Bearer temporary-secret"
    assert captured["body"]["model"]=="grok-test"
    assert captured["timeout"]==12
    assert "temporary-secret" not in repr(captured["body"])


def test_openai_responses_api_adapter(monkeypatch):
    from flybrain_os.model_hub import _post_chat
    monkeypatch.setenv("OPENAI_API_KEY", "test-secret")
    captured={}
    class Response:
        def __enter__(self): return self
        def __exit__(self,*args): pass
        def read(self,n): return json.dumps({"output_text":"Responses API result"}).encode()
    def fake_open(req,timeout):
        captured["url"]=req.full_url
        captured["body"]=json.loads(req.data)
        return Response()
    provider=Provider("openai","https://api.openai.com/v1","gpt-test","OPENAI_API_KEY",False,"responses")
    assert _post_chat(provider,"Research prompt",opener=fake_open)=="Responses API result"
    assert captured["url"]=="https://api.openai.com/v1/responses"
    assert captured["body"]=={"model":"gpt-test","input":"Research prompt"}


def test_local_only_filters_remote_providers_and_reports_privacy(tmp_path):
    providers=[Provider("ollama","http://127.0.0.1:11434/v1","local","",True),
               Provider("openai","https://api.openai.com/v1","remote","OPENAI_API_KEY")]
    called=[]
    def fake_call(provider,prompt,timeout=45):
        called.append(provider.provider_id)
        return "ok"
    result=ModelConsultation(tmp_path/"ledger.sqlite").consult("private task",providers=providers,caller=fake_call,local_only=True)
    assert called==["ollama"]
    assert result["privacy"]=={"local_only":True,"providers_receiving_task":["ollama"],"external_data_transfer":False}


def test_provider_check_reports_reachability_without_leaking_token(monkeypatch):
    from flybrain_os.model_hub import check_provider
    monkeypatch.setenv("XAI_API_KEY","secret-token")
    class Response:
        def __enter__(self): return self
        def __exit__(self,*args): pass
        def read(self,n): return json.dumps({"data":[{"id":"grok-test"}]}).encode()
    def fake_open(req,timeout):
        assert req.get_header("Authorization")=="Bearer secret-token"
        return Response()
    result=check_provider(Provider("xai","https://api.x.ai/v1","grok-test","XAI_API_KEY",False,"responses"),opener=fake_open)
    assert result["status"]=="reachable" and result["configured_model_listed"] is True
    assert "secret-token" not in repr(result)
