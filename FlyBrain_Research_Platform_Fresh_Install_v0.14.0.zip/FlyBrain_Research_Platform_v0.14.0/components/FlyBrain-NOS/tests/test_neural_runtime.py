import pytest
from flybrain_os.neural_runtime import LIFConfig, simulate_lif


def test_lif_is_deterministic_and_emits_spikes():
    cfg=LIFConfig(dt_ms=1,tau_m_ms=5,rest_mv=0,reset_mv=0,threshold_mv=1,refractory_ms=1)
    a=simulate_lif(["a"],[],{"a":10},5,cfg)
    b=simulate_lif(["a"],[],{"a":10},5,cfg)
    assert a==b and a["spike_counts"]["a"]>0


def test_lif_propagates_spike_to_target_next_step():
    cfg=LIFConfig(dt_ms=1,tau_m_ms=1,rest_mv=0,reset_mv=0,threshold_mv=.5,refractory_ms=0,synaptic_gain=10)
    out=simulate_lif(["src","dst"],[("src","dst",1)],{"src":10},3,cfg)
    assert "src" in out["spike_trace"][0]
    assert "dst" in out["spike_trace"][1]


def test_lif_rejects_unknown_edge_endpoint():
    with pytest.raises(ValueError): simulate_lif(["a"],[("a","b",1)],{},1)


def test_lif_rejects_nonfinite_weight():
    with pytest.raises(ValueError): simulate_lif(["a"],[("a","a",float("nan"))],{},1)


def test_lif_rejects_invalid_configuration():
    with pytest.raises(ValueError): simulate_lif(["a"],[],{},1,LIFConfig(dt_ms=0))


def test_lif_no_current_does_not_spike_from_rest():
    out=simulate_lif(["a"],[],{},10)
    assert out["spike_counts"]["a"]==0


def test_lif_rejects_unknown_input_neuron():
    with pytest.raises(ValueError): simulate_lif(["a"],[],{"missing":1},1)
