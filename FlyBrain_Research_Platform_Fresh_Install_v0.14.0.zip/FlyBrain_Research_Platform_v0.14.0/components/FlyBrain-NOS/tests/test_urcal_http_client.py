import json
import threading
import pytest
from wsgiref.simple_server import make_server
from flybrain_os.urcal_http_client import FlyBrainURCALHTTPClient, URCALHTTPError


def test_flybrain_http_client_integrates_with_urcal_wsgi(tmp_path):
    jobs = pytest.importorskip("urcal.jobs", reason="install/ expose URCAL source to run cross-project integration")
    api = pytest.importorskip("urcal.http_api", reason="install/ expose URCAL source to run cross-project integration")
    JobStore = jobs.JobStore
    URCALHTTPApp = api.URCALHTTPApp
    token="local-integration-token-with-32-chars"
    server=make_server("127.0.0.1",0,URCALHTTPApp(JobStore(tmp_path/"jobs.sqlite"),token))
    thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
    try:
        client=FlyBrainURCALHTTPClient(f"http://127.0.0.1:{server.server_port}",token)
        created=client.submit_research_job("flybrain/fb-http-1",{"experiment":"connectome"},idempotency_key="fb-http-key")
        assert created["state"]=="queued"
        fetched=client.get_job("flybrain/fb-http-1")
        assert fetched["task_id"]=="flybrain/fb-http-1" and fetched["state"]=="queued"
    finally:
        server.shutdown(); thread.join(timeout=2); server.server_close()


def test_http_client_requires_https_for_remote_hosts():
    with pytest.raises(ValueError): FlyBrainURCALHTTPClient("http://example.com","x")


def test_http_client_requires_token():
    with pytest.raises(ValueError): FlyBrainURCALHTTPClient("http://127.0.0.1:8000","short")


def test_http_client_rejects_hostname_prefix_spoofing():
    with pytest.raises(ValueError): FlyBrainURCALHTTPClient("http://127.0.0.1.attacker.invalid","local-integration-token-with-32-chars")


def test_http_client_rejects_query_or_fragment_in_base_url():
    token="local-integration-token-with-32-chars"
    with pytest.raises(ValueError): FlyBrainURCALHTTPClient("https://example.com/api?token=x",token)

def test_http_client_validates_job_payload():
    client=FlyBrainURCALHTTPClient("http://127.0.0.1:8000","local-integration-token-with-32-chars")
    with pytest.raises(ValueError): client.submit_research_job("",{})
    with pytest.raises(ValueError): client.submit_research_job("fb/1",[])
    with pytest.raises(ValueError): client.submit_research_job("fb/1",{},max_cost=-1)

def test_http_client_bounds_response_size(monkeypatch):
    import flybrain_os.urcal_http_client as module
    class Response:
        def __enter__(self): return self
        def __exit__(self,*args): return False
        def read(self,n): return b"x"*(1024*1024+1)
    monkeypatch.setattr(module,"urlopen",lambda *a,**k: Response())
    client=FlyBrainURCALHTTPClient("http://127.0.0.1:8000","local-integration-token-with-32-chars")
    with pytest.raises(URCALHTTPError,match="1 MiB"):
        client.get_job("fb/large")

def test_http_client_does_not_echo_remote_error_body(monkeypatch):
    from urllib.error import HTTPError
    import io
    import flybrain_os.urcal_http_client as module
    secret="do-not-echo-this-secret"
    def fail(*args,**kwargs):
        raise HTTPError("http://localhost",401,"Unauthorized",{},io.BytesIO(secret.encode()))
    monkeypatch.setattr(module,"urlopen",fail)
    client=FlyBrainURCALHTTPClient("http://127.0.0.1:8000","local-integration-token-with-32-chars")
    with pytest.raises(URCALHTTPError) as err:
        client.get_job("fb/1")
    assert secret not in str(err.value)
