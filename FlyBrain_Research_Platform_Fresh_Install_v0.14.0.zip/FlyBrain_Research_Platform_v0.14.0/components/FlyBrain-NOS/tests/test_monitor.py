import json
from flybrain_os.monitor import FetchResult, SourceMonitor, normalize_body, write_report


def test_normalize_html_removes_scripts_and_collapses_whitespace():
    body=b'<html><script>ignore me</script><h1>FlyWire</h1><p> New   dataset </p></html>'
    text=normalize_body(body,'text/html')
    assert 'FlyWire' in text and 'New dataset' in text and 'ignore me' not in text


def test_monitor_baseline_then_unchanged_then_changed(tmp_path):
    content={"body":b'<html><h1>FAFB v783</h1></html>'}
    def fake_fetch(url, **kwargs):
        return FetchResult(200,content['body'],'etag-1','Mon, 01 Jan 2024 00:00:00 GMT','text/html')
    monitor=SourceMonitor(tmp_path/'state.sqlite',fetcher=fake_fetch)
    source={"id":"codex","url":"https://example.test"}
    assert monitor.check(source)['status']=='baseline_created'
    assert monitor.check(source)['status']=='unchanged'
    content['body']=b'<html><h1>FAFB v784</h1><p>New snapshot</p></html>'
    third=monitor.check(source)
    assert third['status']=='changed'
    assert 'FAFB v784' in third['change_excerpt']


def test_monitor_handles_http_304(tmp_path):
    calls=[]
    def fake_fetch(url, **kwargs):
        calls.append(kwargs)
        if len(calls)==1: return FetchResult(200,b'initial','etag-x','date-x','text/plain')
        assert kwargs['etag']=='etag-x'
        return FetchResult(304,b'','etag-x','date-x','')
    monitor=SourceMonitor(tmp_path/'state.sqlite',fetcher=fake_fetch)
    source={"id":"x","url":"https://example.test"}
    assert monitor.check(source)['status']=='baseline_created'
    assert monitor.check(source)['status']=='unchanged'


def test_run_and_report(tmp_path):
    def fake_fetch(url, **kwargs): return FetchResult(200,b'OK','','','text/plain')
    m=SourceMonitor(tmp_path/'state.sqlite',fetcher=fake_fetch)
    report=m.run({"sources":[{"id":"one","url":"https://example.test"}]})
    assert report['checked']==1 and report['errors']==0
    target=tmp_path/'report.json'; write_report(report,target)
    assert json.loads(target.read_text())['checked']==1
