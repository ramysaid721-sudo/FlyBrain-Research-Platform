import csv, json
import pytest
from flybrain_os.connectome import DatasetManifest, Edge, load_edges_csv, sha256_file, write_bundle
from flybrain_os.mapping import CircuitAssignment, assignments_from_json

def manifest(tmp_path):
    f=tmp_path/"source.csv"; f.write_text("a,b\n1,2\n")
    return DatasetManifest("test","v1","test.csv","https://example.org/test",sha256_file(f),"CC0","test attribution","2026-11-16")

def test_root_ids_preserved_as_strings(tmp_path):
    p=tmp_path/"edges.csv"
    p.write_text("pre_root_id,post_root_id,syn_count,neuropil\n9007199254740993123,9007199254740993999,7,AL\n")
    e=load_edges_csv(p)[0]
    assert e.source_id == "9007199254740993123"
    assert e.synapse_count == 7

def test_synapse_count_not_converted_to_weight():
    e=Edge("a","b",12); e.validate()
    assert not hasattr(e,"weight")

def test_negative_synapse_count_rejected():
    with pytest.raises(ValueError): Edge("a","b",-1).validate()

def test_bad_probability_rejected():
    with pytest.raises(ValueError): Edge("a","b",1,neurotransmitter_probabilities={"GABA":1.2}).validate()

def test_missing_csv_column_rejected(tmp_path):
    p=tmp_path/"bad.csv"; p.write_text("a,b\n1,2\n")
    with pytest.raises(ValueError): load_edges_csv(p)

def test_bundle_and_provenance(tmp_path):
    e=[Edge("n1","n2",3)]
    out=tmp_path/"bundle"; s=write_bundle(out,manifest(tmp_path),e)
    assert s["edge_rows"] == 1
    assert s["synapse_counts_are_weights"] is False
    assert json.loads((out/"manifest.json").read_text())["license"] == "CC0"

def test_function_claim_requires_evidence():
    with pytest.raises(ValueError):
        CircuitAssignment("c1",("n1",),"shared neuropil", "motor control", None).validate()

def test_anatomical_assignment_without_function_is_valid():
    CircuitAssignment("c1",("n1",),"shared neuropil").validate()

def test_functional_assignment_with_evidence_is_valid():
    result=assignments_from_json([{"circuit_id":"c1","neuron_ids":["n1"],"anatomical_basis":"published region","proposed_function":"candidate sensory pathway","function_evidence":"inferred","source_reference":"doi:example"}])
    assert len(result)==1
