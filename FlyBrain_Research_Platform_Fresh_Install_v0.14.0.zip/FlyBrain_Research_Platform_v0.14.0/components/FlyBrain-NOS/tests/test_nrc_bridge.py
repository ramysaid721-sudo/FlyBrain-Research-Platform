from flybrain_os.nrc_bridge import NRCBridge
from flybrain_os.collaboration import CollaborationLedger


def test_nrc_bridge_roundtrip_with_flybrain(tmp_path):
    nrc=NRCBridge(tmp_path/"nrc.sqlite")
    fly=CollaborationLedger(tmp_path/"fly.sqlite","flybrain-nos")
    msg=nrc.publish("research_proposal",{"title":"test","evidence":"hypothesis"})
    packet=tmp_path/"out.jsonl"
    assert nrc.export_outbox(packet)==1
    assert fly.import_jsonl(packet)["imported"]==1
    fly.create_message("nrc","test_report",{"passed":True},message_id="test-report")
    reply=tmp_path/"reply.jsonl"
    fly.export_jsonl(reply,recipient="nrc")
    assert nrc.import_inbox(reply)["imported"]==1
    nrc.review("test-report","accepted","Verified schema roundtrip")
    assert nrc.status()["reviews"]==1
