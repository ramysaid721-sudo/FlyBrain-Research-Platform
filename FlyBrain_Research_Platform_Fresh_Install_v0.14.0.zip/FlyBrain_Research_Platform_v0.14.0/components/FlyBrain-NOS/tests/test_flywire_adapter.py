import csv
import json
import pytest
from flybrain_os.flywire import (
    DATASET_REPO, DATASET_VERSION, FlyWireDatasetSpec, iter_flywire_edges_csv,
    iter_flywire_nodes_csv, write_flywire_source_record, flywire_manifest,
)


def write_edges(path, rows=None):
    cols = ["pre", "post", "syn_count", "gaba", "ach", "glut", "oct", "ser", "da"]
    rows = rows or [["9007199254740993123", "9007199254740993999", 7, .1, .2, .3, .1, .1, .2]]
    with path.open("w", newline="") as f:
        w = csv.writer(f); w.writerow(cols); w.writerows(rows)


def test_flywire_dataset_spec_is_evidence_labelled():
    s = FlyWireDatasetSpec(); s.validate()
    assert s.repository == DATASET_REPO
    assert s.snapshot == DATASET_VERSION
    assert s.synapse_counts_are_physiological_weights is False


def test_flywire_edge_import_preserves_64bit_ids_and_nt_probabilities(tmp_path):
    p = tmp_path / "edges.csv"; write_edges(p)
    e = list(iter_flywire_edges_csv(p))[0]
    assert e.source_id == "9007199254740993123"
    assert e.target_id == "9007199254740993999"
    assert e.synapse_count == 7
    assert e.neurotransmitter_probabilities["ach"] == .2
    assert e.evidence == "measured"
    assert e.neurotransmitter_evidence == "inferred"


def test_flywire_rejects_bad_probability_sum(tmp_path):
    p = tmp_path / "edges.csv"
    write_edges(p, [["1", "2", 1, .1, .1, .1, .1, .1, .1]])
    with pytest.raises(ValueError, match="sum"):
        list(iter_flywire_edges_csv(p))


def test_flywire_rejects_missing_columns(tmp_path):
    p = tmp_path / "edges.csv"; p.write_text("pre,post,syn_count\n1,2,1\n")
    with pytest.raises(ValueError, match="missing FlyWire columns"):
        list(iter_flywire_edges_csv(p))


def test_flywire_node_predictions_not_verified(tmp_path):
    p = tmp_path / "nodes.csv"
    p.write_text("root_id,flow,super_class,cell_class,cell_sub_class,cell_type,hemibrain_type,hemilineages,top_nt,top_nt_conf,side,nerve,vfb_id,fbbt_id\n"
                  "9007199254740993123,in,central,interneuron,x,KC,,lineage1,ACH,0.91,left,,,\n")
    a = list(iter_flywire_nodes_csv(p))[0]
    assert a.root_id == "9007199254740993123"
    assert a.values["transmitter_prediction"] == "ACH"
    assert a.values["transmitter_verified"] is False
    assert a.values["transmitter_confidence"] == .91


def test_flywire_duplicate_node_ids_rejected(tmp_path):
    p = tmp_path / "nodes.csv"
    p.write_text("root_id,super_class,cell_class,cell_type,top_nt,top_nt_conf\n1,c,a,b,ACH,.9\n1,c,a,b,ACH,.9\n")
    with pytest.raises(ValueError, match="duplicate root_id"):
        list(iter_flywire_nodes_csv(p))


def test_flywire_manifest_uses_real_local_checksum(tmp_path):
    p = tmp_path / "download.csv"; p.write_text("abc")
    m = flywire_manifest(p, imported_at="2026-11-16")
    assert len(m.source_sha256) == 64
    assert m.snapshot == "FAFB_v783"


def test_source_record_does_not_claim_download(tmp_path):
    p = tmp_path / "source.json"
    data = write_flywire_source_record(p)
    saved = json.loads(p.read_text())
    assert data["local_data_downloaded"] is False
    assert saved["status"] == "source_verified_metadata_only"


def test_structural_and_transmitter_evidence_are_separate(tmp_path):
    p = tmp_path / "edges.csv"; write_edges(p)
    e = list(iter_flywire_edges_csv(p))[0]
    assert e.evidence == "measured"
    assert e.neurotransmitter_evidence == "inferred"


def test_parquet_adapter_reports_optional_dependency_when_absent(tmp_path):
    import importlib.util
    if importlib.util.find_spec("pyarrow") is not None:
        pytest.skip("pyarrow is installed")
    from flybrain_os.flywire import iter_flywire_edges_parquet
    with pytest.raises(RuntimeError, match="pyarrow"):
        list(iter_flywire_edges_parquet(tmp_path / "not-used.parquet"))
