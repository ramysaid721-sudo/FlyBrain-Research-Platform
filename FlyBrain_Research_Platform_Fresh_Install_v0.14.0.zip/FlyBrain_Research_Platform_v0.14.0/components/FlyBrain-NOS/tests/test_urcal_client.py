import pytest
from flybrain_os.urcal_client import FlyBrainURCALClient, FlyBrainResourcePolicy
class FakeGateway:
    def __init__(self): self.calls=[]
    def submit_job(self,principal,task,payload):
        self.calls.append((principal,task,payload)); return {"state":"queued"}
    def get_job(self,principal,task_id): return {"task_id":task_id}
def test_flybrain_client_uses_owned_policy_and_idempotency():
    g=FakeGateway(); c=FlyBrainURCALClient(g,"flybrain-instance",
        FlyBrainResourcePolicy(frozenset({"python","cpu"}),max_cost=0))
    out=c.submit_research_job("fb-1",{"analysis":"connectome"},idempotency_key="fb-1-key")
    assert out["state"]=="queued"
    principal,task,payload=g.calls[0]
    assert principal=="flybrain-instance"
    assert task.required_capabilities==frozenset({"python","cpu"})
    assert task.idempotency_key=="fb-1-key"
    assert payload["analysis"]=="connectome"
def test_flybrain_client_rejects_missing_gateway():
    with pytest.raises(ValueError):
        FlyBrainURCALClient(None,"x",FlyBrainResourcePolicy(frozenset()))

def test_flybrain_client_to_real_urcal_gateway(tmp_path):
    pytest.importorskip("urcal.jobs", reason="URCAL source required for cross-project integration")
    from urcal.jobs import JobStore
    from urcal.gateway import APIGateway
    g=APIGateway(lambda principal: principal=="flybrain-prod",JobStore(tmp_path/"jobs.sqlite"))
    c=FlyBrainURCALClient(g,"flybrain-prod",FlyBrainResourcePolicy(frozenset({"cpu"})))
    created=c.submit_research_job("fb-e2e",{"dataset":"snapshot-A"})
    assert created["state"]=="queued"
    assert c.get_job("fb-e2e")["state"]=="queued"
