# FlyBrain-NOS 0.12.0 — Connectome-Centred Neural Operating System

A standalone prototype for building a Drosophila-connectome-centred neural operating architecture.

## What is new

- FlyWire FAFB v783 source integration: provenance-checked metadata, streaming edge/node adapters, Parquet support via optional PyArrow, and explicit separation of observed connectivity from predicted neurotransmitter labels (0.9.0).

- Multi-model research hub with OpenAI and xAI Responses API support, compatible Chat Completions adapters, provider reachability diagnostics, and an explicit local-only privacy mode (0.8.0).

- Topology-first circuit candidate extraction from seed neurons, neuropil filters, hop radius, direction, and node caps.
- Descriptive graph metrics (degree, reciprocal-pair fraction, observed synapse totals) with no conversion to physiological weights.
- Experimental discrete-time activation propagation with explicit synthetic parameters, isolated from biological claims.

- Evidence-aware connectome edge ingestion from CSV.
- Dataset/snapshot provenance manifest with source checksum and licensing fields.
- Root IDs preserved as strings to avoid precision loss.
- Directed edges retain observed synapse counts without inventing signed weights or synaptic efficacy.
- Separate circuit-mapping records for anatomical basis and proposed functional interpretation.
- CLI validation and JSONL bundle export.

## Quick start

```bash
python -m pip install -e .
pytest -q
flybrain-nos validate-csv edges.csv --dataset FAFB --snapshot v783 \
  --source-name proofread_connections_783.feather --source-url 'https://...' \
  --license 'verify exact file terms' --attribution 'FlyWire; cite source paper' \
  --imported-at 2026-11-16 --output data/imported_fafb_v783
```

Example circuit extraction:

```bash
flybrain-nos extract-circuit edges.csv --seed 720575940000000001 --hops 2 \
  --direction both --min-synapses 5 --output candidate.json
```

The temporal sandbox (`flybrain_os.temporal.simulate_steps`) and experimental leaky-integrate-and-fire runtime (`flybrain_os.neural_runtime.simulate_lif`) are Python APIs. Both are synthetic engineering/research models, not biologically validated Drosophila simulators. LIF parameters and signed weights must be explicitly supplied; connectome synapse counts are not converted into physiological weights.

The current importer accepts CSV edge tables. Convert Feather/Parquet exports to CSV with a separately audited conversion step, preserving integer IDs as strings. No large dataset is downloaded automatically.

## Scope and limitations

This is an ingestion, evidence-governance and experimental-runtime layer, not a biologically faithful fly-brain simulation. It does not infer synaptic signs, efficacy, temporal dynamics, neuromodulation, plasticity, or circuit function from edge counts. The runtime remains independently operable and has no mandatory runtime dependency on NRC. Bidirectional research exchange is available through the optional collaboration protocol.

## Development relationship

NRC is intended to serve as the research and engineering environment that helps develop and test FlyBrain-NOS. This package does not contain or import NRC. A verified NRC runtime was not available in the current execution environment, so this release was developed and tested directly rather than claiming that NRC executed the build.

## Neuron annotation ingestion and local catalog (0.4.0)

Normalize an annotation CSV or JSON list. Required identity is `root_id`; dataset and snapshot are supplied explicitly so records cannot be silently mixed across releases. Optional fields include `cell_type`, `class`, `super_class`, `side`, `neuropils`, `transmitter_prediction`, `transmitter_confidence`, `transmitter_verified`, `confidence`, `source_reference`, and `notes`. Unknown fields are rejected rather than silently discarded.

```bash
flybrain-nos import-annotations neurons.json --dataset FAFB --snapshot v783 \
  --output data/annotations-fafb-v783.jsonl --catalog data/research.sqlite
flybrain-nos catalog-stats data/research.sqlite
```

`evidence` is one of `measured`, `inferred`, `assumed`, or `synthetic` (default: `inferred`). A predicted transmitter and a verified transmitter are separate fields; predictions are not promoted to measured facts. Re-importing an existing key fails unless `--replace` is explicitly supplied.

Circuit candidates can also be registered in the same catalog:

```bash
flybrain-nos extract-circuit edges.csv --seed 720575940000000001 --hops 2 \
  --dataset FAFB --snapshot v783 --catalog data/research.sqlite --output candidate.json
```

The catalog is local SQLite storage. It does not synchronize to a cloud service, fetch connectome data, or infer cell function. Dataset snapshot identity is mandatory when registering candidates.

## Local source update monitor (0.5.0)

FlyBrain-NOS now includes a local source monitor for public FlyWire/Codex and connectome project pages. Run `python -m flybrain_os.cli monitor-sources` to create/update a local SQLite baseline and JSON report. It checks pages only (2 MB response cap), does not download connectome payloads, and must be scheduled by the host operating system if recurring checks are wanted. See `docs/SOURCE_MONITOR.md`.


## Multi-model research hub (0.7.0)

Supports parallel consultation with OpenAI API, xAI/Grok, Hugging Face Inference Providers, OpenRouter, local Ollama, Groq, Together, Fireworks, DeepSeek, Mistral, Gemini, and custom OpenAI-compatible providers. Credentials are environment-only. Run `flybrain-nos model-hub-status`, `flybrain-nos model-task-plan "..."`, or `flybrain-nos model-consult "..."`. See `docs/MULTI_MODEL_HUB.md` for configuration, cost/privacy considerations, and safety rules. Model responses are untrusted research inputs; no generated code is auto-executed.


## NRC-side adapter (0.7.1)

Added `NRCBridge`, a portable NRC-side adapter for publishing proposals, exporting/importing JSONL packets, reviewing received messages, and checking collaboration status. It does not imply that NRC itself was installed or executed. See `docs/NRC_BRIDGE.md`.


## Multi-model research hub (0.8.0)

Use `python -m flybrain_os.cli model-hub-status` to inspect configured providers and local resources; `model-provider-check` to probe metadata endpoints; and `model-consult "..." --local-only` to keep a research prompt on configured local Ollama only. OpenAI and xAI use Responses API; other compatible providers use Chat Completions. See `docs/MULTI_MODEL_HUB.md`.


## FlyWire FAFB v783 source adapter (0.9.0)

A public source package was inspected and its metadata and sample rows validated. See `docs/FLYWIRE_V783_INTEGRATION.md`. The adapter exposes `iter_flywire_edges_csv`, `iter_flywire_edges_parquet` (optional `pyarrow`), `iter_flywire_nodes_csv`, and `flywire_manifest`. Root IDs remain strings; observed synapse counts are not physiological weights; predicted neurotransmitter probabilities remain explicitly inferred/unverified. The full 476.6 MB remote package has not been downloaded or imported.


## Experimental spiking runtime (0.12.0)

The generic LIF engine is available as `flybrain_os.neural_runtime.simulate_lif`. It returns membrane-voltage traces, spike events and per-neuron spike counts. A spike at time step *t* affects downstream neurons at step *t+1*. Parameters and weights are experiment inputs and must be documented and calibrated before biological interpretation. See `docs/NEURAL_RUNTIME_STATUS.md`.

## Optional URCAL integration

The FlyBrain URCAL HTTP client uses only the Python standard library and does not require the URCAL Python package. To run the cross-project WSGI integration test, expose the URCAL source tree on `PYTHONPATH` (for example, `PYTHONPATH=/path/to/URCAL python -m pytest -q`). Without URCAL installed, the standalone FlyBrain suite still runs; only that cross-project integration test is skipped. Install the test extra with `pip install -e ".[test]"`.


## Independent URCAL HTTP integration (0.13.0)

`flybrain_os.urcal_http_client.FlyBrainURCALHTTPClient` connects to URCAL over its authenticated HTTP API without importing the URCAL Python package. Provide the URCAL base URL and a bearer token through deployment configuration. Remote endpoints must use HTTPS; unencrypted HTTP is allowed only for loopback development. This is a bounded, authenticated job-submission/status transport, not a provider execution engine. Response bodies are capped at 1 MiB and remote error bodies are not echoed into diagnostics.
