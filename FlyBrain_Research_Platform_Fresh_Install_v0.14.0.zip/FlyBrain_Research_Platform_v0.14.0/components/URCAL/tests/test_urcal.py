import time
import pytest
from urcal import Provider, ProviderRegistry, TaskSpec, Router, Policy, NoEligibleProvider
from urcal.adapters import DryRunAdapter, RetryPolicy, submit_with_retry
from urcal.audit import AuditLog
from urcal.jobs import JobStore
from urcal.resources import ResourceManager
from urcal.monitoring import ProviderHealthMonitor, PricingVerifier
from urcal.gateway import APIGateway, AuthenticationError
from urcal.discovery import discover, match_capabilities
from urcal.results import validate_result

NOW=time.time()
def p(pid,caps={"cpu"},state="available",pricing="free",quota=10,cost=0,region=None):
    return Provider(pid,pid,frozenset(caps),state,pricing,quota,cost,region,{},NOW,NOW,NOW)
def task(task_id="t-1",caps={"cpu"},units=1,max_cost=0,idem=None):
    return TaskSpec(task_id,frozenset(caps),units,max_cost,idempotency_key=idem)

def test_selects_available_free_provider():
    r=ProviderRegistry(); r.register(p("a"))
    assert Router(r,Policy()).plan(task(),now=NOW).provider_id=="a"
def test_discovered_is_not_executable():
    r=ProviderRegistry(); r.register(p("a",state="discovered"))
    with pytest.raises(NoEligibleProvider): Router(r,Policy()).plan(task(),now=NOW)
def test_configured_is_not_executable():
    r=ProviderRegistry(); r.register(p("a",state="configured"))
    with pytest.raises(NoEligibleProvider): Router(r,Policy()).plan(task(),now=NOW)
def test_paid_rejected_by_default():
    r=ProviderRegistry(); r.register(p("a",pricing="paid",cost=1))
    with pytest.raises(NoEligibleProvider): Router(r,Policy()).plan(task(max_cost=2),now=NOW)
def test_unknown_price_rejected():
    r=ProviderRegistry(); r.register(p("a",pricing="unknown",cost=None))
    with pytest.raises(NoEligibleProvider): Router(r,Policy()).plan(task(),now=NOW)
def test_missing_capability_rejected():
    r=ProviderRegistry(); r.register(p("a"))
    with pytest.raises(NoEligibleProvider): Router(r,Policy()).plan(task(caps={"gpu"}),now=NOW)
def test_quota_checked():
    r=ProviderRegistry(); r.register(p("a",quota=0))
    with pytest.raises(NoEligibleProvider): Router(r,Policy()).plan(task(units=1),now=NOW)
def test_quota_boundary_allowed():
    r=ProviderRegistry(); r.register(p("a",quota=1))
    assert Router(r,Policy()).plan(task(),now=NOW).provider_id=="a"
def test_preferred_region_wins():
    r=ProviderRegistry(); r.register(p("a",quota=10,region="eu")); r.register(p("b",quota=2,region="us"))
    assert Router(r,Policy()).plan(TaskSpec("x",frozenset({"cpu"}),preferred_regions=frozenset({"us"})),now=NOW).provider_id=="b"
def test_more_quota_breaks_tie():
    r=ProviderRegistry(); r.register(p("a",quota=2)); r.register(p("b",quota=8))
    assert Router(r,Policy()).plan(task(),now=NOW).provider_id=="b"
def test_fallback_candidates_returned():
    r=ProviderRegistry(); r.register(p("a")); r.register(p("b"))
    assert len(Router(r,Policy()).plan(task(),now=NOW).fallback_candidates)==1
def test_failover_excludes_failed_even_if_preferred():
    r=ProviderRegistry(); r.register(p("a",quota=20)); r.register(p("b",quota=5))
    assert Router(r,Policy()).failover(task(),"a",now=NOW).provider_id=="b"
def test_failover_excludes_multiple_failed():
    r=ProviderRegistry(); [r.register(p(x)) for x in "abc"]
    assert Router(r,Policy()).failover(task(),"a",excluded={"b"},now=NOW).provider_id=="c"
def test_no_fallback_when_only_one():
    r=ProviderRegistry(); r.register(p("a"))
    with pytest.raises(NoEligibleProvider): Router(r,Policy()).failover(task(),"a",now=NOW)
def test_lifecycle_transition():
    r=ProviderRegistry(); r.register(p("a",state="discovered"))
    r.update_state("a","configured"); r.update_state("a","tested"); r.update_state("a","available")
    assert r.get("a").state=="available"
def test_invalid_lifecycle_transition():
    r=ProviderRegistry(); r.register(p("a",state="discovered"))
    with pytest.raises(ValueError): r.update_state("a","available")
def test_update_quota_timestamp():
    r=ProviderRegistry(); r.register(p("a")); r.update_quota("a",3,verified_at=NOW)
    assert r.get("a").quota_remaining==3 and r.get("a").quota_verified_at==NOW
def test_negative_quota_rejected():
    with pytest.raises(ValueError): p("a",quota=-1)
def test_empty_id_rejected():
    with pytest.raises(ValueError): Provider(" ","x")
def test_invalid_state_rejected():
    with pytest.raises(ValueError): p("a",state="online")
def test_invalid_pricing_rejected():
    with pytest.raises(ValueError): p("a",pricing="maybe")
def test_negative_task_cost_rejected():
    with pytest.raises(ValueError): TaskSpec("x",frozenset(),max_cost=-1)
def test_budget_guard():
    r=ProviderRegistry(); r.register(p("a",cost=.01))
    with pytest.raises(NoEligibleProvider): Router(r,Policy(global_budget=0)).plan(task(max_cost=1),now=NOW)
def test_task_max_cost_guard():
    r=ProviderRegistry(); r.register(p("a",cost=.01))
    with pytest.raises(NoEligibleProvider): Router(r,Policy(global_budget=1)).plan(task(max_cost=0),now=NOW)
def test_free_zero_cost_allowed():
    r=ProviderRegistry(); r.register(p("a",cost=0))
    assert Router(r,Policy()).plan(task(),now=NOW).provider_id=="a"
def test_persistent_audit_survives_reopen(tmp_path):
    path=tmp_path/"audit.sqlite"; a=AuditLog(path); a.append("planned",{"task":"t"})
    assert AuditLog(path).events()[0]["event_type"]=="planned"
def test_dry_run_adapter_success():
    a=DryRunAdapter(); assert a.health_check().ok and a.submit({"task_id":"x"}).ok
def test_dry_run_adapter_failure():
    a=DryRunAdapter(fail=True); assert not a.health_check().ok and not a.submit({"task_id":"x"}).ok
def test_duplicate_provider_id_rejected():
    r=ProviderRegistry(); r.register(p("a"))
    with pytest.raises(ValueError): r.register(p("a"))
def test_stale_pricing_rejected():
    r=ProviderRegistry(); r.register(p("a"))
    with pytest.raises(NoEligibleProvider): Router(r,Policy(pricing_ttl_seconds=1)).plan(task(),now=NOW+2)
def test_stale_quota_rejected():
    r=ProviderRegistry(); r.register(p("a"))
    with pytest.raises(NoEligibleProvider): Router(r,Policy(quota_ttl_seconds=1)).plan(task(),now=NOW+2)
def test_unknown_quota_rejected_by_default():
    r=ProviderRegistry(); r.register(p("a",quota=None))
    with pytest.raises(NoEligibleProvider): Router(r,Policy()).plan(task(),now=NOW)
def test_capability_superset_allowed():
    r=ProviderRegistry(); r.register(p("a",caps={"cpu","python","memory"}))
    assert Router(r,Policy()).plan(task(caps={"cpu","python"}),now=NOW).provider_id=="a"
def test_discovery_does_not_claim_connection():
    d=discover([{"provider_id":"x","capabilities":["cpu"]}])
    assert d[0]["state"]=="discovered" and not d[0]["connectivity_verified"]
def test_capability_match():
    assert len(match_capabilities({"cpu"},[p("a"),p("b",caps={"gpu"})]))==1
def test_atomic_budget_reservation(tmp_path):
    rm=ResourceManager(tmp_path/"r.sqlite",global_budget=1)
    t1=task("1",max_cost=1); t2=task("2",max_cost=1); provider=p("a",cost=.75)
    rm.reserve(t1,provider)
    with pytest.raises(ValueError): rm.reserve(t2,provider)
def test_idempotent_job_submission(tmp_path):
    js=JobStore(tmp_path/"j.sqlite"); t=task("one",idem="same")
    assert not js.create(t,{"x":1})["duplicate"]
    assert js.create(task("two",idem="same"),{"x":1})["duplicate"]
def test_idempotency_key_payload_conflict(tmp_path):
    js=JobStore(tmp_path/"j.sqlite"); js.create(task("one",idem="same"),{"x":1})
    with pytest.raises(ValueError): js.create(task("two",idem="same"),{"x":2})
def test_job_state_machine(tmp_path):
    js=JobStore(tmp_path/"j.sqlite"); js.create(task(),{"x":1})
    js.transition("t-1","submitted",provider_id="a"); js.transition("t-1","running")
    js.transition("t-1","succeeded",result={"ok":True})
    assert js.get("t-1")["state"]=="succeeded"
    with pytest.raises(ValueError): js.transition("t-1","running")
def test_health_monitor_marks_failure(tmp_path):
    r=ProviderRegistry(); r.register(p("a",state="tested"))
    mon=ProviderHealthMonitor(r,{"a":DryRunAdapter(fail=True)})
    mon.check("a"); assert r.get("a").state=="failed"
def test_pricing_verifier_requires_evidence():
    with pytest.raises(ValueError): PricingVerifier().verify(p("a"),pricing="free",estimated_cost=0,source="guess")
def test_gateway_requires_auth(tmp_path):
    gw=APIGateway(lambda who:who=="ok",JobStore(tmp_path/"j.sqlite"))
    with pytest.raises(AuthenticationError): gw.submit_job("bad",task(),{})
def test_gateway_authenticated_submit(tmp_path):
    gw=APIGateway(lambda who:who=="ok",JobStore(tmp_path/"j.sqlite"))
    assert gw.submit_job("ok",task(),{})["state"]=="queued"
def test_result_validation():
    assert validate_result({"n":2},lambda x:x["n"]>0).valid
    assert not validate_result({},lambda x:x["n"]>0).valid
def test_retry_policy_retries_only_retryable():
    class Once:
        provider_id="x"
        n=0
        def submit(self,payload):
            self.n+=1
            from urcal.adapters import AdapterResult
            return AdapterResult(self.n>1,"try",retryable=self.n==1)
        def health_check(self): pass
    a=Once(); assert submit_with_retry(a,{},RetryPolicy(2,0,0)).ok and a.n==2

def test_atomic_provider_quota_reservation(tmp_path):
    rm=ResourceManager(tmp_path/"r.sqlite",global_budget=10)
    provider=p("a",quota=1)
    rm.reserve(task("one",units=1),provider)
    with pytest.raises(ValueError): rm.reserve(task("two",units=1),provider)

def test_committed_spend_remains_in_global_budget(tmp_path):
    rm=ResourceManager(tmp_path/"r.sqlite",global_budget=1)
    provider=p("a",cost=.75)
    rid=rm.reserve(task("one",max_cost=1),provider); rm.finalize(rid,success=True)
    with pytest.raises(ValueError): rm.reserve(task("two",max_cost=1),provider)
def test_free_provider_cannot_claim_nonzero_cost():
    r=ProviderRegistry(); r.register(p("a",cost=.1))
    with pytest.raises(NoEligibleProvider): Router(r,Policy(global_budget=1)).plan(task(max_cost=1),now=NOW)
def test_health_monitor_promotes_discovered_through_lifecycle(tmp_path):
    r=ProviderRegistry(); r.register(p("a",state="discovered"))
    ProviderHealthMonitor(r,{"a":DryRunAdapter()}).check("a")
    assert r.get("a").state=="available"

def test_audit_log_rejects_mutation(tmp_path):
    path=tmp_path/"audit.sqlite"; a=AuditLog(path); a.append("safe",{"x":1})
    import sqlite3
    with sqlite3.connect(path) as c:
        with pytest.raises(sqlite3.IntegrityError): c.execute("DELETE FROM audit_events")
def test_usage_tracker_persists_and_aggregates(tmp_path):
    from urcal.usage import UsageTracker
    path=tmp_path/"usage.sqlite"; u=UsageTracker(path)
    u.record("t","p",cpu_seconds=2,input_bytes=10,output_bytes=20,estimated_cost=0)
    totals=UsageTracker(path).totals("p")
    assert totals["events"]==1 and totals["cpu_seconds"]==2 and totals["output_bytes"]==20
def test_usage_tracker_rejects_negative_values(tmp_path):
    from urcal.usage import UsageTracker
    with pytest.raises(ValueError): UsageTracker(tmp_path/"u.sqlite").record("t","p",cpu_seconds=-1)


def test_sqlite_queue_persists_and_acknowledges(tmp_path):
    from urcal.queue import SQLiteQueue
    path=tmp_path/"queue.sqlite"
    q=SQLiteQueue(path)
    assert q.enqueue({"task_id":"q-1","value":7})["duplicate"] is False
    assert q.enqueue({"task_id":"q-1","value":7})["duplicate"] is True
    job=SQLiteQueue(path).dequeue(timeout=0,worker_id="w1")
    assert job["value"]==7 and job["_queue"]["attempt"]==1
    SQLiteQueue(path).ack("q-1",worker_id="w1")
    assert q.status("q-1")["state"]=="done"


def test_sqlite_queue_rejects_idempotency_payload_conflict(tmp_path):
    from urcal.queue import SQLiteQueue
    q=SQLiteQueue(tmp_path/"q.sqlite")
    q.enqueue({"task_id":"same","x":1})
    with pytest.raises(ValueError): q.enqueue({"task_id":"same","x":2})


def test_sqlite_queue_nack_requeues_then_dead_letters(tmp_path):
    from urcal.queue import SQLiteQueue
    q=SQLiteQueue(tmp_path/"q.sqlite",max_attempts=2)
    q.enqueue({"task_id":"retry"})
    first=q.dequeue(timeout=0,worker_id="w1")
    assert q.nack("retry",error="transient",worker_id="w1")=="queued"
    second=q.dequeue(timeout=0,worker_id="w2")
    assert second["_queue"]["attempt"]==2
    assert q.nack("retry",error="terminal",worker_id="w2")=="dead"
    assert q.status("retry")["state"]=="dead"


def test_sqlite_queue_reclaims_expired_lease(tmp_path):
    from urcal.queue import SQLiteQueue
    q=SQLiteQueue(tmp_path/"q.sqlite")
    q.enqueue({"task_id":"lease"})
    q.dequeue(timeout=0,worker_id="dead-worker",lease_seconds=0.01)
    import time as _time; _time.sleep(0.02)
    reclaimed=q.dequeue(timeout=0,worker_id="new-worker")
    assert reclaimed["_queue"]["attempt"]==2
    assert reclaimed["_queue"]["worker_id"]=="new-worker"


def test_http_api_auth_submit_and_get(tmp_path):
    import io
    from urcal.http_api import URCALHTTPApp
    app=URCALHTTPApp(JobStore(tmp_path/"http.sqlite"),"test-token-that-is-at-least-24-chars")
    def call(method,path,body=b"",token=None):
        captured={}
        env={"REQUEST_METHOD":method,"PATH_INFO":path,"CONTENT_LENGTH":str(len(body)),"wsgi.input":io.BytesIO(body)}
        if token: env["HTTP_AUTHORIZATION"]="Bearer "+token
        def start(status,headers): captured.update(status=status,headers=headers)
        payload=b"".join(app(env,start))
        return captured["status"],json.loads(payload)
    import json
    status,_=call("GET","/health")
    assert status.startswith("401")
    token="test-token-that-is-at-least-24-chars"
    status,_=call("GET","/health",token=token)
    assert status.startswith("200")
    request=json.dumps({"task":{"task_id":"http-1","required_capabilities":["cpu"]},"payload":{"x":1}}).encode()
    status,created=call("POST","/v1/jobs",request,token)
    assert status.startswith("202") and created["state"]=="queued"
    status,job=call("GET","/v1/jobs/http-1",token=token)
    assert status.startswith("200") and job["task_id"]=="http-1"


def test_http_api_rejects_short_token(tmp_path):
    from urcal.http_api import URCALHTTPApp
    with pytest.raises(ValueError): URCALHTTPApp(JobStore(tmp_path/"http.sqlite"),"short")


def test_sqlite_queue_concurrent_workers_claim_once(tmp_path):
    from urcal.queue import SQLiteQueue
    from concurrent.futures import ThreadPoolExecutor
    path=tmp_path/"shared.sqlite"
    SQLiteQueue(path).enqueue({"task_id":"single-claim"})
    def take(worker): return SQLiteQueue(path).dequeue(timeout=0,worker_id=worker)
    with ThreadPoolExecutor(max_workers=8) as pool:
        results=list(pool.map(take,[f"w{i}" for i in range(8)]))
    claimed=[r for r in results if r is not None]
    assert len(claimed)==1


def test_job_store_never_persists_arbitrary_error_message(tmp_path):
    js=JobStore(tmp_path/"safe-error.sqlite"); js.create(task(),{})
    js.transition("t-1","submitted")
    js.transition("t-1","running")
    js.transition("t-1","failed",error="Bearer very-secret-token-value")
    assert js.get("t-1")["error"]=="execution_failed"


def test_queue_never_persists_arbitrary_error_message(tmp_path):
    from urcal.queue import SQLiteQueue
    q=SQLiteQueue(tmp_path/"safe-queue.sqlite")
    q.enqueue({"task_id":"safe-error"}); q.dequeue(timeout=0,worker_id="w")
    q.nack("safe-error",error="Bearer very-secret-token-value",worker_id="w")
    assert q.status("safe-error")["last_error"]=="worker_nack"


def test_job_idempotency_is_scoped_per_principal(tmp_path):
    js=JobStore(tmp_path/"principals.sqlite")
    js.create(task("fb-task",idem="same-key"),{"x":1},principal="flybrain")
    js.create(task("nrc-task",idem="same-key"),{"x":1},principal="nrc")
    assert js.get("fb-task",principal="flybrain")["task_id"]=="fb-task"
    with pytest.raises(KeyError): js.get("fb-task",principal="nrc")


def test_http_api_supports_independent_principals(tmp_path):
    import io,json
    from urcal.http_api import URCALHTTPApp
    tokens={"flybrain":"flybrain-token-with-more-than-24-chars","nrc":"nrc-token-with-more-than-24-characters"}
    app=URCALHTTPApp(JobStore(tmp_path/"multi-tenant.sqlite"),tokens)
    def call(method,path,body=b"",token=None):
        captured={}; env={"REQUEST_METHOD":method,"PATH_INFO":path,"CONTENT_LENGTH":str(len(body)),"wsgi.input":io.BytesIO(body)}
        if token: env["HTTP_AUTHORIZATION"]="Bearer "+token
        def start(status,headers): captured["status"]=status
        result=json.loads(b"".join(app(env,start)))
        return captured["status"],result
    body=json.dumps({"task":{"task_id":"flybrain-task","idempotency_key":"same"},"payload":{}}).encode()
    status,_=call("POST","/v1/jobs",body,tokens["flybrain"])
    assert status.startswith("202")
    status,_=call("GET","/v1/jobs/flybrain-task",token=tokens["nrc"])
    assert status.startswith("404")


def test_job_store_migrates_legacy_schema_without_losing_idempotency(tmp_path):
    import sqlite3,json
    path=tmp_path/"legacy.sqlite"
    with sqlite3.connect(path) as c:
        c.execute("CREATE TABLE jobs(task_id TEXT PRIMARY KEY,idempotency_key TEXT UNIQUE,payload_digest TEXT NOT NULL,provider_id TEXT,state TEXT NOT NULL,result_json TEXT,error TEXT,created_at REAL NOT NULL,updated_at REAL NOT NULL)")
        c.execute("INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?)",("legacy-task","legacy-key","digest",None,"queued",None,None,1.0,1.0))
    js=JobStore(path)
    assert js.get("legacy-task",principal="default")["task_id"]=="legacy-task"
    t=TaskSpec("new-id",frozenset(),idempotency_key="legacy-key",payload_digest="digest")
    assert js.create(t,{},principal="default")["duplicate"] is True


def test_http_api_preserves_namespaced_task_ids(tmp_path):
    import io,json
    from urcal.http_api import URCALHTTPApp
    token="namespace-test-token-with-at-least-24-chars"
    app=URCALHTTPApp(JobStore(tmp_path/"namespace.sqlite"),token)
    def call(method,path,body=b""):
        captured={}; env={"REQUEST_METHOD":method,"PATH_INFO":path,"CONTENT_LENGTH":str(len(body)),"wsgi.input":io.BytesIO(body),"HTTP_AUTHORIZATION":"Bearer "+token}
        def start(status,headers): captured["status"]=status
        result=json.loads(b"".join(app(env,start)))
        return captured["status"],result
    body=json.dumps({"task":{"task_id":"flybrain/research-7"},"payload":{}}).encode()
    status,_=call("POST","/v1/jobs",body)
    assert status.startswith("202")
    status,result=call("GET","/v1/jobs/flybrain/research-7")
    assert status.startswith("200") and result["task_id"]=="flybrain/research-7"


def test_offline_provider_catalog_loads_only_discovered_unknown_entries():
    from urcal.catalog import load_provider_registry, read_catalog
    data = read_catalog()
    registry = load_provider_registry()
    assert len(registry.all()) == len(data["providers"])
    assert all(p.state == "discovered" for p in registry.all())
    assert all(p.pricing == "unknown" and p.quota_remaining is None for p in registry.all())
    assert all(p.metadata["connection_verified"] is False for p in registry.all())

def test_cataloged_provider_is_not_routable_without_configuration_and_evidence():
    from urcal.catalog import load_provider_registry
    from urcal.router import Router, NoEligibleProvider
    from urcal.policy import Policy
    from urcal.models import TaskSpec
    registry = load_provider_registry()
    router = Router(registry, Policy(global_budget=0))
    with pytest.raises(NoEligibleProvider):
        router.plan(TaskSpec("catalog-only", frozenset({"cpu"})))

def test_catalog_separates_software_from_resource_providers():
    from urcal.catalog import read_catalog
    data = read_catalog()
    provider_ids = {x["id"] for x in data["providers"]}
    software_ids = {x["id"] for x in data["software"]}
    assert "kaggle-notebooks" in provider_ids
    assert "numpy" in software_ids and "numpy" not in provider_ids
