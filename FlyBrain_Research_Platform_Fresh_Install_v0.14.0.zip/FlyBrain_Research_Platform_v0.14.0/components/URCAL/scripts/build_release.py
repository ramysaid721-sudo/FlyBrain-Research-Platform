#!/usr/bin/env python3
"""Run URCAL checks and create a clean checksummed source release."""
from __future__ import annotations
import hashlib,json,subprocess,sys,zipfile,tomllib
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
VERSION=tomllib.loads((ROOT/'pyproject.toml').read_text())['project']['version']
OUT=ROOT.parent/f'URCAL_v{VERSION}-release.zip'
EXCLUDED={'__pycache__','.pytest_cache','.git','dist','build'}

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()
def run(args): subprocess.run(args,cwd=ROOT,check=True)
def main():
    run([sys.executable,'-m','pytest','-q'])
    run([sys.executable,'-m','compileall','-q','urcal'])
    run([sys.executable,'-m','urcal.http_api','--help'])
    files=[]
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file() or p.name=='RELEASE_MANIFEST.json' or any(x in EXCLUDED or x.endswith('.egg-info') for x in p.parts): continue
        rel=p.relative_to(ROOT)
        if p.suffix in {'.pyc','.sqlite','.db'}: continue
        files.append({'path':rel.as_posix(),'sha256':digest(p),'bytes':p.stat().st_size})
    manifest={'project':'URCAL','version':VERSION,'created_at_utc':datetime.now(timezone.utc).isoformat(timespec='seconds'),
              'verification':{'pytest':'passed','compileall':'passed','http_api_help':'passed'},'file_count':len(files),'files':files,
              'scope_note':'Source release only. No credentials, runtime databases, cloud resources or paid services included.'}
    (ROOT/'RELEASE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(ROOT.rglob('*')):
            if not p.is_file(): continue
            rel=p.relative_to(ROOT)
            if any(x in EXCLUDED or x.endswith('.egg-info') for x in rel.parts) or p.suffix in {'.pyc','.sqlite','.db'}: continue
            z.write(p,Path('URCAL')/rel)
    with zipfile.ZipFile(OUT) as z:
        bad=z.testzip()
        if bad: raise RuntimeError(f'ZIP integrity failure: {bad}')
    print(json.dumps({'archive':str(OUT),'bytes':OUT.stat().st_size,'sha256':digest(OUT),'files':len(zipfile.ZipFile(OUT).namelist())},indent=2))
if __name__=='__main__': main()
