# URCAL API contracts (Python v0.2.0)

## Domain
- `Provider`: provider identity, capabilities, lifecycle state, pricing/quota
  observations and verification timestamps.
- `TaskSpec`: task ID, required capabilities, quota estimate, task cost ceiling,
  region preferences, idempotency key, payload digest, timeout.
- `Decision`: selected provider, reason and ordered fallbacks.

## Main interfaces
- `ProviderRegistry.register/get/all/update/update_state/update_quota`
- `Router.plan(task, excluded=(), now=None)`
- `Router.failover(task, failed_provider_id, excluded=(), now=None)`
- `AuditLog.append(event_type, payload)` and `.events()`
- `ResourceManager.reserve(task, provider)`, `.finalize(id, success)`,
  `.reserved_cost()`
- `JobStore.create(task, payload)`, `.transition(task_id, state, ...)`, `.get(id)`
- `ProviderAdapter.health_check()` and `.submit(task_payload)`
- `QueueAdapter.enqueue/dequeue`
- `APIGateway.submit_job/get_job` (requires caller-supplied authentication)
- `validate_result(result, validator)`

All remote provider-specific API contracts belong in provider adapters and must
be validated against current official documentation before activation.
\n- `UsageTracker.record(...)` and `.totals(provider_id=None)`\n