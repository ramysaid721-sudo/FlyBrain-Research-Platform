# Provider and scientific software integration matrix — 2026-11-17

## Operating rule

This is a documentation and offline discovery catalog, not evidence that any account, API credential, quota or remote resource is available. All providers are loaded into URCAL as `discovered`, `pricing=unknown`, `quota_remaining=null`, `connection_verified=false`. No entry can be routed until it passes the complete lifecycle, a provider-specific health test, fresh pricing/quota verification and the user's zero-cost policy. Any paid or unknown-cost action remains blocked.

## Cloud, hosting, database and CI resources

| Resource | Offer classification | Integration surface | Important constraint | State in this workspace |
|---|---|---|---|---|
| Oracle Cloud | Always Free plus separate trial | OCI SDK / REST / Terraform | Region and capacity constraints; separate trial credits | Discovered; not connected |
| Cloudflare Workers | Permanent free tier with hard limits | Workers REST API / Wrangler / Queues | Free request and CPU limits; paid plan begins at $5/month | Discovered; not connected |
| Render | Limited free instances | Render API / Git deploy | Spin-down, ephemeral filesystem; free Postgres expires after 30 days | Discovered; not connected |
| Google Cloud | Service-specific free quotas plus trial | Google Cloud APIs / SDKs | Billing-enabled overages possible; quotas vary by service | Discovered; not connected |
| AWS | New-account credits, selected trials and Always Free services | AWS SDK / REST / CLI | Credits expire; services have separate limits and paid-only options | Discovered; not connected |
| Microsoft Azure | Trial credit plus selected free services | Azure SDK / ARM REST | Account eligibility and service-specific quotas | Discovered; not connected |
| Hugging Face Inference Providers | Small monthly free credit, then metered | InferenceClient / HTTP API | Official page lists $0.10/month for Free users, subject to change; extra use is paid | Discovered; not connected |
| GitHub Actions | Public repository standard runners free; private included minutes | GitHub Actions workflow / REST API | Private usage is plan-dependent; public Actions use is free | Discovered; no repository exposed to connector |
| GitLab CI | Plan-limited monthly shared-runner minutes | GitLab CI YAML / REST API | Shared-runner quota and storage depend on plan/namespace | Discovered; not connected |
| Deno Deploy | Limited free plan | Deno Deploy API / CLI | Recheck lifecycle notices and current usage caps before long-lived use | Discovered; not connected |
| Vercel Hobby | Free personal-project plan | Vercel REST API / CLI | Hobby plan has usage caps and eligibility restrictions | Discovered; not connected |
| Neon | Limited permanent free tier | Postgres connection / Neon API | Current free-plan quotas include compute hours, storage and transfer limits | Discovered; not connected |
| Supabase | Limited permanent free tier | Supabase REST / Postgres / SDK | Projects may pause; database, egress and storage quotas apply | Discovered; not connected |
| Upstash | Limited free tier | Redis REST / SDK | Daily commands and storage capped; avoid billing activation | Discovered; not connected |
| Backblaze B2 | Free storage allowance then paid | S3-compatible API / B2 API | Storage and egress thresholds must be enforced | Discovered; not connected |

## Research compute and developer environments

| Resource | Classification | Integration surface | Constraint / correct interpretation |
|---|---|---|---|
| Kaggle Notebooks | Free limited GPU/TPU | Notebook / Kaggle API | P100 or TPU access can be queued; weekly quota dynamic; session-limited, not a persistent worker |
| Google Colab | Free limited interactive compute | Notebook / local runtime | GPU/TPU availability and usage limits fluctuate; no guaranteed worker |
| Jupyter | Open-source software | Jupyter Server / kernels | Jupyter is an environment, not a compute entitlement; host resources are separate |
| NVIDIA CUDA | Free toolkit subject to NVIDIA license terms | CUDA runtime/toolkit | Requires compatible NVIDIA GPU and drivers; no GPU is bundled |
| AMD ROCm | Open-source stack with supported hardware matrix | ROCm runtime | Requires compatible AMD GPU, OS and driver combination |
| PyTorch | Open-source ML framework | Python API | Does not provide hosted compute; accelerator backend must be provisioned |
| TensorFlow | Open-source ML framework | Python API | Does not provide hosted compute; accelerator backend must be provisioned |
| JAX | Open-source array/ML framework | Python API | CPU, CUDA, ROCm and TPU paths have different install requirements |
| Ray | Open-source distributed runtime | Ray cluster API | Requires provisioned worker nodes; no free cluster is included |
| Dask | Open-source parallel computing | Dask scheduler/client | Requires provisioned workers; local mode is not remote cloud capacity |

## Quantum compute

| Resource | Classification | Integration surface | Constraint / correct interpretation |
|---|---|---|---|
| IBM Quantum | Small free Open Plan allocation; paid tiers | Qiskit Runtime / IBM Quantum Platform | Open Plan up to 10 minutes per rolling 28-day window; verify remaining allocation |
| Qiskit | Open-source SDK | Python SDK / Aer simulator | SDK is free software; QPU execution entitlement is separate |
| PennyLane | Open-source SDK | Python API / plugins | Local simulation is distinct from third-party QPU billing |
| Amazon Braket | Managed simulators/QPUs metered; local SDK simulator available | Braket SDK / AWS API | Local simulation is not the same as managed simulator or QPU billing |
| Azure Quantum | Provider-dependent | Azure Quantum workspace / SDK | Pricing, credits and hardware availability depend on selected provider |
| Quantinuum | Commercial hardware access | Provider API / Nexus | Account and commercial terms require direct verification |
| IonQ | Simulator/hardware terms differ | IonQ API / cloud marketplaces | Never infer hardware cost from simulator availability |
| Rigetti | Commercial hardware and simulator options | Rigetti QCS API | Verify selected QPU/simulator and plan separately |
| Open-source simulators | Free software, local compute | Qiskit Aer and other simulator APIs | Runtime cost is the host CPU/GPU and storage, not the simulator license alone |

## Scientific libraries and tools

These are software components, not cloud providers. Installing them does not grant data, hardware or hosted compute. Review the exact release license and transitive dependencies before redistribution.

| Tool | Intended capability | Integration direction |
|---|---|---|
| NumPy / SciPy | Numerical arrays, optimization, integration, sparse methods | Python environment adapter |
| OpenMM / LAMMPS | Molecular dynamics and materials simulation | Reproducible job container + CPU/GPU capability checks |
| RDKit | Cheminformatics | Python environment adapter |
| Biopython | Bioinformatics | Python environment adapter |
| COBRApy | Constraint-based metabolic modelling | Python environment adapter |
| QuTiP | Quantum dynamics and open quantum systems | Python environment adapter |
| Multiphysics tools | FEniCSx, OpenFOAM, MOOSE, Elmer and similar | Separate solver adapters; license and hardware review per tool |
| Neural/connectome analysis | Network analysis, connectomics and neural data tools | Dataset-aware adapters with provenance and evidence labels |

## Official references checked

- Oracle Always Free and trial: https://www.oracle.com/cloud/free/
- Cloudflare Workers pricing (updated 2026-10-02): https://developers.cloudflare.com/workers/platform/pricing/
- Render free service constraints: https://render.com/docs/free
- Google Cloud Free Tier: https://docs.cloud.google.com/free/docs/free-cloud-features
- AWS Free Tier: https://aws.amazon.com/free/
- Hugging Face Inference Providers pricing: https://huggingface.co/docs/inference-providers/pricing
- GitHub Actions billing: https://docs.github.com/en/actions/concepts/billing-and-usage
- GitLab pricing: https://about.gitlab.com/pricing/
- Deno Deploy pricing: https://deno.com/deploy/pricing
- Vercel Hobby limits: https://vercel.com/docs/plans/hobby
- Neon free-plan quotas: https://github.com/neondatabase/website/blob/main/content/faqs/free-plan-limits-and-quotas.md
- Supabase pricing: https://supabase.com/pricing
- Upstash Redis pricing: https://upstash.com/docs/redis/overall/pricing
- Backblaze B2 pricing: https://www.backblaze.com/cloud-storage/pricing
- Kaggle notebooks: https://www.kaggle.com/docs/notebooks and https://www.kaggle.com/docs/efficient-gpu-usage
- Google Colab FAQ/resource limits: https://research.google.com/colaboratory/faq.html
- IBM Quantum plans: https://quantum.cloud.ibm.com/docs/en/ibm-quantum-platform/plans-overview
- Amazon Braket pricing: https://aws.amazon.com/braket/pricing/
- SciPy licensing and cost: https://scipy.org/faq/
- JAX installation and accelerator support: https://docs.jax.dev/en/latest/installation.html

## Not verified / deployment blockers

No account was authenticated to any provider. No API token was available to URCAL. No live pricing or quota endpoint was queried. GitHub returned zero repositories visible to the linked account in this execution. Provider-specific adapters, terms acceptance, regional availability, account-specific quotas and live price verification remain separate implementation gates. URCAL intentionally does not upgrade plans, attach payment methods, deploy resources or trigger paid work.
