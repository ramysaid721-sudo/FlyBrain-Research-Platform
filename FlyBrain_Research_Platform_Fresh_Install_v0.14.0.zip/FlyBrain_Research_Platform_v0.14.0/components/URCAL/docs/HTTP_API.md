# URCAL HTTP API (v0.3.0)

The optional standard-library WSGI transport exposes a small authenticated job API.

## Start

For one principal, set `URCAL_API_TOKEN` to a random secret of at least 24 characters. For independent system identities, set `URCAL_API_TOKENS` to a JSON object mapping principal names to distinct tokens (each at least 24 characters), for example `{"flybrain":"...","neuroresearch":"..."}`. The multi-principal setting takes precedence. Inject these values from a secret manager/environment and never commit them. Then run:

```bash
urcal-api --host 127.0.0.1 --port 8765 --db ./urcal-jobs.sqlite
```

The server binds to loopback by default. It does not implement TLS. For remote access, put it behind a correctly configured TLS reverse proxy, firewall it, and use a managed secret store. Do not expose the development WSGI server directly to the public internet.

## Endpoints

- `GET /health` — authenticated health response.
- `POST /v1/jobs` — authenticated job creation. Body:

```json
{
  "task": {
    "task_id": "research-001",
    "required_capabilities": ["cpu", "python"],
    "estimated_quota_units": 1,
    "max_cost": 0,
    "idempotency_key": "research-001"
  },
  "payload": {"operation": "local-analysis"}
}
```

- `GET /v1/jobs/{task_id}` — retrieve job state.

Use `Authorization: Bearer <token>`. Each principal can only retrieve jobs it submitted; task IDs remain globally unique, so clients should namespace them (for example `flybrain/<id>` and `neuroresearch/<id>`). Idempotency keys are scoped independently per principal. Request bodies are capped at 1 MiB. Responses include `Cache-Control: no-store`. Errors do not include secret values.

## Important boundary

This transport accepts and records jobs; it does not itself select or invoke a provider. Provider routing, resource reservation, execution workers, TLS, rate limiting, distributed authentication and production deployment remain separate integration tasks. The bundled SQLite queue is a durable single-host queue with at-least-once delivery, not a multi-region broker. Workers must be idempotent.
