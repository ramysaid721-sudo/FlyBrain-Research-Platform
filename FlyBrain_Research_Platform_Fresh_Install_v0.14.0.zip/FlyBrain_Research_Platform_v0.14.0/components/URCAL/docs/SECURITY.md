# Security and cost controls

URCAL v0.2.0 is a local foundation, not a hardened multi-tenant production
service. Before public deployment, add TLS termination, OAuth/OIDC or
mTLS, authorization scopes, request-size limits, rate limiting, secret-manager
integration, database encryption/backup, log redaction, and threat modelling.

Never commit API keys. Use secret references such as `env:PROVIDER_TOKEN`.
Do not pass secret values into `Provider.metadata`, task payloads, or audit
events. The gateway requires an authentication callback; it does not implement
an identity provider itself.

The default policy rejects paid and unknown-cost providers. Prices and quotas
must carry fresh timestamps. A local budget reservation prevents concurrent
local over-allocation, but does not guarantee a provider's remote bill or quota.
Remote spend remains disabled unless a separate explicit authorization and
provider-specific adapter policy are implemented.
