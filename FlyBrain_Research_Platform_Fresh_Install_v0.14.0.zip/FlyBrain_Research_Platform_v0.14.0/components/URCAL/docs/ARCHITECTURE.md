# URCAL architecture and trust boundaries

URCAL is a neutral resource access/control plane. It does not own scientific
semantics or decide research conclusions.

```text
FlyBrain-NOS client ----\
                         -> URCAL API facade -> policy -> router -> provider adapters
NRC client -------------/                   |          |         |
                                             |          |         +-> compute/storage/research services
                                             |          +-> provider registry + capability matcher
                                             +-> audit + job ledger + quota/budget reservations
```

Each client has its own credentials, configuration, local policy, audit
namespace/database, and task identity. URCAL does not share FlyBrain or NRC
internal state and does not make either system a subordinate of the other.

## Routing sequence
1. Authenticate caller at the gateway boundary.
2. Validate task schema and idempotency key.
3. Discover provider metadata; keep state `discovered`.
4. Configure a provider and run a health check.
5. Record pricing and quota observations with source and timestamps.
6. Transition `tested` to `available` only after a successful health check.
7. Match capabilities and filter by lifecycle, pricing freshness, quota
   freshness, task budget, and global budget.
8. Atomically reserve local budget/quota accounting.
9. Submit through a provider adapter with bounded timeout/retry.
10. Validate result, transition job state, finalize reservation, and append audit.

## Failover
The failed provider is excluded before candidate ranking. A task is not blindly
replayed after an ambiguous network failure unless the provider adapter supports
idempotent submission or can query the original remote job. URCAL's local
idempotency ledger prevents duplicate local job creation; it cannot guarantee
exactly-once execution at a remote provider without provider-side support.

## Persistence
SQLite WAL stores audit events, job state, local reservations, and usage observations. Audit rows reject UPDATE and DELETE operations through database triggers. These stores
are separate from provider resources. Multi-host deployments require a
transactional shared database and a distributed queue adapter; the included
in-memory queue is only for local tests.

## Security boundaries
- Credentials are referenced, not stored in provider metadata.
- The environment resolver supports `env:NAME`; production should use a
  managed secret service adapter.
- Audit payloads must be redacted by callers.
- No generated code is executed by URCAL.
- Unknown/paid costs are denied by default.
- Local reservations do not replace provider-side metering or quota checks.

## v0.3.0 execution interfaces

The SQLite queue persists queued/leased/done/dead states, supports atomic local worker claims, lease expiry recovery, acknowledgement and bounded retry/dead-letter behavior. It is suitable for a single host or a carefully shared local database file; it is not a substitute for a dedicated multi-host broker.

The WSGI API is a thin authenticated transport around the persistent job store. It does not bypass provider policy or claim to execute jobs. Bind to loopback by default and deploy behind TLS/authentication infrastructure before remote use.
