# URCAL v0.3.0
Universal Research & Compute Access Layer

URCAL is a provider-neutral resource access/control layer. It is deliberately
not a neural model, scientific decision engine, or system-of-record for
FlyBrain-NOS or NeuroResearch Neural Core (NRC).

## Implemented in this release
- Provider registry with explicit lifecycle transitions:
  `discovered -> configured -> tested -> available`, plus `failed` and
  `unavailable`.
- Capability discovery and deterministic capability matching.
- Fail-closed routing requiring `available` health state, fresh pricing and
  quota observations, cost ceilings, and capability fit.
- Failover plans that exclude the failed provider before ranking alternatives.
- SQLite-backed append-only audit events.
- SQLite-backed job lifecycle and idempotency-key/payload-digest checks.
- Atomic SQLite quota and global-budget reservations.
- Provider adapter SDK, bounded retry policy, dry-run adapter.
- Health-monitor and pricing-evidence interfaces.
- Authentication callback boundary and environment-secret reference resolver.
- Independent API principals with separate bearer tokens, owner-scoped job reads and principal-scoped idempotency keys.
- Task-specific result validation hook.
- Authenticated standard-library WSGI HTTP API (`urcal-api`) with a bounded request body and loopback-first server.
- SQLite-backed persistent leased queue with atomic local worker claims, lease recovery, acknowledgements, bounded retries and dead-letter state.

## Important execution boundary
The bundled adapter is a local dry-run adapter. No cloud provider is connected
by installing this package. No paid resource is provisioned or started. A
provider must be separately configured, health-tested, have current pricing
and quota evidence, and pass local policy before it can be routed.

`InMemoryQueue` is a local test queue. `SQLiteQueue` is durable for single-host/local shared-file deployments and provides at-least-once delivery; workers must be idempotent. It is not a multi-region broker. A production broker adapter (e.g. Redis, RabbitMQ, cloud queue) must implement `QueueAdapter` and be tested against the service current contract. See `docs/HTTP_API.md`.

## Quick start (local policy demonstration)
```python
import time
from urcal import Provider, ProviderRegistry, TaskSpec, Router, Policy

now = time.time()
registry = ProviderRegistry()
registry.register(Provider(
    id="local-cpu", name="Local CPU", capabilities=frozenset({"python", "cpu"}),
    state="available", pricing="free", quota_remaining=100, estimated_cost=0,
    pricing_verified_at=now, quota_verified_at=now, health_checked_at=now,
))
router = Router(registry, Policy(global_budget=0))
decision = router.plan(TaskSpec("demo-001", frozenset({"python", "cpu"})), now=now)
print(decision.provider_id)
```

## Lifecycle
- `discovered`: metadata found; no connection claim.
- `configured`: configuration exists; not yet tested.
- `tested`: an initial connection test succeeded; not yet currently routable.
- `available`: current health check succeeded; eligible subject to policy.
- `failed`: last health/execution check failed.
- `unavailable`: explicitly unavailable or administratively disabled.

## Cost and quota policy
- Free-only is the default.
- Unknown pricing is rejected.
- Pricing and quota observations expire after configurable TTLs.
- Global budget and provider quota reservations are transactionally checked
  against concurrent reservations.
- Reservations are local accounting controls, not provider-side quota locks.
  A remote provider can still change its quota after verification; adapters
  must re-check before submission where supported.
- A provider reporting a `free` tier must still have an evidence source and
  a recent verification timestamp.

## Persistence
Audit events, jobs, and reservations use SQLite. Keep database files outside
version control, apply file-system permissions, and back them up according to
the deployment's data-retention policy. Do not place secrets in audit payloads.

## Tests
Run `python -m pytest -q`. The test suite uses temporary local SQLite files and
dry-run adapters; it does not contact external providers.

## Not yet implemented
- Production cloud/provider adapters.
- Multi-host distributed broker implementations and shared transactional resource accounting.
- Provider-specific live pricing/quota fetchers.
- TLS termination, OAuth/OIDC integration, rate limiting, and managed secret backend.
- Remote resource metering reconciliation and provider-side quota reservation.

## Offline provider catalog

`urcal.catalog.read_catalog()` reads the curated provider and scientific-software catalog without network access. `load_provider_registry()` creates provider records in `discovered` state with `pricing="unknown"`, no quota evidence and `connection_verified=false`. This is metadata discovery only. It cannot make any provider routable; configure, test, health-check and attach fresh pricing/quota evidence first.
