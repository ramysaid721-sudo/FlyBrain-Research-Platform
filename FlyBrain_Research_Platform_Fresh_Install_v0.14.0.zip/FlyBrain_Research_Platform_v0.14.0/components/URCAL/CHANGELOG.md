## 0.3.1 - Offline provider and scientific software catalog

- Added a curated catalog for cloud, research-compute, quantum and scientific software resources.
- Added `read_catalog` and `load_provider_registry`; cataloged providers always load as `discovered` with unknown runtime pricing, no quota evidence and `connection_verified=false`.
- Kept scientific libraries and SDKs separate from compute-provider entitlements.
- Added fail-closed tests proving catalog presence alone never makes a provider routable.
- Updated provider pricing research to correct Hugging Face Free inference credits to the currently documented USD 0.10/month amount, subject to change and distinguish limited free offers from verified connectivity.

# Changelog

## 0.3.0 - Durable local queue and authenticated HTTP transport
- Added SQLite-backed persistent leased queue with atomic worker claims, acknowledgements, retry delays, lease recovery and dead-letter state.
- Added standard-library WSGI HTTP API with bearer-token authentication, bounded request bodies, no-store responses and loopback-first serving.
- Added `urcal-api` command; refuses startup without an environment-provided token of sufficient length.
- Added tests for persistence, duplicate payload conflicts, retries, expired leases, API auth and job lifecycle endpoints.
- Queue delivery is at-least-once; remote execution still requires idempotent workers. SQLite queue is single-host/shared-file infrastructure, not a managed distributed broker.
- No cloud providers connected and no paid resources used.


## 0.2.0 - Durable safety and routing foundation
- Added explicit `available`, `failed`, and `unavailable` provider lifecycle states.
- Added freshness timestamps and TTL enforcement for pricing and quota observations.
- Made routing fail closed on stale/unknown pricing and quota.
- Corrected failover planning to exclude failed providers before ranking candidates.
- Added atomic SQLite budget and quota reservations.
- Replaced in-memory audit events with persistent SQLite audit log.
- Added persistent job lifecycle and idempotency-key/payload-digest conflict detection.
- Added provider health monitoring, pricing evidence verifier, discovery/matching helpers.
- Added API gateway auth boundary, secret-reference interface, result validation,
  queue contract, retry policy, and expanded adapter SDK.
- Preserved dry-run-only behavior; no cloud integrations or paid resources created.

## 0.1.0 - Initial local foundation
- Provider registry, policy checks, capability matching, routing and failover plan.
- Provider adapter contract and local dry-run adapter.
- In-memory audit log.
