"""Framework-neutral API gateway facade with mandatory caller-supplied auth."""
class AuthenticationError(PermissionError): pass
class APIGateway:
    def __init__(self,authenticate,job_store):
        if not callable(authenticate): raise ValueError("authenticate callback is required")
        self.authenticate=authenticate; self.job_store=job_store
    def submit_job(self,principal,task,payload):
        if not self.authenticate(principal): raise AuthenticationError("authentication failed")
        return self.job_store.create(task,payload,principal=principal)
    def get_job(self,principal,task_id):
        if not self.authenticate(principal): raise AuthenticationError("authentication failed")
        return self.job_store.get(task_id,principal=principal)
