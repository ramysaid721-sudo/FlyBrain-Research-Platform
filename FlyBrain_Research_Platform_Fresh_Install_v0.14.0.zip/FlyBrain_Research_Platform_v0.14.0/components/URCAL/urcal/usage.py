"""Persistent resource usage accounting; values are observations, not provider billing guarantees."""
import sqlite3, time, uuid
class UsageTracker:
    def __init__(self,path="urcal-usage.sqlite"):
        self.path=path
        with self._db() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS usage_events(
                event_id TEXT PRIMARY KEY, task_id TEXT NOT NULL, provider_id TEXT NOT NULL,
                cpu_seconds REAL NOT NULL, memory_byte_seconds REAL NOT NULL,
                input_bytes INTEGER NOT NULL, output_bytes INTEGER NOT NULL,
                quota_units REAL NOT NULL, estimated_cost REAL NOT NULL,
                observed_at REAL NOT NULL, source TEXT NOT NULL)""")
    def _db(self):
        c=sqlite3.connect(self.path,timeout=30); c.execute("PRAGMA journal_mode=WAL"); return c
    def record(self,task_id,provider_id,*,cpu_seconds=0,memory_byte_seconds=0,
               input_bytes=0,output_bytes=0,quota_units=0,estimated_cost=0,source="adapter"):
        values=(cpu_seconds,memory_byte_seconds,input_bytes,output_bytes,quota_units,estimated_cost)
        if any(v<0 for v in values): raise ValueError("usage values cannot be negative")
        event_id=str(uuid.uuid4())
        with self._db() as c:
            c.execute("INSERT INTO usage_events VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (event_id,task_id,provider_id,cpu_seconds,memory_byte_seconds,input_bytes,
                 output_bytes,quota_units,estimated_cost,time.time(),source))
        return event_id
    def totals(self,provider_id=None):
        where=" WHERE provider_id=?" if provider_id else ""
        with self._db() as c:
            row=c.execute("SELECT COUNT(*),COALESCE(SUM(cpu_seconds),0),COALESCE(SUM(input_bytes),0),COALESCE(SUM(output_bytes),0),COALESCE(SUM(estimated_cost),0) FROM usage_events"+where,
                          (provider_id,) if provider_id else ()).fetchone()
        return {"events":row[0],"cpu_seconds":row[1],"input_bytes":row[2],"output_bytes":row[3],"estimated_cost":row[4]}
