"""Provider health and pricing/quota observation helpers."""
import time
from dataclasses import replace
class ProviderHealthMonitor:
    def __init__(self,registry,adapters,audit=None): self.registry=registry; self.adapters=adapters; self.audit=audit
    def check(self,provider_id):
        adapter=self.adapters[provider_id]; result=adapter.health_check(); now=time.time()
        state="available" if result.ok else "failed"
        current=self.registry.get(provider_id)
        if result.ok:
            if current.state != "available":
                if current.state == "discovered":
                    self.registry.update_state(provider_id,"configured")
                    current=self.registry.get(provider_id)
                if current.state != "tested":
                    self.registry.update_state(provider_id,"tested")
                self.registry.update_state(provider_id,"available")
        elif current.state != "failed":
            self.registry.update_state(provider_id,"failed")
        self.registry.update(provider_id,health_checked_at=now)
        if self.audit: self.audit.append("provider_health_check",{"provider_id":provider_id,"ok":result.ok,"state":state})
        return result
class PricingVerifier:
    """Accepts a provider observation only when source and timestamp are supplied."""
    def verify(self,provider,*,pricing,estimated_cost,source,verified_at=None):
        import time
        if pricing not in {"free","paid","unknown"}: raise ValueError("invalid pricing classification")
        if not source or not source.startswith(("https://","local:")): raise ValueError("pricing evidence source must be https:// or local:")
        if estimated_cost is not None and estimated_cost<0: raise ValueError("cost cannot be negative")
        return replace(provider,pricing=pricing,estimated_cost=estimated_cost,
                       pricing_verified_at=verified_at or time.time(),
                       metadata={**provider.metadata,"pricing_source":source})
