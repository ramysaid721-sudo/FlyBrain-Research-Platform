"""Load the offline provider/software catalog without claiming live connectivity."""
from __future__ import annotations
import json
from importlib.resources import files
from pathlib import Path
from .models import Provider
from .registry import ProviderRegistry


def read_catalog(path: str | Path | None = None) -> dict:
    """Read catalog metadata. It performs no network calls and verifies no account."""
    if path is None:
        raw = files("urcal").joinpath("data/provider_catalog.json").read_text(encoding="utf-8")
    else:
        raw = Path(path).read_text(encoding="utf-8")
    data = json.loads(raw)
    if data.get("schema_version") != 1 or not isinstance(data.get("providers"), list) or not isinstance(data.get("software"), list):
        raise ValueError("unsupported or malformed provider catalog")
    ids = [x.get("id") for x in data["providers"] + data["software"]]
    if any(not isinstance(x, str) or not x.strip() for x in ids) or len(ids) != len(set(ids)):
        raise ValueError("catalog IDs must be non-empty and globally unique")
    return data


def load_provider_registry(path: str | Path | None = None) -> ProviderRegistry:
    """Load all service providers in discovered/unknown state, never available."""
    data = read_catalog(path)
    registry = ProviderRegistry()
    for item in data["providers"]:
        registry.register(Provider(
            id=item["id"], name=item["name"],
            capabilities=frozenset(item.get("capabilities", [])),
            state="discovered", pricing="unknown", quota_remaining=None,
            estimated_cost=None,
            metadata={**item, "connection_verified": False, "catalog_research_date": data.get("researched_at")},
        ))
    return registry
