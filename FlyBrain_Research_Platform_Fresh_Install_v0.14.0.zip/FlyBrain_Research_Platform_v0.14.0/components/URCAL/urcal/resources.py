"""Atomic quota and budget reservations backed by SQLite."""
import sqlite3, time, uuid
class ResourceManager:
    def __init__(self,path="urcal-resources.sqlite",global_budget=0.0):
        self.path=path; self.global_budget=float(global_budget)
        with self._db() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS reservations(
                reservation_id TEXT PRIMARY KEY, task_id TEXT UNIQUE NOT NULL, provider_id TEXT NOT NULL,
                quota_units REAL NOT NULL, cost REAL NOT NULL, state TEXT NOT NULL, created_at REAL NOT NULL)""")
    def _db(self):
        c=sqlite3.connect(self.path,timeout=30,isolation_level=None)
        c.execute("PRAGMA journal_mode=WAL"); c.execute("PRAGMA busy_timeout=30000"); return c
    def reserved_cost(self):
        with self._db() as c:
            row=c.execute("SELECT COALESCE(SUM(cost),0) FROM reservations WHERE state IN ('reserved','committed')").fetchone()
            return float(row[0])
    def reserve(self,task,provider):
        cost=float(provider.estimated_cost or 0)
        with self._db() as c:
            c.execute("BEGIN IMMEDIATE")
            existing=c.execute("SELECT reservation_id,state FROM reservations WHERE task_id=?",(task.task_id,)).fetchone()
            if existing:
                c.rollback()
                if existing[1]=="reserved": return existing[0]
                raise ValueError("task already has a finalized reservation")
            used=c.execute("SELECT COALESCE(SUM(cost),0) FROM reservations WHERE state IN ('reserved','committed')").fetchone()[0]
            if used+cost>self.global_budget:
                c.rollback(); raise ValueError("global budget reservation would be exceeded")
            # Provider quota_remaining is an external snapshot. Only local reservations
            # created after that snapshot should be subtracted from it.
            snapshot_at=provider.quota_verified_at or 0
            provider_used=c.execute("SELECT COALESCE(SUM(quota_units),0) FROM reservations WHERE provider_id=? AND state IN ('reserved','committed') AND created_at>?",(provider.id,snapshot_at)).fetchone()[0]
            if provider.quota_remaining is not None and provider_used+task.estimated_quota_units>provider.quota_remaining:
                c.rollback(); raise ValueError("provider quota reservation would be exceeded")
            rid=str(uuid.uuid4())
            c.execute("INSERT INTO reservations VALUES(?,?,?,?,?,?,?)",(rid,task.task_id,provider.id,task.estimated_quota_units,cost,"reserved",time.time()))
            c.commit(); return rid
    def finalize(self,reservation_id,success=True):
        with self._db() as c:
            cur=c.execute("UPDATE reservations SET state=? WHERE reservation_id=? AND state='reserved'",("committed" if success else "released",reservation_id))
            if cur.rowcount!=1: raise ValueError("reservation not found or already finalized")
    def reservations(self):
        with self._db() as c: return c.execute("SELECT reservation_id,task_id,provider_id,quota_units,cost,state,created_at FROM reservations ORDER BY created_at").fetchall()
