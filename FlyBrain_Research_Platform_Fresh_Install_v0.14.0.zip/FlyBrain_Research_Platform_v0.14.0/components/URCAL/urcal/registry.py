"""Thread-safe in-memory provider registry with explicit lifecycle transitions."""
from threading import RLock
from dataclasses import replace
from .models import Provider

_TRANSITIONS={"discovered":{"configured","unavailable","failed"},
"configured":{"tested","unavailable","failed"},
"tested":{"available","failed","unavailable","configured"},
"available":{"failed","unavailable","configured","tested"},
"failed":{"configured","tested","unavailable"},
"unavailable":{"configured","tested","failed"}}

class ProviderRegistry:
    def __init__(self):
        self._providers={}; self._lock=RLock()
    def register(self, provider):
        with self._lock:
            if provider.id in self._providers: raise ValueError(f"provider already registered: {provider.id}")
            self._providers[provider.id]=provider
    def upsert(self, provider):
        with self._lock: self._providers[provider.id]=provider
    def get(self, provider_id):
        with self._lock: return self._providers[provider_id]
    def all(self):
        with self._lock: return tuple(self._providers[k] for k in sorted(self._providers))
    def update(self, provider_id, **changes):
        with self._lock:
            p=self._providers[provider_id]; self._providers[provider_id]=replace(p,**changes)
            return self._providers[provider_id]
    def update_state(self, provider_id, state):
        with self._lock:
            p=self._providers[provider_id]
            if state not in _TRANSITIONS[p.state]: raise ValueError(f"invalid lifecycle transition: {p.state} -> {state}")
            self._providers[provider_id]=replace(p,state=state)
            return self._providers[provider_id]
    def update_quota(self, provider_id, quota_remaining, verified_at=None):
        import time
        return self.update(provider_id,quota_remaining=quota_remaining,quota_verified_at=verified_at or time.time())
