"""Capability discovery and matching helpers; discovery never implies connectivity."""
def discover(adapter_descriptors):
    return tuple({"provider_id":x["provider_id"],"capabilities":frozenset(x.get("capabilities",())),
                  "state":"discovered","connectivity_verified":False} for x in adapter_descriptors)
def match_capabilities(required,providers):
    required=frozenset(required)
    return tuple(p for p in providers if required.issubset(frozenset(p.capabilities)))
