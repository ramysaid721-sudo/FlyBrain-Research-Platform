"""Capability-aware deterministic routing with explicit failed-provider exclusion."""
from .policy import PolicyError
class NoEligibleProvider(RuntimeError): pass

class Router:
    def __init__(self, registry, policy, budget_ledger=None):
        self.registry=registry; self.policy=policy; self.budget_ledger=budget_ledger
    def plan(self, task, *, excluded=(), now=None):
        eligible=[]; rejected=[]; blocked=set(excluded)
        reserved=self.budget_ledger.reserved_cost() if self.budget_ledger else 0.0
        for p in self.registry.all():
            if p.id in blocked: continue
            if not task.required_capabilities.issubset(p.capabilities): continue
            try: self.policy.validate(p,task,now=now,reserved_cost=reserved)
            except PolicyError as exc: rejected.append(f"{p.id}: {exc}"); continue
            region_penalty=0 if not task.preferred_regions or p.region in task.preferred_regions else 1
            quota_rank=-(p.quota_remaining if p.quota_remaining is not None else 0)
            eligible.append((region_penalty,quota_rank,p.id))
        if not eligible:
            detail="; ".join(rejected) or "no non-excluded provider has required capabilities"
            raise NoEligibleProvider(detail)
        eligible.sort()
        ids=[x[2] for x in eligible]
        return __import__("urcal.models",fromlist=["Decision"]).Decision(
            task.task_id,ids[0],"capabilities, current health, fresh pricing/quota and budget checks passed",tuple(ids[1:]))
    def failover(self, task, failed_provider_id, excluded=(), *, now=None):
        blocked=set(excluded)|{failed_provider_id}
        decision=self.plan(task,excluded=blocked,now=now)
        return __import__("urcal.models",fromlist=["Decision"]).Decision(
            task.task_id,decision.provider_id,f"failover after excluding failed provider {failed_provider_id}",decision.fallback_candidates)
