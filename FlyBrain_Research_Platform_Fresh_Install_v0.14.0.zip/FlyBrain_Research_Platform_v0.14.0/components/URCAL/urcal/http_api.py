"""Minimal authenticated WSGI HTTP API for URCAL; standard-library only."""
from __future__ import annotations
import hmac
import json
from wsgiref.simple_server import make_server
from .gateway import APIGateway, AuthenticationError
from .jobs import JobStore
from .models import TaskSpec


class URCALHTTPApp:
    def __init__(self, job_store, token):
        # Accept either one shared token (legacy/default principal) or a mapping
        # of independent principal IDs to independent tokens.
        token_map={"default":token} if isinstance(token,str) else dict(token or {})
        if not token_map or any(not isinstance(k,str) or not k or not isinstance(v,str) or len(v)<24 for k,v in token_map.items()):
            raise ValueError("each API principal requires a token of at least 24 characters")
        self._tokens=token_map
        self.gateway = APIGateway(lambda principal: principal in self._tokens, job_store)

    def _resolve_principal(self, supplied):
        if not isinstance(supplied,str): return None
        for principal,secret in self._tokens.items():
            if hmac.compare_digest(supplied,secret): return principal
        return None

    @staticmethod
    def _response(start_response, status, payload):
        body=json.dumps(payload,separators=(",",":"),default=str).encode()
        start_response(status,[("Content-Type","application/json; charset=utf-8"),("Content-Length",str(len(body))),("Cache-Control","no-store")])
        return [body]

    def __call__(self,environ,start_response):
        method=environ.get("REQUEST_METHOD","GET").upper(); path=environ.get("PATH_INFO","")
        auth=environ.get("HTTP_AUTHORIZATION","")
        supplied=auth[7:] if auth.startswith("Bearer ") else ""
        principal=self._resolve_principal(supplied)
        if principal is None: return self._response(start_response,"401 Unauthorized",{"error":"unauthorized"})
        if method=="GET" and path=="/health": return self._response(start_response,"200 OK",{"status":"ok","service":"urcal"})
        if method=="POST" and path=="/v1/jobs":
            try:
                length=int(environ.get("CONTENT_LENGTH") or "0")
                if length<1 or length>1_048_576: return self._response(start_response,"413 Payload Too Large",{"error":"request body must be 1..1048576 bytes"})
                raw=environ["wsgi.input"].read(length)
                data=json.loads(raw)
                task_data=data["task"]
                task=TaskSpec(task_id=str(task_data["task_id"]),required_capabilities=frozenset(task_data.get("required_capabilities",[])),
                    estimated_quota_units=float(task_data.get("estimated_quota_units",1)),max_cost=float(task_data.get("max_cost",0)),
                    idempotency_key=task_data.get("idempotency_key"),timeout_seconds=float(task_data.get("timeout_seconds",300)))
                result=self.gateway.submit_job(principal,task,data.get("payload",{}))
                return self._response(start_response,"202 Accepted",result)
            except (KeyError,TypeError,ValueError,json.JSONDecodeError) as exc:
                return self._response(start_response,"400 Bad Request",{"error":"invalid_request","detail":str(exc)[:300]})
            except AuthenticationError:
                return self._response(start_response,"401 Unauthorized",{"error":"unauthorized"})
        if method=="GET" and path.startswith("/v1/jobs/"):
            task_id=path[len("/v1/jobs/"): ]
            try: return self._response(start_response,"200 OK",self.gateway.get_job(principal,task_id))
            except KeyError: return self._response(start_response,"404 Not Found",{"error":"job_not_found"})
        return self._response(start_response,"404 Not Found",{"error":"not_found"})


def serve(host="127.0.0.1",port=8765,db_path="urcal-jobs.sqlite",token=None):
    import os
    token=token or os.environ.get("URCAL_API_TOKEN")
    token_map=os.environ.get("URCAL_API_TOKENS")
    if token_map:
        try: token=json.loads(token_map)
        except json.JSONDecodeError: raise RuntimeError("URCAL_API_TOKENS must be a JSON object") from None
    if not token: raise RuntimeError("set URCAL_API_TOKEN or URCAL_API_TOKENS; refusing unauthenticated API")
    app=URCALHTTPApp(JobStore(db_path),token)
    with make_server(host,port,app) as server: server.serve_forever()


def main():
    import argparse
    parser=argparse.ArgumentParser(description="Run the authenticated URCAL HTTP API")
    parser.add_argument("--host",default="127.0.0.1")
    parser.add_argument("--port",type=int,default=8765)
    parser.add_argument("--db",default="urcal-jobs.sqlite")
    args=parser.parse_args()
    serve(args.host,args.port,args.db)


if __name__=="__main__": main()
