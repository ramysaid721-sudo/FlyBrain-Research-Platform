"""Secret references only; secret values are resolved at runtime and never serialized."""
import os
class SecretResolver:
    def resolve(self,reference): raise NotImplementedError
class EnvironmentSecretResolver(SecretResolver):
    def resolve(self,reference):
        if not reference or not reference.startswith("env:"): raise ValueError("only env: secret references are supported")
        name=reference[4:]
        if not name or name not in os.environ: raise KeyError(f"secret environment variable is not configured: {name}")
        return os.environ[name]
