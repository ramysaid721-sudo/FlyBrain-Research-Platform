"""Queue contracts with in-memory and SQLite-backed durable implementations.

SQLiteQueue is durable and safe for multiple local processes sharing one SQLite
file. It is not a cross-region or high-throughput distributed broker; use a
provider-specific broker adapter for that deployment class.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from queue import Queue, Empty
import json
import sqlite3
import time


class QueueAdapter(ABC):
    @abstractmethod
    def enqueue(self, job): ...

    @abstractmethod
    def dequeue(self, timeout=None): ...


class InMemoryQueue(QueueAdapter):
    """Test/local queue only; not durable and not distributed."""
    def __init__(self): self._q = Queue()
    def enqueue(self, job): self._q.put(job)
    def dequeue(self, timeout=None):
        try: return self._q.get(timeout=timeout)
        except Empty: return None


class SQLiteQueue(QueueAdapter):
    """Persistent leased queue with acknowledgement, retry and dead-lettering.

    Guarantees atomic claim across local processes using BEGIN IMMEDIATE.
    Delivery is at-least-once: workers must make task execution idempotent.
    """
    def __init__(self, path="urcal-queue.sqlite", *, max_attempts=5, poll_interval=0.1):
        if max_attempts < 1 or poll_interval <= 0: raise ValueError("invalid queue configuration")
        self.path = str(path); self.max_attempts = int(max_attempts); self.poll_interval = float(poll_interval)
        with self._db() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS queue_items (
                job_id TEXT PRIMARY KEY, job_json TEXT NOT NULL, state TEXT NOT NULL,
                attempts INTEGER NOT NULL DEFAULT 0, available_at REAL NOT NULL,
                lease_until REAL, worker_id TEXT, last_error TEXT,
                created_at REAL NOT NULL, updated_at REAL NOT NULL)""")
            c.execute("CREATE INDEX IF NOT EXISTS queue_ready_idx ON queue_items(state, available_at, lease_until)")

    def _db(self):
        c = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA busy_timeout=30000")
        return c

    def enqueue(self, job):
        if not isinstance(job, dict): raise TypeError("job must be a dictionary")
        job_id = str(job.get("task_id") or job.get("job_id") or "").strip()
        if not job_id: raise ValueError("job requires task_id or job_id")
        payload = json.dumps(job, sort_keys=True, separators=(",", ":"), default=str)
        now = time.time()
        with self._db() as c:
            try:
                c.execute("INSERT INTO queue_items(job_id,job_json,state,attempts,available_at,created_at,updated_at) VALUES(?,?,'queued',0,?,?,?)", (job_id,payload,now,now,now))
            except sqlite3.IntegrityError:
                row = c.execute("SELECT job_json FROM queue_items WHERE job_id=?", (job_id,)).fetchone()
                if row and row[0] != payload: raise ValueError("queue job id reused with different payload")
                return {"job_id": job_id, "duplicate": True}
        return {"job_id": job_id, "duplicate": False}

    def dequeue(self, timeout=None, *, worker_id="worker", lease_seconds=60):
        if lease_seconds <= 0: raise ValueError("lease_seconds must be positive")
        deadline = None if timeout is None else time.monotonic() + max(0, timeout)
        while True:
            now = time.time()
            with self._db() as c:
                c.execute("BEGIN IMMEDIATE")
                row = c.execute("""SELECT job_id,job_json,attempts FROM queue_items
                    WHERE (state='queued' AND available_at<=?) OR (state='leased' AND lease_until<=?)
                    ORDER BY available_at,created_at LIMIT 1""", (now,now)).fetchone()
                if row:
                    job_id, payload, attempts = row
                    attempts += 1
                    c.execute("UPDATE queue_items SET state='leased',attempts=?,lease_until=?,worker_id=?,updated_at=? WHERE job_id=?",
                              (attempts,now+lease_seconds,worker_id,now,job_id))
                    c.commit()
                    job = json.loads(payload)
                    job["_queue"] = {"job_id":job_id,"attempt":attempts,"worker_id":worker_id,"lease_until":now+lease_seconds}
                    return job
                c.commit()
            if deadline is not None and time.monotonic() >= deadline: return None
            time.sleep(self.poll_interval if deadline is None else min(self.poll_interval,max(0,deadline-time.monotonic())))

    def ack(self, job_id, *, worker_id=None):
        with self._db() as c:
            sql = "UPDATE queue_items SET state='done',lease_until=NULL,worker_id=NULL,updated_at=? WHERE job_id=? AND state='leased'"
            args = [time.time(),job_id]
            if worker_id is not None: sql += " AND worker_id=?"; args.append(worker_id)
            cur = c.execute(sql,args)
            if cur.rowcount != 1: raise ValueError("job is not leased by this worker")

    def nack(self, job_id, *, error=None, delay_seconds=0, worker_id=None):
        if delay_seconds < 0: raise ValueError("delay_seconds cannot be negative")
        with self._db() as c:
            c.execute("BEGIN IMMEDIATE")
            row = c.execute("SELECT attempts FROM queue_items WHERE job_id=? AND state='leased'" + (" AND worker_id=?" if worker_id is not None else ""),
                            (job_id,worker_id) if worker_id is not None else (job_id,)).fetchone()
            if not row: c.rollback(); raise ValueError("job is not leased by this worker")
            state = "dead" if row[0] >= self.max_attempts else "queued"
            now = time.time()
            # Do not persist arbitrary exception messages: they may contain tokens,
            # URLs with credentials, prompts or provider response data.
            safe_error = (type(error).__name__ if isinstance(error, BaseException)
                          else ("worker_nack" if error is not None else None))
            c.execute("UPDATE queue_items SET state=?,available_at=?,lease_until=NULL,worker_id=NULL,last_error=?,updated_at=? WHERE job_id=?",
                      (state,now+delay_seconds,safe_error,now,job_id))
            c.commit()
            return state

    def status(self, job_id):
        with self._db() as c:
            row = c.execute("SELECT job_id,state,attempts,available_at,lease_until,worker_id,last_error FROM queue_items WHERE job_id=?",(job_id,)).fetchone()
        if not row: raise KeyError(job_id)
        return dict(zip(("job_id","state","attempts","available_at","lease_until","worker_id","last_error"),row))
