"""Result validation primitives; callers must supply task-specific validators."""
from dataclasses import dataclass
@dataclass(frozen=True)
class ValidationResult:
    valid: bool
    reason: str
def validate_result(result,validator):
    try:
        ok=bool(validator(result))
        return ValidationResult(ok,"validator accepted result" if ok else "validator rejected result")
    except Exception as exc:
        return ValidationResult(False,f"validator raised {type(exc).__name__}")
