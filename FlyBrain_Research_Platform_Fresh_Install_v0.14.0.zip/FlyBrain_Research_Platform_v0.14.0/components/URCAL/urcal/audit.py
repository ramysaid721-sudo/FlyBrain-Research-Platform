"""Append-only SQLite audit log; payloads must not contain secrets."""
import json, sqlite3, time
from pathlib import Path
class AuditLog:
    def __init__(self, path="urcal-audit.sqlite"):
        self.path=str(path); Path(self.path).parent.mkdir(parents=True,exist_ok=True) if self.path not in {":memory:"} else None
        with self._connect() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS audit_events(
                id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp REAL NOT NULL,
                event_type TEXT NOT NULL, payload_json TEXT NOT NULL)""")
            c.execute("""CREATE TRIGGER IF NOT EXISTS audit_no_update
                BEFORE UPDATE ON audit_events BEGIN SELECT RAISE(ABORT,'audit log is append-only'); END""")
            c.execute("""CREATE TRIGGER IF NOT EXISTS audit_no_delete
                BEFORE DELETE ON audit_events BEGIN SELECT RAISE(ABORT,'audit log is append-only'); END""")
    def _connect(self):
        c=sqlite3.connect(self.path,timeout=30); c.execute("PRAGMA journal_mode=WAL"); return c
    def append(self,event_type,payload):
        safe=json.dumps(payload,sort_keys=True,default=str)
        with self._connect() as c:
            cur=c.execute("INSERT INTO audit_events(timestamp,event_type,payload_json) VALUES(?,?,?)",(time.time(),event_type,safe))
            return cur.lastrowid
    def events(self):
        with self._connect() as c: rows=c.execute("SELECT timestamp,event_type,payload_json FROM audit_events ORDER BY id").fetchall()
        return tuple({"timestamp":r[0],"event_type":r[1],"payload":json.loads(r[2])} for r in rows)
    def to_json(self): return json.dumps(self.events(),sort_keys=True,indent=2)
