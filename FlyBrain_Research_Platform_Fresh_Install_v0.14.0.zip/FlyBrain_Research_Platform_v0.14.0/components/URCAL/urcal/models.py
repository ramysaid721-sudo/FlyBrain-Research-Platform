"""Typed URCAL domain models. Provider discovery is not proof of availability."""
from dataclasses import dataclass, field
from typing import FrozenSet, Optional

VALID_STATES = {"discovered", "configured", "tested", "available", "failed", "unavailable"}
VALID_PRICING = {"free", "paid", "unknown"}

@dataclass(frozen=True)
class Provider:
    id: str
    name: str
    capabilities: FrozenSet[str] = frozenset()
    state: str = "discovered"
    pricing: str = "unknown"
    quota_remaining: Optional[float] = None
    estimated_cost: Optional[float] = None
    region: Optional[str] = None
    metadata: dict = field(default_factory=dict)
    pricing_verified_at: Optional[float] = None
    quota_verified_at: Optional[float] = None
    health_checked_at: Optional[float] = None

    def __post_init__(self):
        if not self.id.strip(): raise ValueError("provider id must not be empty")
        if self.state not in VALID_STATES: raise ValueError(f"invalid provider state: {self.state}")
        if self.pricing not in VALID_PRICING: raise ValueError(f"invalid pricing classification: {self.pricing}")
        if self.quota_remaining is not None and self.quota_remaining < 0: raise ValueError("quota_remaining cannot be negative")
        if self.estimated_cost is not None and self.estimated_cost < 0: raise ValueError("estimated_cost cannot be negative")

@dataclass(frozen=True)
class TaskSpec:
    task_id: str
    required_capabilities: FrozenSet[str]
    estimated_quota_units: float = 1.0
    max_cost: float = 0.0
    preferred_regions: FrozenSet[str] = frozenset()
    priority: int = 0
    idempotency_key: Optional[str] = None
    payload_digest: Optional[str] = None
    timeout_seconds: float = 300.0

    def __post_init__(self):
        if not self.task_id.strip(): raise ValueError("task_id must not be empty")
        if self.estimated_quota_units < 0 or self.max_cost < 0: raise ValueError("quota and cost limits cannot be negative")
        if self.timeout_seconds <= 0: raise ValueError("timeout_seconds must be positive")

@dataclass(frozen=True)
class Decision:
    task_id: str
    provider_id: str
    reason: str
    fallback_candidates: tuple[str, ...] = ()

@dataclass
class ExecutionRecord:
    task_id: str
    provider_id: str
    status: str
    result_ref: Optional[str] = None
    error: Optional[str] = None
