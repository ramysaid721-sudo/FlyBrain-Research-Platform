"""Provider adapter SDK contracts, dry-run adapter, and bounded retry policy."""
from abc import ABC, abstractmethod
from dataclasses import dataclass
import time
@dataclass(frozen=True)
class AdapterResult:
    ok: bool
    message: str
    result_ref: str|None=None
    retryable: bool=False
class ProviderAdapter(ABC):
    provider_id: str
    @abstractmethod
    def health_check(self)->AdapterResult: ...
    @abstractmethod
    def submit(self,task_payload:dict)->AdapterResult: ...
class DryRunAdapter(ProviderAdapter):
    def __init__(self,provider_id="dry-run",fail=False): self.provider_id=provider_id; self.fail=fail
    def health_check(self): return AdapterResult(not self.fail,"dry-run health check",retryable=self.fail)
    def submit(self,task_payload):
        if self.fail: return AdapterResult(False,"simulated failure",retryable=True)
        return AdapterResult(True,"dry-run only",f"dryrun://{task_payload.get('task_id')}")
@dataclass(frozen=True)
class RetryPolicy:
    max_attempts:int=2
    initial_delay_seconds:float=0.1
    max_delay_seconds:float=1.0
    def __post_init__(self):
        if self.max_attempts<1 or self.initial_delay_seconds<0 or self.max_delay_seconds<0: raise ValueError("invalid retry policy")
def submit_with_retry(adapter,payload,policy=RetryPolicy(),sleep=time.sleep):
    for attempt in range(policy.max_attempts):
        result=adapter.submit(payload)
        if result.ok or not result.retryable or attempt+1==policy.max_attempts: return result
        sleep(min(policy.initial_delay_seconds*(2**attempt),policy.max_delay_seconds))
    raise RuntimeError("unreachable")
