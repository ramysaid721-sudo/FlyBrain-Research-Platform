"""Fail-closed pricing, quota freshness, and budget policy."""
import time

class PolicyError(RuntimeError): pass

class Policy:
    def __init__(self, free_only=True, allow_unknown_cost=False, require_tested=True,
                 global_budget=0.0, pricing_ttl_seconds=3600, quota_ttl_seconds=900,
                 require_fresh_pricing=True, require_fresh_quota=True):
        self.free_only=free_only; self.allow_unknown_cost=allow_unknown_cost
        self.require_tested=require_tested; self.global_budget=float(global_budget)
        self.pricing_ttl_seconds=pricing_ttl_seconds; self.quota_ttl_seconds=quota_ttl_seconds
        self.require_fresh_pricing=require_fresh_pricing; self.require_fresh_quota=require_fresh_quota

    def validate(self, provider, task, *, now=None, reserved_cost=0.0):
        now=time.time() if now is None else now
        if self.require_tested and provider.state != "available":
            raise PolicyError("provider has not completed a successful health test and is not available")
        if provider.state in {"failed","unavailable"}: raise PolicyError("provider is failed or unavailable")
        if self.free_only and provider.pricing != "free": raise PolicyError("free-only policy rejects non-free provider")
        if provider.pricing == "unknown" and not self.allow_unknown_cost: raise PolicyError("unknown pricing is not allowed")
        if provider.pricing == "free" and provider.estimated_cost not in (None,0,0.0):
            raise PolicyError("provider marked free reports a non-zero estimated cost")
        if provider.pricing_verified_at is None:
            if self.require_fresh_pricing: raise PolicyError("pricing has not been verified")
        elif now-provider.pricing_verified_at > self.pricing_ttl_seconds or provider.pricing_verified_at > now+60:
            raise PolicyError("pricing verification is stale or from the future")
        if provider.estimated_cost is None and not self.allow_unknown_cost:
            raise PolicyError("unknown execution cost is not allowed")
        cost=float(provider.estimated_cost or 0.0)
        if cost > task.max_cost: raise PolicyError("estimated cost exceeds task budget")
        if reserved_cost + cost > self.global_budget: raise PolicyError("estimated cost exceeds remaining global budget")
        if provider.quota_remaining is None:
            if self.require_fresh_quota: raise PolicyError("provider quota is unknown")
        else:
            if provider.quota_verified_at is None:
                if self.require_fresh_quota: raise PolicyError("quota has not been verified")
            elif now-provider.quota_verified_at > self.quota_ttl_seconds or provider.quota_verified_at > now+60:
                raise PolicyError("quota information is stale or from the future")
            if provider.quota_remaining < task.estimated_quota_units: raise PolicyError("insufficient provider quota")
