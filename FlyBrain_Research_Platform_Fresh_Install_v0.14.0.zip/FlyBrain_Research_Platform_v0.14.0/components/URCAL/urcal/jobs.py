"""Persistent job lifecycle and idempotency ledger."""
import hashlib, json, sqlite3, time
VALID_JOB_STATES={"queued","submitted","running","succeeded","failed","cancelled","timed_out"}
_ALLOWED={"queued":{"submitted","cancelled","failed"},"submitted":{"running","failed","timed_out","cancelled"},
"running":{"succeeded","failed","timed_out","cancelled"}}
class JobStore:
    def __init__(self,path="urcal-jobs.sqlite"):
        self.path=path
        with self._db() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS jobs(
                task_id TEXT PRIMARY KEY, idempotency_key TEXT UNIQUE, payload_digest TEXT NOT NULL,
                provider_id TEXT, state TEXT NOT NULL, result_json TEXT, error TEXT,
                created_at REAL NOT NULL, updated_at REAL NOT NULL,
                owner_id TEXT NOT NULL DEFAULT 'default')""")
            columns={row[1] for row in c.execute("PRAGMA table_info(jobs)")}
            if "owner_id" not in columns:
                c.execute("ALTER TABLE jobs ADD COLUMN owner_id TEXT NOT NULL DEFAULT 'default'")
                # Namespace pre-existing idempotency keys under the legacy
                # default principal without discarding prior job records.
                rows=c.execute("SELECT task_id,idempotency_key,owner_id FROM jobs").fetchall()
                for task_id,old_key,owner in rows:
                    scoped=hashlib.sha256((owner+"\0"+old_key).encode()).hexdigest()
                    c.execute("UPDATE jobs SET idempotency_key=? WHERE task_id=?",(scoped,task_id))
    def _db(self):
        c=sqlite3.connect(self.path,timeout=30,isolation_level=None); c.execute("PRAGMA journal_mode=WAL"); return c
    def create(self,task,payload,principal="default"):
        digest=task.payload_digest or hashlib.sha256(json.dumps(payload,sort_keys=True,default=str).encode()).hexdigest()
        now=time.time()
        if not principal: raise ValueError("principal must not be empty")
        user_key=task.idempotency_key or task.task_id
        key=hashlib.sha256((principal+"\0"+user_key).encode()).hexdigest()
        with self._db() as c:
            c.execute("BEGIN IMMEDIATE")
            row=c.execute("SELECT task_id,payload_digest,state FROM jobs WHERE idempotency_key=?",(key,)).fetchone()
            if row:
                c.rollback()
                if row[1]!=digest: raise ValueError("idempotency key reused with a different payload")
                return {"task_id":row[0],"state":row[2],"duplicate":True}
            c.execute("INSERT INTO jobs(task_id,idempotency_key,payload_digest,provider_id,state,result_json,error,created_at,updated_at,owner_id) VALUES(?,?,?,?,?,?,?,?,?,?)",
                      (task.task_id,key,digest,None,"queued",None,None,now,now,principal))
            c.commit()
        return {"task_id":task.task_id,"state":"queued","duplicate":False}
    def transition(self,task_id,state,*,provider_id=None,result=None,error=None):
        if state not in VALID_JOB_STATES: raise ValueError("invalid job state")
        with self._db() as c:
            row=c.execute("SELECT state FROM jobs WHERE task_id=?",(task_id,)).fetchone()
            if not row: raise KeyError(task_id)
            old=row[0]
            if state not in _ALLOWED.get(old,set()): raise ValueError(f"invalid job transition: {old} -> {state}")
            # Persist only a stable error class/code, never arbitrary exception
            # text that could contain credentials or provider response payloads.
            safe_error = (type(error).__name__ if isinstance(error, BaseException)
                          else ("execution_failed" if error is not None else None))
            c.execute("UPDATE jobs SET state=?,provider_id=COALESCE(?,provider_id),result_json=?,error=?,updated_at=? WHERE task_id=?",
                      (state,provider_id,json.dumps(result,default=str) if result is not None else None,safe_error,time.time(),task_id))
    def get(self,task_id,principal=None):
        with self._db() as c: row=c.execute("SELECT task_id,idempotency_key,payload_digest,provider_id,state,result_json,error,created_at,updated_at,owner_id FROM jobs WHERE task_id=?",(task_id,)).fetchone()
        if not row or (principal is not None and row[9]!=principal): raise KeyError(task_id)
        return dict(zip(("task_id","idempotency_key","payload_digest","provider_id","state","result","error","created_at","updated_at"),row[:5]+((json.loads(row[5]) if row[5] else None),)+row[6:9]))
