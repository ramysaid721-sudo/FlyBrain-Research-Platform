"""Structural contract only; NRC implementation must map this to its own runtime."""
from typing import Protocol, Mapping, Any

class NRCURCALClient(Protocol):
    def submit(self, task_id: str, payload: Mapping[str, Any], *,
               required_capabilities: tuple[str, ...], max_cost: float,
               idempotency_key: str) -> Mapping[str, Any]: ...
    def get(self, task_id: str) -> Mapping[str, Any]: ...
