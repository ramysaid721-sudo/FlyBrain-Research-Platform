# NeuroResearch Neural Core ↔ URCAL Adapter Specification v0.2.1

**Status: interface specification only.** No NeuroResearch Neural Core source tree, runtime, task schemas or test suite was supplied. This package intentionally does not invent NRC internals or claim a live NRC integration.

## URCAL 0.3.1 HTTP contract

- `GET /health`
- `POST /v1/jobs`
- `GET /v1/jobs/{task_id}`
- `Authorization: Bearer <NRC-owned token>`
- HTTPS required for all non-loopback endpoints.

Submission payload:

```json
{
  "task": {
    "task_id": "neuroresearch/<stable-id>",
    "required_capabilities": ["cpu", "python"],
    "estimated_quota_units": 1,
    "max_cost": 0,
    "timeout_seconds": 300,
    "idempotency_key": "<stable-nrc-key>"
  },
  "payload": {"<NRC-defined-task-payload>": "..."}
}
```

## NRC-side requirements

1. Maintain NRC-owned settings, principal, token, resource policy and audit store.
2. Map NRC task types to URCAL capability names and explicit zero-cost ceilings by default.
3. Use stable globally unique task IDs prefixed `neuroresearch/` and stable idempotency keys.
4. Submit and poll through the URCAL API; treat delivery as at-least-once and design workers for idempotency.
5. Validate results against NRC-owned schemas; treat all provider output as untrusted data.
6. Never execute returned code or payloads automatically.
7. Apply NRC data classification and egress policy before sending data to URCAL.
8. Keep FlyBrain and NRC credentials, database records and configuration isolated.

## Required material to implement and test the executable adapter

- NRC source repository/archive and license.
- Runtime entry points and supported runtime versions.
- Task request and result schemas.
- Existing authentication/configuration conventions (not secret values).
- Job lifecycle and cancellation semantics.
- NRC-local persistence/audit interfaces.
- Data classification and egress rules.
- Existing tests and a safe local integration fixture.

## Independence

FlyBrain-NOS and NeuroResearch Neural Core are peers. Each receives a distinct URCAL principal/token, client, namespace, policy, audit store and local state. URCAL remains a neutral resource-control layer, not a neural controller.
