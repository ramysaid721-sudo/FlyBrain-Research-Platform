"""Transport-neutral FlyBrain-owned client for the URCAL HTTP API.

No URCAL Python package import is required. Credentials are supplied by the
caller (normally an environment-backed secret resolver) and never logged.
"""
from __future__ import annotations
import json
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlsplit
from urllib.request import Request, urlopen


class URCALHTTPError(RuntimeError):
    def __init__(self,status,message):
        self.status=status
        super().__init__(f"URCAL HTTP request failed ({status}): {message}")


class FlyBrainURCALHTTPClient:
    def __init__(self,base_url:str,token:str,*,timeout_seconds:float=15.0):
        base_url=base_url.rstrip("/")
        parsed=urlsplit(base_url)
        if parsed.scheme not in {"http","https"} or not parsed.hostname:
            raise ValueError("base_url must be an absolute http or https URL")
        if parsed.username or parsed.password:
            raise ValueError("credentials must not be embedded in base_url")
        if parsed.query or parsed.fragment:
            raise ValueError("base_url must not contain a query or fragment")
        if parsed.query or parsed.fragment:
            raise ValueError("base_url must not contain a query or fragment")
        if parsed.scheme=="http" and parsed.hostname.lower() not in {"127.0.0.1","localhost","::1"}:
            raise ValueError("non-loopback URCAL endpoints must use HTTPS")
        if not token or len(token)<24: raise ValueError("URCAL bearer token must contain at least 24 characters")
        if timeout_seconds<=0: raise ValueError("timeout_seconds must be positive")
        self.base_url=base_url; self._token=token; self.timeout_seconds=float(timeout_seconds)

    def _request(self,method,path,payload=None):
        data=None if payload is None else json.dumps(payload,separators=(",",":"),default=str).encode()
        headers={"Authorization":f"Bearer {self._token}","Accept":"application/json"}
        if data is not None: headers["Content-Type"]="application/json"
        req=Request(self.base_url+path,data=data,headers=headers,method=method)
        try:
            with urlopen(req,timeout=self.timeout_seconds) as response:
                body=response.read(1_048_577)
                if len(body)>1_048_576:
                    raise URCALHTTPError(502,"response exceeds the 1 MiB safety limit")
                try:
                    return json.loads(body)
                except (UnicodeDecodeError, json.JSONDecodeError):
                    raise URCALHTTPError(502,"endpoint returned invalid JSON") from None
        except HTTPError as exc:
            # Never echo arbitrary remote response bodies: they may contain secrets.
            raise URCALHTTPError(exc.code,"remote endpoint rejected the request") from None
        except URLError as exc:
            raise URCALHTTPError(0,"connection failed") from None

    def submit_research_job(self,task_id:str,payload:dict,*,idempotency_key:str|None=None,
                            required_capabilities=("cpu",),max_cost:float=0.0,
                            estimated_quota_units:float=1.0,timeout_seconds:float=300.0):
        if not isinstance(task_id,str) or not task_id.strip(): raise ValueError("task_id must be non-empty")
        if not isinstance(payload,dict): raise ValueError("payload must be a JSON object")
        if not required_capabilities or any(not isinstance(x,str) or not x.strip() for x in required_capabilities):
            raise ValueError("required_capabilities must contain non-empty strings")
        if max_cost<0 or estimated_quota_units<0 or timeout_seconds<=0:
            raise ValueError("cost/quota must be non-negative and timeout must be positive")
        request={"task":{"task_id":task_id,"required_capabilities":list(required_capabilities),
            "max_cost":max_cost,"estimated_quota_units":estimated_quota_units,
            "timeout_seconds":timeout_seconds,"idempotency_key":idempotency_key or task_id},"payload":payload}
        return self._request("POST","/v1/jobs",request)

    def get_job(self,task_id:str):
        return self._request("GET","/v1/jobs/"+quote(task_id,safe=""))
