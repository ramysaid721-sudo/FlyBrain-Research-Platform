# FlyBrain-URCAL HTTP Adapter v0.2.1

Aligned with FlyBrain-NOS 0.13.3 and URCAL 0.3.1.

- Uses authenticated `POST /v1/jobs` and `GET /v1/jobs/{task_id}`.
- Requires a FlyBrain-owned bearer token supplied by an external secret resolver.
- Requires HTTPS for remote endpoints; HTTP is accepted only on loopback for development.
- Caps response bodies at 1 MiB and does not echo arbitrary remote error bodies.
- Validates task identity, payload shape, capabilities, cost, quota and timeout before submission.
- Does not import NeuroResearch or share its credentials, task ownership or policies.

This is a transport adapter only. It submits/retrieves jobs; it does not execute provider workloads by itself.

## Minimal use

```python
from flybrain_urcal_adapter import FlyBrainURCALHTTPClient

client = FlyBrainURCALHTTPClient(
    "https://your-urcal-host.example",
    token=secret_resolver("FLYBRAIN_URCAL_TOKEN"),
)
job = client.submit_research_job(
    "flybrain/experiment-001",
    {"experiment": "replace-with-your-task-payload"},
    idempotency_key="flybrain/experiment-001",
    required_capabilities=("cpu",),
    max_cost=0.0,
)
```

Never hardcode the token or commit it to source control. Keep the default maximum cost at zero unless an explicit, separate authorization policy is approved.
