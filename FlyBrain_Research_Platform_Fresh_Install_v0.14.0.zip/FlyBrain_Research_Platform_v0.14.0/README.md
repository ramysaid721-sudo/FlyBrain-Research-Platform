# FlyBrain Research Platform

**Integrated research stack:** FlyBrain Neural Operating System (FlyBrain-NOS) + Universal Research Compute Access Layer (URCAL) + integration adapters.

This repository consolidates the independently versioned components into one development and CI workspace. It does not imply that external compute providers, NeuroResearch, GPUs, quantum processors, or production hosting are connected.

## Components

| Component | Version / status | Responsibility |
|---|---|---|
| FlyBrain-NOS | 0.13.3 | Connectome-aware research OS, evidence/provenance handling, circuit extraction, synthetic temporal/LIF runtimes, source monitoring, model-hub interfaces |
| URCAL | 0.3.1 | Provider-neutral job API, policy/quota/cost controls, audit trail, catalog and single-host durable queue |
| FlyBrain-URCAL Adapter | 0.2.1 | Bounded HTTP client connecting FlyBrain to URCAL |
| NeuroResearch-URCAL Adapter Spec | 0.2.1 | Interface contract only; executable NRC integration requires the NRC source/runtime and schema |

## Quick start

```bash
python -m venv .venv
. .venv/bin/activate                 # Windows: .venv\\Scripts\\activate
python -m pip install --upgrade pip pytest
python -m pip install -e ./components/URCAL
python -m pip install -e ./components/FlyBrain-NOS
python -m pytest -q components/URCAL/tests
python scripts/run_stack_tests.py --flybrain components/FlyBrain-NOS --urcal components/URCAL
```

## Continuous integration

GitHub Actions runs package tests and the integrated FlyBrain/URCAL test suite on Python 3.10–3.13 for pushes and pull requests to `main` and `develop`. The workflow uses read-only repository permissions and does not require secrets or paid services.

## Deployment and safety boundary

URCAL's included WSGI server is a development transport, not a public production server. It binds to loopback by default and does not provide TLS, rate limiting, distributed workers, or production-grade identity management. For remote deployment, use a maintained WSGI/ASGI server behind TLS, firewalling, managed secrets, monitoring, backups, and explicit rate limits. The SQLite queue is durable for a single host, not a distributed queue.

Provider catalog entries are discovery metadata, not proof of account access, free quota, live availability, or successful connectivity. Provider routing must remain disabled until credentials, quotas, cost ceilings, capabilities, and a real health check are configured and verified.

FlyBrain's temporal and LIF runtimes are synthetic computational models. They are not biologically validated Drosophila brain simulations. Structural connectome edges do not by themselves establish synaptic sign, strength, delay, or physiological conductance.

## Release integrity

The component release archives and wheels are maintained separately. See `docs/RELEASE_AND_VALIDATION.md` for the verified baseline and outstanding production gates.
