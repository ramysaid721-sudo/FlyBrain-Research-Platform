# Contributing

1. Keep FlyBrain-NOS and URCAL independently installable and independently versioned.
2. Add tests for new behavior, including failure and fail-closed cases.
3. Preserve evidence provenance and distinguish measured data from assumptions and synthetic outputs.
4. Never mark a provider connected based only on catalog presence.
5. Run both package test suites and the integrated stack runner before submitting a pull request.
6. Do not commit secrets, generated runtime databases, personal datasets, build output, or local environment files.

## Local verification

```bash
python -m pip install pytest
python -m pip install -e ./components/URCAL
python -m pip install -e ./components/FlyBrain-NOS
python -m pytest -q components/URCAL/tests
python scripts/run_stack_tests.py --flybrain components/FlyBrain-NOS --urcal components/URCAL
```
