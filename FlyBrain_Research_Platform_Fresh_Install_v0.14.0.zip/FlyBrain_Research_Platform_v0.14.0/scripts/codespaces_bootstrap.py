#!/usr/bin/env python3
"""Reproducible first-run setup and validation for GitHub Codespaces/local use."""
from __future__ import annotations
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
VENV = ROOT / ".venv"
PYTHON = VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
REPORT = ROOT / "SETUP_REPORT.json"

def run(label: str, args: list[str], *, required: bool = True) -> dict:
    started = time.time()
    proc = subprocess.run(args, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    result = {"step": label, "command": args, "returncode": proc.returncode,
              "duration_seconds": round(time.time() - started, 2), "output": proc.stdout[-12000:]}
    print(f"\n=== {label}: {'PASS' if proc.returncode == 0 else 'FAIL'} ===", flush=True)
    print(proc.stdout, flush=True)
    if required and proc.returncode:
        results.append(result)
        write_report(False)
        raise SystemExit(proc.returncode)
    results.append(result)
    return result

def write_report(success: bool) -> None:
    payload = {"platform": "FlyBrain Research Platform", "release": "0.14.0",
               "success": success, "steps": results}
    REPORT.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    lines = ["# Setup and Validation Report", "", f"Overall: {'PASS' if success else 'FAIL'}", "",
             "| Step | Result |", "|---|---|"]
    lines += [f"| {x['step']} | {'PASS' if x['returncode'] == 0 else 'FAIL'} |" for x in results]
    (ROOT / "SETUP_REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

results: list[dict] = []
if not PYTHON.exists():
    run("Create virtual environment", [sys.executable, "-m", "venv", str(VENV)])
run("Install pytest", [str(PYTHON), "-m", "pip", "install", "pytest"])
run("Install URCAL", [str(PYTHON), "-m", "pip", "install", "--no-deps", "--no-build-isolation", "-e", str(ROOT / "components/URCAL")])
run("Install FlyBrain-NOS", [str(PYTHON), "-m", "pip", "install", "--no-deps", "--no-build-isolation", "-e", str(ROOT / "components/FlyBrain-NOS")])
env = os.environ.copy()
env["PYTHONPATH"] = os.pathsep.join([str(ROOT / "components/URCAL"), str(ROOT / "components/FlyBrain-NOS"), str(ROOT / "adapters/FlyBrain-URCAL-Adapter"), env.get("PYTHONPATH", "")]).rstrip(os.pathsep)
run("URCAL test suite", [str(PYTHON), "-m", "pytest", "-q", str(ROOT / "components/URCAL/tests")])
run("FlyBrain and integration test suite", [str(PYTHON), str(ROOT / "scripts/run_stack_tests.py"), "--flybrain", str(ROOT / "components/FlyBrain-NOS"), "--urcal", str(ROOT / "components/URCAL")])
run("Compile all Python modules", [str(PYTHON), "-m", "compileall", "-q", str(ROOT / "components"), str(ROOT / "adapters")])
run("Import smoke test", [str(PYTHON), "-c", "import urcal, flybrain_os, flybrain_urcal_adapter; print('URCAL, FlyBrain-NOS, and adapter imports: OK')"], required=True)
write_report(True)
print("\nRESULT: SETUP AND AVAILABLE TESTS PASSED", flush=True)
