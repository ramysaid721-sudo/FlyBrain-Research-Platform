#!/usr/bin/env python3
"""Run FlyBrain tests, optionally enabling the URCAL cross-project test.

Usage:
  python scripts/run_stack_tests.py --flybrain /path/to/FlyBrain
  python scripts/run_stack_tests.py --flybrain /path/to/FlyBrain --urcal /path/to/URCAL
"""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import subprocess
import sys

p = argparse.ArgumentParser()
p.add_argument('--flybrain', required=True, type=Path)
p.add_argument('--urcal', type=Path)
a = p.parse_args()
fly = a.flybrain.resolve()
if not (fly / 'tests').is_dir():
    p.error('--flybrain must point to the FlyBrain source root')
env = os.environ.copy()
paths = [str(fly)]
if a.urcal:
    urcal = a.urcal.resolve()
    if not (urcal / 'urcal').is_dir():
        p.error('--urcal must point to the URCAL source root')
    paths.insert(0, str(urcal))
env['PYTHONPATH'] = os.pathsep.join(paths + ([env['PYTHONPATH']] if env.get('PYTHONPATH') else []))
cmd = [sys.executable, '-m', 'pytest', '-q', str(fly / 'tests')]
print('Running:', ' '.join(cmd), flush=True)
print('URCAL integration:', 'enabled' if a.urcal else 'optional/skipped when not installed', flush=True)
raise SystemExit(subprocess.call(cmd, cwd=fly, env=env))
