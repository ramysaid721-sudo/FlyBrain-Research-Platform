# تعليمات تثبيت FlyBrain Research Platform 0.14.0

1. ارفع محتويات هذا الأرشيف إلى جذر مستودع GitHub باسم `FlyBrain-Research-Platform` (وليس ملف ZIP وحده).
2. افتح المستودع في GitHub Codespaces وأنشئ Codespace جديداً.
3. عند إنشاء البيئة، ينفذ Codespaces تلقائياً `scripts/codespaces_bootstrap.py` عبر إعداد `.devcontainer/devcontainer.json`.
4. ينشئ السكربت بيئة Python افتراضية، ويثبت pytest وURCAL وFlyBrain-NOS، ثم يشغّل الاختبارات وفحوص الاستيراد والترجمة.
5. راجع `SETUP_REPORT.md` و`SETUP_REPORT.json` لمعرفة نتيجة التشغيل.

إذا لم يبدأ الإعداد تلقائياً، افتح Terminal داخل Codespaces وشغّل:

```bash
python scripts/codespaces_bootstrap.py
```

لا يحتوي هذا الإصدار على بيانات اعتماد لمزودي الحوسبة ولا ينشئ اتصالاً خارجياً تلقائياً. لا تضع مفاتيح API داخل ملفات المستودع.
