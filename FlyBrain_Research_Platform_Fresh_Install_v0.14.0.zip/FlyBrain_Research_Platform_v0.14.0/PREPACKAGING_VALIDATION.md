# Pre-packaging validation record

Source bundle: FlyBrain Research Platform 0.14.0.

Local validation executed against this source tree:

- URCAL tests: 68 passed.
- FlyBrain-NOS tests with URCAL integration paths: 76 passed.
- Python compile check: passed.
- Import smoke check (`urcal`, `flybrain_os`, `flybrain_urcal_adapter`): passed.

Total: 144 tests passed, 0 failed.

These checks were run in the assistant's local validation environment. They do not claim that the GitHub Codespace, external provider accounts, production hosting, or third-party APIs have been connected or verified. Codespaces first-run setup is configured separately by `.devcontainer/devcontainer.json` and `scripts/codespaces_bootstrap.py`.
