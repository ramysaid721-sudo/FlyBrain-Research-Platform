# Setup and Validation Report

**Source release:** FlyBrain Research Platform 0.14.0  
**Validation status:** PASS

| Check | Result |
|---|---:|
| URCAL test suite | 68 passed |
| FlyBrain-NOS + URCAL integration test suite | 76 passed |
| Python compile check | Passed |
| Import smoke check | Passed |
| **Total tests** | **144 passed, 0 failed** |

Validation was performed locally against the packaged source tree. GitHub Codespaces execution and external provider connectivity have not yet been verified.
