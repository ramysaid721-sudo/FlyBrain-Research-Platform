# Release and Validation Baseline

## Component baseline

- FlyBrain-NOS: 0.13.3
- URCAL: 0.3.1
- FlyBrain-URCAL HTTP adapter: 0.2.1
- NeuroResearch adapter specification: 0.2.1 (contract only; not an executable NRC connector)

## Previously verified locally

- URCAL unit tests: 68 passed.
- FlyBrain standalone tests: 74 passed, 2 optional cross-project tests skipped.
- FlyBrain integrated with URCAL: 76 passed.
- Combined passing test count across package suites: 144.
- Package compilation, CLI help, wheel builds, clean target installation, and local HTTP/SQLite integration checks passed.
- Provider catalog contains 23 provider/service entries and 21 software/tool entries; entries default to discovered/unknown/not-connected.

These are local verification results from the component release build. The newly added GitHub Actions workflow has been authored but cannot be reported as remotely executed until the repository is created and the workflow runs on GitHub.

## Production gates still open

1. Import the actual NeuroResearch source/runtime and schema; implement and test its executable adapter.
2. Configure provider accounts and credentials; verify each provider's live status, quota, cost, and supported capabilities before enabling routing.
3. Replace the development WSGI serving arrangement with a production server behind TLS, firewalling, managed secrets, rate limits, monitoring, and backups.
4. Replace or augment SQLite for multi-host execution with a broker/queue and idempotent workers; test retries, duplicate delivery, worker loss, and quota race conditions.
5. Supply a pinned connectome dataset snapshot and calibrated or explicitly sourced model parameters; validate against baselines and held-out tasks.
6. Run load, failure-injection, dependency, and security testing in the deployed environment.

## Completion definition

The stack is production-ready only after the production gates above are closed and their evidence is recorded. A green unit-test workflow alone is not a production-readiness certificate.
